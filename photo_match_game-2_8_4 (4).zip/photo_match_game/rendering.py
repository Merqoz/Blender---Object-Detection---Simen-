"""Rendering helpers.

Both the challenge capture and the score capture go through `render_camera_to_path`,
which:
  1. Temporarily makes the requested cam the active scene camera
  2. Hides any background image pinned to that cam (so the overlay can't
     contaminate the render)
  3. Triggers an OpenGL render to a PNG
  4. Restores everything
"""

import bpy


def render_camera_to_path(scene, cam, output_path):
    """OpenGL-render from `cam` to `output_path` (PNG) without any overlay."""
    saved = {
        'filepath': scene.render.filepath,
        'format': scene.render.image_settings.file_format,
        'active_cam': scene.camera,
        'bg_visible': cam.data.show_background_images,
        'cam_hidden': cam.hide_viewport,
    }

    # render.opengl(view_context=False) renders from scene.camera, so swap in
    # the cam we actually want to capture from.
    scene.camera = cam
    cam.hide_viewport = False  # has to be visible to be the active scene cam
    cam.data.show_background_images = False
    scene.render.filepath = output_path
    scene.render.image_settings.file_format = 'PNG'

    try:
        bpy.ops.render.opengl(write_still=True, view_context=False)
    finally:
        scene.render.filepath = saved['filepath']
        scene.render.image_settings.file_format = saved['format']
        cam.data.show_background_images = saved['bg_visible']
        cam.hide_viewport = saved['cam_hidden']
        scene.camera = saved['active_cam']


def setup_camera_background(scene, cam, img, opacity):
    """Pin `img` as a semi-transparent overlay on the camera and resize the
    render output to match the image's aspect ratio.

    Defensive ordering: enable show_background_images both before and after
    creating the new background entry. Some users have reported the checkbox
    being unchecked after this function runs; the redundant set is cheap and
    rules out any save/restore issue from elsewhere flipping it.
    """
    # Defensive: enable once before mutating the list (some Blender builds
    # auto-disable the toggle when the list goes empty)
    cam.data.show_background_images = True
    cam.data.background_images.clear()

    bg = cam.data.background_images.new()
    bg.image = img
    bg.alpha = opacity
    bg.display_depth = 'FRONT'
    bg.frame_method = 'FIT'
    bg.show_background_image = True  # per-entry visibility flag

    # Defensive: re-enable after mutation, in case clear() or new() side-effects
    # toggled the camera-level flag
    cam.data.show_background_images = True

    img_w, img_h = img.size
    if img_w > 0 and img_h > 0:
        max_dim = 1280  # cap so big reference images don't slow scoring renders
        scale = min(1.0, max_dim / max(img_w, img_h))
        scene.render.resolution_x = max(2, int(img_w * scale))
        scene.render.resolution_y = max(2, int(img_h * scale))
        scene.render.resolution_percentage = 100
