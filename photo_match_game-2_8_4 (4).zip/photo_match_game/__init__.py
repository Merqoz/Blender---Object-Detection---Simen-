"""Photo Match Game — turn scene composition into a memory game.

A challenge camera is placed at a random angle around a chosen object, its view
is captured as a screenshot, and the player tries to align their own camera to
match it. Pixel similarity + camera pose similarity are both scored.
"""

bl_info = {
    "name": "Photo Match Game",
    "author": "Claude",
    "version": (2, 8, 4),
    "blender": (3, 2, 0),
    "location": "View3D > Sidebar (N) > Photo Match",
    "description": "Generate a randomized camera challenge or load a reference image, then align your camera to match. Includes live pose scoring, strict scoring, multi-version camera search (v1/v2/v3 with contour matching), 6-DOF object search, continuous fine-tune polishing mode, configurable camera intrinsics with phone presets, a live phone-camera feed (HTTPS+WebSocket) with score-adaptive tracking (Initial Lock + Re-Lock + auto-recover), and a full source-dropdown UI with sub-panels for live feed, tracking status, intrinsics, and advanced state-machine tuning.",
    "category": "3D View",
}

# Reload-safe submodule imports — Blender often reloads add-ons during dev,
# and a plain `from . import x` won't pick up edits without this dance.
if "bpy" in locals():
    import importlib
    for _name in (
        "geometry", "camera_utils", "rendering", "scoring", "image_features",
        "search", "search_v2", "search_v3", "object_search",
        "camera_intrinsics", "tracking_state",
        "properties", "live_scoring", "fine_tune", "live_feed",
        "live_tracking",
        "operators", "ui",
    ):
        if _name in locals():
            importlib.reload(locals()[_name])

import bpy

from . import camera_intrinsics
from . import properties
from . import operators
from . import ui
from . import live_scoring
from . import fine_tune
from . import live_feed
from . import live_tracking


# Order matters: camera_intrinsics registers PhotoMatchCameraIntrinsics, which
# properties.py references in a PointerProperty — so it must register first.
# properties must register before operators/ui that reference
# scene.photo_match_props. live_scoring and live_feed are timer-based and
# need properties registered. live_tracking needs live_feed (frame slot
# import) and properties (PropertyGroup access) so it goes last.
_modules = (camera_intrinsics, properties, operators, fine_tune, ui,
            live_scoring, live_feed, live_tracking)


def register():
    for module in _modules:
        module.register()


def unregister():
    for module in reversed(_modules):
        module.unregister()


if __name__ == "__main__":
    register()
