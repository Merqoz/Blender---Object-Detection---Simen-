"""Per-scene state stored on `scene.photo_match_props`."""

import bpy
from bpy.props import (
    StringProperty, FloatProperty, PointerProperty, BoolProperty,
    EnumProperty, IntProperty,
)
from bpy.types import PropertyGroup

from . import camera_intrinsics
from . import camera_utils


# ----------------------------------------------------------------------------
# Update callbacks
# ----------------------------------------------------------------------------

def _update_opacity(self, context):
    """Keep the camera background alpha in sync with the slider, and force a
    viewport redraw so the change is visible immediately."""
    cam = context.scene.camera
    if cam and cam.type == 'CAMERA' and cam.data.background_images:
        cam.data.background_images[0].alpha = self.opacity
    camera_utils.tag_redraw_3d_viewports(context)


def _target_object_poll(self, obj):
    """Only allow object types that have a meaningful position/extent."""
    return obj.type in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'EMPTY'}


def _fine_tune_update(self, context):
    """Lazy-imported wrapper so we can reference fine_tune.update_fine_tune_enabled
    without a circular import at module load time."""
    from . import fine_tune
    fine_tune.update_fine_tune_enabled(self, context)


def _tracking_auto_recover_update(self, context):
    """Forward auto-recover toggle into the running state machine, if any.
    No-op when not currently tracking."""
    from . import live_tracking
    live_tracking.on_auto_recover_changed(bool(self.tracking_auto_recover))


def _tracking_thresholds_update(self, context):
    """Forward the entire threshold quad into the running state machine.

    Bound to all four threshold sliders' update= callbacks so the user sees
    threshold changes take effect immediately, not at the next match-tick
    boundary. We push all four every edit (rather than tracking which field
    changed) — the SM API takes them as kwargs, the diff cost is negligible
    next to a match-tick render."""
    from . import live_tracking
    live_tracking.on_thresholds_changed(
        tracking_to_lost=self.threshold_tracking_to_lost,
        lost_to_tracking=self.threshold_lost_to_tracking,
        locked_to_tracking=self.threshold_locked_to_tracking,
        tracking_to_locked=self.threshold_tracking_to_locked,
    )


def _reference_source_update(self, context):
    """Switch between Random / File / Live-Feed reference sources.

    Edge case from handoff §405: switching to FILE while a live feed is
    running stops the feed first. The reverse (switching to LIVE_FEED while
    a file reference is loaded) doesn't auto-stop anything — the file image
    just becomes ignored until the user starts a feed."""
    if self.reference_source != 'LIVE_FEED':
        # Stop tracking + live feed if either is up
        from . import live_tracking, live_feed
        if live_tracking.is_tracking():
            live_tracking.stop_tracking(context.scene, self)
        if live_feed.is_running():
            live_feed.stop_server()
            # Mirror props (the operator path normally does this, but we're
            # bypassing it on a programmatic switch)
            self.live_feed_running = False
            self.live_feed_phone_connected = False
            self.live_feed_url = ""


# ----------------------------------------------------------------------------
# Enum items
# ----------------------------------------------------------------------------

ALGORITHM_VERSIONS = [
    ('V1', "v1 — Coarse + Refine",
     "Fibonacci sphere coarse sweep, then shrinking Gaussian perturbations. "
     "The original algorithm. Reliable cold-start, no warm-start advantage."),
    ('V2', "v2 — Warm-start + PID",
     "Tight Gaussian shell around current camera, escalating to global "
     "Fibonacci only if needed. Then PID-controlled gradient descent + "
     "Hooke-Jeeves pattern search polish. Good for hand-aligned starting points."),
    ('V3', "v3 — Contour-aware (default)",
     "v2 algorithm with multi-scale Chamfer (contour) scoring driving the "
     "search. Best at distinguishing different rotations of symmetric objects "
     "(cubes, repeating panels) and silhouettes."),
]


# ----------------------------------------------------------------------------
# Property group
# ----------------------------------------------------------------------------

class PhotoMatchProperties(PropertyGroup):
    # --- Reference image (the screenshot the player is trying to match) ---
    reference_image_path: StringProperty(
        name="Reference Image Path",
        description="Path to the reference image on disk",
        default="",
        subtype='FILE_PATH',
    )
    reference_image: PointerProperty(
        name="Reference Image",
        type=bpy.types.Image,
    )

    # --- Random challenge config ---
    target_object: PointerProperty(
        name="Target Object",
        description="The object the random reference camera will frame",
        type=bpy.types.Object,
        poll=_target_object_poll,
    )
    distance_offset: FloatProperty(
        name="Distance from Surface",
        description="Extra distance beyond the object's bounding sphere when "
                    "placing the random reference camera",
        default=2.0,
        min=0.0,
        max=100.0,
        soft_max=20.0,
        unit='LENGTH',
    )
    upper_hemisphere_only: BoolProperty(
        name="Above Object Only",
        description="Constrain the random reference camera to the upper hemisphere",
        default=True,
    )

    # --- Reference camera (hidden, set when a random challenge is generated) ---
    reference_camera: PointerProperty(
        name="Reference Camera",
        description="Hidden camera that captured the challenge — used for pose scoring",
        type=bpy.types.Object,
    )

    # --- Scores ---
    pixel_score: FloatProperty(default=0.0, min=0.0, max=100.0)
    position_score: FloatProperty(default=0.0, min=0.0, max=100.0)
    rotation_score: FloatProperty(default=0.0, min=0.0, max=100.0)
    score: FloatProperty(
        name="Score",
        description="Combined match score (0-100)",
        default=0.0, min=0.0, max=100.0,
    )
    best_score: FloatProperty(
        name="Best Score",
        description="Best combined score this session",
        default=0.0, min=0.0, max=100.0,
    )

    # --- Display ---
    opacity: FloatProperty(
        name="Reference Opacity",
        description="How visible the reference image is over your scene",
        default=0.5, min=0.0, max=1.0,
        update=_update_opacity,
    )

    # --- Live scoring ---
    live_scoring_enabled: BoolProperty(
        name="Live Scoring",
        description="Continuously update position + rotation scores as you move "
                    "the camera. Pixel score still requires the Calculate button "
                    "(rendering is too slow to do live). Only works with random "
                    "challenges (loaded images have no reference camera to compare against)",
        default=True,
    )

    # --- Auto-solve runtime state (set by the modal operator) ---
    auto_solve_running: BoolProperty(default=False)
    auto_solve_progress: StringProperty(default="")

    # --- Fine-tune mode ---
    # The user-facing toggle. Flipping this True kicks off a modal operator
    # that polishes the current pose with small Hooke-Jeeves steps until the
    # toggle goes back to False.
    fine_tune_enabled: BoolProperty(
        name="Fine-Tune Mode",
        description="Continuously polish the current pose with small steps. "
                    "When on, the camera (or object) is gently nudged toward "
                    "better matches without big jumps. Auto-Solve must be "
                    "stopped first",
        default=False,
        update=lambda self, ctx: _fine_tune_update(self, ctx),
    )
    fine_tune_running: BoolProperty(default=False)  # internal state
    fine_tune_status: StringProperty(default="")  # UI feedback string

    # Persistent mode (v2.7.1+): when ON, fine-tune doesn't auto-disable
    # when the reference image is swapped or when the user drags the
    # camera/object in the viewport. It just re-baselines and keeps polishing.
    # Default OFF preserves the original behavior — explicit opt-in keeps the
    # operator from running indefinitely for users who don't want it.
    fine_tune_persistent: BoolProperty(
        name="Persistent",
        description="Keep fine-tune running through reference-image changes "
                    "and manual pose moves. Without this, fine-tune turns "
                    "itself off whenever the reference is swapped or the "
                    "camera/object is dragged in the viewport, and you have "
                    "to flip the Polishing toggle back on each time. "
                    "With this on, fine-tune notices the change, re-scores "
                    "the new pose as a fresh baseline, and continues polishing",
        default=False,
    )

    fine_tune_target: EnumProperty(
        name="Polish",
        description="What fine-tune adjusts each tick",
        items=[
            ('CAMERA', "Camera",
             "Polish the camera pose around the target"),
            ('OBJECT', "Object",
             "Polish the target object's rotation and location"),
        ],
        default='CAMERA',
    )
    fine_tune_auto_enable: BoolProperty(
        name="Auto-Enable on Bullseye",
        description="Automatically turn on Fine-Tune when Auto-Solve finishes "
                    "with a high score",
        default=True,
    )
    fine_tune_threshold: FloatProperty(
        name="Bullseye Threshold",
        description="Auto-Solve scores at or above this trigger Fine-Tune",
        default=93.0, min=50.0, max=100.0,
    )

    # --- Algorithm choice ---
    camera_algorithm: EnumProperty(
        name="Algorithm",
        description="Which camera search algorithm to use for Auto-Solve",
        items=ALGORITHM_VERSIONS,
        default='V3',
    )

    # --- Scoring config (used by v3 contour scoring) ---
    edge_threshold: FloatProperty(
        name="Edge Sensitivity",
        description="Lower values detect more edges (good for soft images); "
                    "higher values reject noise (good for crisp renders)",
        default=0.15, min=0.05, max=0.5,
    )
    auto_invert_line_art: BoolProperty(
        name="Auto-Invert Line Art",
        description="Detect & invert images where the foreground is bright "
                    "(typical of wireframe renders against a dark background)",
        default=True,
    )

    # Reference feature cache key — operators.py uses this to invalidate the
    # ReferenceFeatures cache when the user changes the inputs to feature
    # extraction. Bumped automatically when relevant settings change.
    feature_cache_key: StringProperty(default="")

    # --- Camera intrinsics ---
    # Focal length / sensor dimensions for the player camera. Stored as a
    # nested group so the live-feed feature (v2.7) can reuse the same data
    # to interpret phone frames.
    intrinsics: PointerProperty(
        name="Camera Intrinsics",
        type=camera_intrinsics.PhotoMatchCameraIntrinsics,
    )

    # --- Live feed (handoff §5.2) ---
    # Read-only status flags + display strings + the QR/live image pointers.
    # The live_feed module is the source of truth; these properties are
    # mirrors that the UI can bind to. Mutated by operators and by the
    # 5 Hz display timer in live_feed.py — never by the user directly.
    live_feed_running: BoolProperty(
        name="Live Feed Running",
        description="True while the local HTTPS server is accepting "
                    "phone connections. Read-only — controlled by Start/Stop",
        default=False,
    )
    live_feed_phone_connected: BoolProperty(
        name="Phone Connected",
        description="True when a phone has an open WebSocket and frames are "
                    "arriving recently. Read-only",
        default=False,
    )
    live_feed_url: StringProperty(
        name="Live Feed URL",
        description="The HTTPS URL the phone should browse to. Shown beneath "
                    "the QR code so the user can also type it in if needed",
        default="",
    )
    live_feed_qr_image: PointerProperty(
        name="Live Feed QR Code",
        description="QR-code Blender image for the live feed URL — generated "
                    "when the server starts. Empty if the `qrcode` Python "
                    "package isn't installed",
        type=bpy.types.Image,
    )
    live_feed_last_frame_age_ms: IntProperty(
        name="Last Frame Age (ms)",
        description="Milliseconds since the most recent frame from the phone. "
                    "Useful for diagnosing dropouts — should sit around 200ms "
                    "while connected (5 Hz). Read-only",
        default=0,
        min=0,
    )
    live_feed_silhouette_only: BoolProperty(
        name="Silhouette Only",
        description="When matching against the live phone feed, keep only "
                    "the largest connected edge component. Reduces background "
                    "clutter interference. (Used by step 5+ matching — has "
                    "no effect on display alone.)",
        default=True,
    )

    # --- v2.8.1: Auto-camera + overlay (defaults updated in v2.8.4) ---
    # When the live feed starts, automatically ensure there's a camera to
    # look through and wire the feed as its background. The overlay render
    # was introduced in v2.8.1 with `live_feed_overlay_enabled=True` by
    # default; v2.8.4 flipped that to False because users with the default
    # Blender scene (containing a red cube) saw the cube render as the
    # overlay and got confused. The feature is still available as an
    # advanced opt-in for users with bespoke scenes who genuinely want
    # a transparent rendered overlay on top of the live feed.
    live_feed_auto_camera: BoolProperty(
        name="Auto-Create Camera",
        description="When the live feed starts: if no scene camera is set, "
                    "create one named 'PhotoMatch_LiveCam' and wire the live "
                    "feed as its background. If a camera already exists, "
                    "reuse it — just add the live feed to its backgrounds. "
                    "Off skips both behaviors entirely",
        default=True,
    )
    live_feed_overlay_enabled: BoolProperty(
        name="Render Scene Overlay (advanced)",
        description="Render the scene with a transparent background every "
                    "1 second, layered on top of the live feed in the camera "
                    "background. Useful for visualizing model-to-photo "
                    "alignment when your scene has the right object set up. "
                    "Disabled by default because the default Blender scene "
                    "(cube + light + camera) renders an opaque red cube on "
                    "top of the live feed, which surprises new users",
        default=False,
    )
    live_feed_overlay_alpha: FloatProperty(
        name="Overlay Opacity",
        description="Alpha for the rendered overlay. Lower = more of the "
                    "live feed shows through; 1.0 = opaque overlay",
        default=0.7, min=0.0, max=1.0,
        subtype='FACTOR',
    )

    # --- v2.8.4: Snapshot rate + freeze ---
    # The display timer used to fire at a fixed 5 Hz (DISPLAY_INTERVAL in
    # live_feed.py), which made the camera-background image flicker as it
    # updated 5×/sec. For photo-match workflows the user wants a stable
    # "polaroid" feel — one frame per second is plenty since the matcher
    # itself only ticks at 1 Hz by default. The interval is exposed as a
    # property so anyone needing more or less can dial it.
    live_feed_snapshot_interval: FloatProperty(
        name="Snapshot Every (s)",
        description="How often the live feed image is refreshed in the "
                    "camera background. 1 second feels like flipping "
                    "polaroids — stable, predictable. Smaller (0.1-0.5) "
                    "approaches real-time video; larger (3+) is good for "
                    "slow alignment work. The matcher reads frames "
                    "independently of this rate; this only affects what "
                    "you SEE in the viewport",
        default=1.0, min=0.1, max=10.0,
        subtype='TIME', unit='TIME',
    )
    live_feed_snapshot_freeze: BoolProperty(
        name="Freeze Snapshot",
        description="When ON, the camera-background image stops refreshing "
                    "and stays pinned to the current frame. Useful for "
                    "carefully aligning the Blender camera against a "
                    "specific reference moment without the image shifting "
                    "underneath you. Phone keeps streaming; only the "
                    "displayed snapshot is frozen",
        default=False,
    )

    # --- v2.8.2: Full 360 stepout sweep (modified V3 algorithm) ---
    # Opt-in tickbox that swaps standard V3 for V3_360 — replaces V3's
    # local+global discovery phases with an exhaustive horizontal grid
    # sweep (azimuth × distance). Costs ~5× the eval budget but eliminates
    # the V3-finds-wrong-basin failure mode for ambiguous scenes.
    enable_full_360_check: BoolProperty(
        name="Do Full 360° with Stepout Check",
        description="Before drilling, sweep around the target in a full "
                    "horizontal circle at multiple distances (configurable). "
                    "Picks the BEST candidate as the search starting point, "
                    "then runs gradient + pattern as usual. Trades search "
                    "time for thoroughness — good when the standard search "
                    "keeps locking onto the wrong angle. With defaults "
                    "(10°×5 rings) the sweep is 180 evals before the regular "
                    "phases kick in",
        default=False,
    )
    full_360_azimuth_step_deg: FloatProperty(
        name="Azimuth Step",
        description="Degrees between azimuth samples in each ring. "
                    "10° = 36 samples per ring (default). Smaller = more "
                    "thorough (and slower)",
        default=10.0, min=2.0, max=60.0,
        subtype='UNSIGNED', unit='ROTATION',
    )
    full_360_distance_step: FloatProperty(
        name="Distance Step",
        description="Meters between distance rings, from the target center. "
                    "0.5m default = first ring at 0.5m, last ring at "
                    "step×count meters out",
        default=0.5, min=0.1, max=5.0,
        subtype='DISTANCE', unit='LENGTH',
    )
    full_360_distance_count: IntProperty(
        name="Distance Rings",
        description="Number of distance rings to sweep. Total sweep "
                    "candidates = (360 / azimuth-step) × ring-count",
        default=5, min=1, max=20,
    )

    # --- Live tracking / state machine state (handoff §5.3) ---
    # These mirror the state machine's runtime values into the property group
    # so the UI can bind to them. Mutated only by `live_tracking.py` (the
    # match timer + the Initial Lock / Re-Lock operators); the user toggles
    # only `tracking_auto_recover`.
    tracking_state: EnumProperty(
        name="Tracking State",
        description="Current regime of the live-tracking state machine. "
                    "Read-only — driven by score adaptiveness",
        items=[
            ('LOST',     "Lost",     "Searching for a pose"),
            ('TRACKING', "Tracking", "Have a rough pose, polishing"),
            ('LOCKED',   "Locked",   "Tight pose match, just polishing"),
        ],
        default='LOST',
    )
    tracking_locked: BoolProperty(
        name="Tracking Locked",
        description="True after Initial Lock has succeeded. Read-only — set "
                    "by the lock operators",
        default=False,
    )
    tracking_auto_recover: BoolProperty(
        name="Auto-Recover",
        description="When ON, dropping below 40% in TRACKING falls back to "
                    "LOST and runs a new full solve. When OFF (default), only "
                    "manual Re-Lock can demote to LOST. Useful when the phone "
                    "may briefly point away during normal use",
        default=False,
        update=_tracking_auto_recover_update,
    )
    tracking_last_score: FloatProperty(
        name="Tracking Last Score",
        description="Most recent score from the state machine. Used for UI "
                    "display only — transitions are driven by the SM itself",
        default=0.0, min=0.0, max=100.0,
    )
    tracking_stale_frame: BoolProperty(
        name="Stale Phone Frame",
        description="Set by the match-tick when no fresh phone frame has "
                    "arrived for ~2s. UI uses this to show a "
                    "'Phone disconnected, waiting…' banner. Read-only",
        default=False,
    )

    # --- Reference source dropdown (handoff §5.1) ---
    # Replaces the earlier "two buttons" pattern: instead of a random-config
    # box AND a separate "load image" button always visible side-by-side,
    # the user now picks ONE source from a dropdown and only that source's
    # configuration is shown. The Live Feed sub-panel auto-becomes visible
    # when LIVE_FEED is selected.
    reference_source: EnumProperty(
        name="Source",
        description="Where the reference image comes from",
        items=[
            ('RANDOM', "Random Challenge",
             "Place a hidden camera at a random angle around the target "
             "object, capture its view as the reference"),
            ('FILE', "Load Image File",
             "Load a reference image from disk (a photo, a screenshot, etc.)"),
            ('LIVE_FEED', "Live Phone Feed",
             "Stream frames from a phone camera over WebSocket and use the "
             "latest frame as the live reference"),
        ],
        default='RANDOM',
        update=_reference_source_update,
    )

    # --- State machine adaptive thresholds (handoff §5.4) ---
    # Defaults match the Thresholds dataclass in tracking_state.py. All four
    # bind to the same update callback which pushes the full quad into the
    # running SM (if any). Sliders are exposed in the Advanced sub-panel.
    threshold_lost_to_tracking: FloatProperty(
        name="LOST → TRACKING",
        description="Score at which a LOST regime promotes to TRACKING. "
                    "Lower = more eager to start polishing on weak matches",
        default=55.0, min=0.0, max=100.0,
        update=_tracking_thresholds_update,
    )
    threshold_tracking_to_locked: FloatProperty(
        name="TRACKING → LOCKED",
        description="Score at which TRACKING regime promotes to LOCKED. "
                    "Higher = stricter about declaring a clean lock",
        default=92.0, min=0.0, max=100.0,
        update=_tracking_thresholds_update,
    )
    threshold_locked_to_tracking: FloatProperty(
        name="LOCKED → TRACKING",
        description="Score below which LOCKED demotes to TRACKING. "
                    "The hysteresis gap (LOCKED→TRACKING vs TRACKING→LOCKED) "
                    "prevents flicker between the two regimes",
        default=80.0, min=0.0, max=100.0,
        update=_tracking_thresholds_update,
    )
    threshold_tracking_to_lost: FloatProperty(
        name="TRACKING → LOST",
        description="Score below which TRACKING falls back to LOST (only when "
                    "Auto-Recover is on). Lower = more tolerant of poor frames",
        default=40.0, min=0.0, max=100.0,
        update=_tracking_thresholds_update,
    )

    # --- Per-regime evaluation budgets (handoff §5.5) ---
    # The match-tick reads these directly each tick, so changes take effect
    # on the very next solve. No update callback needed.
    budget_full_solve: IntProperty(
        name="Full Solve Budget",
        description="Maximum V3 evaluations for the cold-start full solve "
                    "(Initial Lock + auto-recover). More evaluations = more "
                    "thorough search, but each tick takes longer",
        default=60, min=20, max=200,
    )
    budget_warm_solve: IntProperty(
        name="Warm Solve Budget",
        description="Maximum V3 evaluations for the warm solve in TRACKING "
                    "regime. Smaller = faster ticks, but fewer chances to "
                    "improve before the polish phase",
        default=15, min=5, max=60,
    )

    # --- Match-tick interval (handoff §7.5) ---
    # Decoupled from the 5 Hz display rate — even a slow match tick keeps
    # the viewport feeling smooth because the display timer keeps decoding
    # frames between matches.
    match_interval: FloatProperty(
        name="Match Interval (s)",
        description="How often the state machine ticks against the live "
                    "feed. Lower = more responsive, higher CPU. The display "
                    "rate is separate (always ~5 Hz)",
        default=1.0, min=0.2, max=5.0, step=10, precision=1,
    )


classes = (PhotoMatchProperties,)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.photo_match_props = PointerProperty(type=PhotoMatchProperties)


def unregister():
    if hasattr(bpy.types.Scene, "photo_match_props"):
        del bpy.types.Scene.photo_match_props
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
