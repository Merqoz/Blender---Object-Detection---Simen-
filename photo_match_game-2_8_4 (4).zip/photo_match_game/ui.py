"""Sidebar UI panels.

The Photo Match panel is split into a main panel + four sub-panels (handoff
§7.1-§7.5). Sub-panels are real Blender Panels with `bl_parent_id` pointing
at the main panel — they render below it with their own collapsible header,
and their visibility is controlled by `poll()` rather than by inline `if`s.

Layout:

  PHOTOMATCH_PT_panel              ← main: source dropdown + display + score +
                                     auto-solve + fine-tune + reveal
    PHOTOMATCH_PT_LiveFeed         ← visible when source == LIVE_FEED
    PHOTOMATCH_PT_TrackingStatus   ← visible when tracking_locked
    PHOTOMATCH_PT_Intrinsics       ← always visible
    PHOTOMATCH_PT_Advanced         ← always visible, default closed
"""

import bpy
from bpy.types import Panel

from .live_feed import LIVE_FEED_IMAGE_NAME


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------

def _score_message(score):
    """Pick a label and icon for the player's combined score."""
    if score >= 95:
        return "Bullseye!", 'FUND'
    if score >= 85:
        return "Great match!", 'SOLO_ON'
    if score >= 70:
        return "Getting close...", 'KEYTYPE_JITTER_VEC'
    return "Keep adjusting", 'KEYTYPE_EXTREME_VEC'


def _regime_icon(regime):
    """Color-coded icon for a tracking regime. Picked from Blender's built-in
    icon set so we don't need custom icons."""
    return {
        'LOCKED':   'CHECKMARK',
        'TRACKING': 'SORTTIME',
        'LOST':     'ERROR',
    }.get(regime, 'QUESTION')


# ============================================================================
# Main panel
# ============================================================================

class PHOTOMATCH_PT_Panel(Panel):
    """Top-level panel — source dropdown, display options, score, search,
    fine-tune. Sub-panels handle live-feed / tracking / intrinsics / advanced."""
    bl_label = "Photo Match Game"
    bl_idname = "PHOTOMATCH_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Photo Match"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        props = scene.photo_match_props

        self._draw_choose_challenge(layout, props)
        self._draw_display_options(layout, props)
        self._draw_align_hint(layout)
        self._draw_score(layout, props)
        self._draw_autosolve(layout, props)
        self._draw_fine_tune(layout, props)
        self._draw_reveal(layout, props)

    # --- Section: Choose Challenge -----------------------------------------

    def _draw_choose_challenge(self, layout, props):
        """Source dropdown + the configuration block for the chosen source.

        FILE and LIVE_FEED collapse into hint text here — the actual file
        load operator is the only control needed for FILE, and LIVE_FEED's
        whole control surface lives in the Live Feed sub-panel below.
        """
        box = layout.box()
        box.label(text="1. Choose Challenge", icon='IMAGE_DATA')
        box.prop(props, "reference_source", text="Source")

        source = props.reference_source
        if source == 'RANDOM':
            self._draw_random_config(box, props)
        elif source == 'FILE':
            self._draw_file_config(box, props)
        elif source == 'LIVE_FEED':
            self._draw_live_feed_pointer(box, props)

        # Reference image confirmation works for all three sources
        if props.reference_image is not None:
            box.separator()
            box.label(text=props.reference_image.name, icon='CHECKMARK')

    def _draw_random_config(self, box, props):
        """RANDOM source: target object + distance + hemisphere + Generate."""
        col = box.column(align=True)
        col.prop(props, "target_object", text="Target")
        col.prop(props, "distance_offset")
        col.prop(props, "upper_hemisphere_only")
        col.operator(
            "photomatch.generate_random_challenge",
            icon='FILE_REFRESH',
        )

    def _draw_file_config(self, box, props):
        """FILE source: just the load button."""
        box.operator("photomatch.load_image",
                     text="Load Image File", icon='FILEBROWSER')
        box.label(text="Pick a photo or screenshot.", icon='INFO')

    def _draw_live_feed_pointer(self, box, props):
        """LIVE_FEED source: just point the user at the sub-panel below.

        This keeps the main panel clean — all the live-feed UI (start/stop,
        QR, lock buttons, status) lives in the Live Feed sub-panel which
        only appears when this source is selected."""
        col = box.column(align=True)
        col.label(text="Stream from a phone camera.", icon='OUTLINER_OB_CAMERA')
        col.label(text="Configure in the Live Feed sub-panel below.", icon='INFO')

    # --- Section: Display options ------------------------------------------

    def _draw_display_options(self, layout, props):
        box = layout.box()
        box.label(text="2. Display", icon='IMAGE_RGB_ALPHA')
        box.prop(props, "opacity", slider=True)
        box.label(text="(visible in camera view)", icon='OUTLINER_OB_CAMERA')

    # --- Section: Align hint ------------------------------------------------

    def _draw_align_hint(self, layout):
        box = layout.box()
        box.label(text="3. Align Your Camera", icon='OUTLINER_OB_CAMERA')
        col = box.column(align=True)
        col.label(text="Move your camera to match", icon='DOT')
        col.label(text="the reference image.", icon='BLANK1')

    # --- Section: Score ----------------------------------------------------

    def _draw_score(self, layout, props):
        box = layout.box()
        box.label(text="4. Score Your Match", icon='SOLO_ON')

        row = box.row(align=True)
        row.operator("photomatch.calculate_score", icon='PLAY')

        # Live-scoring toggle (only meaningful with a reference camera)
        sub = box.row()
        sub.enabled = props.reference_camera is not None
        sub.prop(props, "live_scoring_enabled")
        if props.reference_camera is None and props.reference_image is not None:
            box.label(text="(Live scoring needs a random challenge)", icon='INFO')

        if props.score <= 0 and props.position_score <= 0:
            return

        msg, icon = _score_message(props.score)
        row = box.row()
        row.scale_y = 1.5
        row.label(text=f"Score: {props.score:.1f}%  {msg}", icon=icon)

        # Per-metric breakdown
        sub = box.column(align=True)
        if props.pixel_score > 0:
            sub.label(text=f"  Pixels:    {props.pixel_score:.1f}%")
        else:
            sub.label(text="  Pixels:    — (press Calculate)")
        if props.reference_camera is not None:
            sub.label(text=f"  Position:  {props.position_score:.1f}%  (live)")
            sub.label(text=f"  Rotation:  {props.rotation_score:.1f}%  (live)")
        else:
            sub.label(text="  (load a random challenge for pose scoring)")

        row = box.row()
        row.label(text=f"Best: {props.best_score:.1f}%", icon='SOLO_OFF')
        row.operator("photomatch.reset_best_score", text="", icon='X')

    # --- Section: Auto-solve -----------------------------------------------

    def _draw_autosolve(self, layout, props):
        box = layout.box()
        box.label(text="5. Auto-Solve", icon='MOD_REMESH')

        if props.auto_solve_running:
            col = box.column(align=True)
            col.label(text=props.auto_solve_progress, icon='SORTTIME')
            col.label(text="Press ESC to cancel", icon='EVENT_ESC')
        else:
            # Algorithm selector — visible upfront because it changes search
            # behavior fundamentally
            box.prop(props, "camera_algorithm", text="Camera Algorithm")

            # V3-only knobs (contour scoring config)
            if props.camera_algorithm == 'V3':
                sub = box.column(align=True)
                sub.prop(props, "edge_threshold", slider=True)
                sub.prop(props, "auto_invert_line_art")

                # v2.8.2: Full 360 stepout sweep — opt-in thoroughness boost.
                # When enabled, the sweep runs first and replaces V3's
                # local+global discovery phases. The 3 sub-sliders only
                # matter when the box is checked, so they grey out if not.
                sweep_box = box.box()
                sweep_box.prop(props, "enable_full_360_check")
                sub_sweep = sweep_box.column(align=True)
                sub_sweep.enabled = bool(props.enable_full_360_check)
                sub_sweep.prop(props, "full_360_azimuth_step_deg",
                               text="Azimuth Step", slider=True)
                sub_sweep.prop(props, "full_360_distance_step",
                               text="Distance Step", slider=True)
                sub_sweep.prop(props, "full_360_distance_count",
                               text="Rings", slider=True)
                # Show the candidate count as a hint — helps the user gauge
                # the sweep cost before they hit Solve. Computed inline.
                if props.enable_full_360_check:
                    n_az = max(1, int(round(
                        360.0 / max(props.full_360_azimuth_step_deg, 1.0))))
                    total = n_az * props.full_360_distance_count
                    sub_sweep.label(
                        text=f"Sweep: {n_az}az × {props.full_360_distance_count}r"
                             f" = {total} evals before drilling",
                        icon='DRIVER')

            row = box.row(align=True)
            row.scale_y = 1.3
            row.operator(
                "photomatch.auto_solve",
                text="Camera",
                icon='OUTLINER_OB_CAMERA',
            )
            row.operator(
                "photomatch.auto_solve_object",
                text="Object",
                icon='OBJECT_DATAMODE',
            )
            col = box.column(align=True)
            col.label(text="Camera = warm-starts from current pose.", icon='DOT')
            col.label(text="Object = move/rotate the object itself.", icon='BLANK1')
            if props.auto_solve_progress:
                box.label(text=props.auto_solve_progress, icon='INFO')

            # Live-feed mode hint — Auto-Solve auto-grabs a frame, no need
            # for separate "Lock" step
            if (props.reference_source == 'LIVE_FEED'
                    and props.live_feed_running):
                box.label(text="(Live mode: auto-captures latest frame)",
                          icon='INFO')

    # --- Section: Fine-tune ------------------------------------------------

    def _draw_fine_tune(self, layout, props):
        box = layout.box()
        row = box.row(align=True)
        row.label(text="6. Fine-Tune Mode", icon='MODIFIER_DATA')

        # The main toggle — large for easy clicking
        row = box.row()
        row.scale_y = 1.3
        if props.auto_solve_running:
            row.enabled = False
        row.prop(
            props, "fine_tune_enabled",
            text="Polishing (continuous)" if props.fine_tune_enabled else "Off",
            toggle=True,
            icon='REC' if props.fine_tune_enabled else 'PAUSE',
        )

        # Status line — shows current polishing score / state
        if props.fine_tune_status:
            box.label(text=props.fine_tune_status, icon='SORTTIME')

        # Persistent toggle (v2.7.1+ — item 1 in user feedback): keeps
        # fine-tune running through reference swaps and pose drags rather
        # than auto-disabling. Off by default to preserve the original
        # behavior — explicit opt-in for users who want the always-on flow.
        box.prop(props, "fine_tune_persistent", icon='LOCKED' if props.fine_tune_persistent else 'UNLOCKED')

        # What to polish
        box.prop(props, "fine_tune_target", expand=True)

        # Auto-enable threshold
        col = box.column(align=True)
        col.prop(props, "fine_tune_auto_enable")
        sub = col.row()
        sub.enabled = props.fine_tune_auto_enable
        sub.prop(props, "fine_tune_threshold", slider=True)

    # --- Section: Reveal (give up) -----------------------------------------

    def _draw_reveal(self, layout, props):
        if props.reference_camera is None:
            return
        box = layout.box()
        box.label(text="Give up?", icon='HIDE_OFF')
        box.operator("photomatch.reveal_reference", icon='RESTRICT_VIEW_OFF')


# ============================================================================
# Sub-panel: Live Feed (handoff §7.2)
# ============================================================================

class PHOTOMATCH_PT_LiveFeed(Panel):
    """Live phone feed controls — server start/stop, QR, status, lock buttons.

    Sub-panel of PHOTOMATCH_PT_panel; only visible when the source dropdown
    is set to LIVE_FEED. Tracking-while-running status (regime, score) is
    in the separate Tracking Status sub-panel — this one is about the
    feed itself + the buttons that initiate or recover a lock.
    """
    bl_label = "Live Phone Feed"
    bl_idname = "PHOTOMATCH_PT_live_feed"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Photo Match"
    bl_parent_id = "PHOTOMATCH_PT_panel"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        try:
            return context.scene.photo_match_props.reference_source == 'LIVE_FEED'
        except AttributeError:
            return False

    def draw(self, context):
        layout = self.layout
        props = context.scene.photo_match_props

        if not props.live_feed_running:
            layout.operator("photomatch.start_live_feed",
                            text="Start Server", icon='PLAY')
            layout.label(text="Generates an HTTPS URL + QR for your phone.",
                         icon='INFO')
            return

        # Running: stop button (alert-styled), URL, QR, status
        row = layout.row(align=True)
        row.alert = True
        row.operator("photomatch.stop_live_feed",
                     text="Stop Server", icon='PAUSE')

        layout.label(text=props.live_feed_url or "(no URL)", icon='URL')

        if props.live_feed_qr_image is not None:
            layout.template_preview(props.live_feed_qr_image, show_buttons=False)
        else:
            sub = layout.column(align=True)
            sub.label(text="QR not generated", icon='ERROR')
            sub.label(text="(open console to see why — encoder is bundled,")
            sub.label(text="this only happens on numpy/bpy load failure)")

        # Phone-connection status
        status_box = layout.box()
        if props.live_feed_phone_connected:
            row = status_box.row()
            row.label(text="Phone connected", icon='LINKED')
            row.label(text=f"{props.live_feed_last_frame_age_ms} ms")
        else:
            status_box.label(text="Waiting for phone…", icon='SORTTIME')

        # Silhouette-only toggle (handoff §5.2 / §7.2)
        layout.prop(props, "live_feed_silhouette_only")

        # v2.8.1 / v2.8.4: Camera + display controls. Snapshot rate + freeze
        # are the prominent controls (the everyday photo-match workflow).
        # The render-overlay toggle is below as an advanced option — it was
        # the default-on "red cube" surprise that v2.8.4 demoted.
        cam_box = layout.box()
        cam_box.label(text="Camera View", icon='CAMERA_DATA')
        cam_box.prop(props, "live_feed_auto_camera")

        # Snapshot rate + freeze — front and center
        snap_col = cam_box.column(align=True)
        snap_col.prop(props, "live_feed_snapshot_interval",
                      text="Refresh every", slider=True)
        # Freeze: emphasize with an alert-style background when ON so the
        # user can't miss why their feed has stopped updating.
        freeze_row = snap_col.row()
        freeze_row.alert = bool(props.live_feed_snapshot_freeze)
        freeze_row.prop(
            props, "live_feed_snapshot_freeze",
            text=("Frozen — click to unfreeze"
                  if props.live_feed_snapshot_freeze
                  else "Freeze current frame"),
            icon=('PAUSE' if props.live_feed_snapshot_freeze else 'PLAY'),
            toggle=True,
        )

        # Advanced: render-overlay (defaults off in v2.8.4)
        cam_box.separator()
        adv_col = cam_box.column(align=True)
        adv_col.prop(props, "live_feed_overlay_enabled")
        sub = adv_col.row()
        sub.enabled = bool(props.live_feed_overlay_enabled)
        sub.prop(props, "live_feed_overlay_alpha", slider=True)

        # Hint about the live-feed image data-block (so user can wire it up
        # as a viewport background if they want to see what the phone sees)
        hint = layout.column(align=True)
        hint.label(text=f"Frames → image '{LIVE_FEED_IMAGE_NAME}'",
                   icon='IMAGE_DATA')

        # --- Lock controls (handoff §7.2) ---
        layout.separator()
        lock_box = layout.box()
        lock_box.label(text="Tracking Lock", icon='LOCKED')

        if not props.tracking_locked:
            row = lock_box.row()
            row.scale_y = 1.3
            row.operator("photomatch.initial_lock",
                         text="Initial Lock", icon='REC')
            if props.target_object is None:
                lock_box.label(text="Set a target object first.", icon='ERROR')
            elif not props.live_feed_phone_connected:
                lock_box.label(text="Waiting for phone before lock can run.",
                               icon='INFO')
            else:
                lock_box.label(text="Hold the phone steady, then press.",
                               icon='INFO')
            return

        # Locked: Re-Lock + Stop Tracking. Detailed status (regime, score)
        # lives in the Tracking Status sub-panel below.
        row = lock_box.row(align=True)
        row.operator("photomatch.relock",
                     text="Re-Lock", icon='FILE_REFRESH')
        row.operator("photomatch.stop_tracking",
                     text="Stop", icon='X')


# ============================================================================
# Sub-panel: Tracking Status (handoff §7.3)
# ============================================================================

class PHOTOMATCH_PT_TrackingStatus(Panel):
    """Big regime indicator + last score + auto-recover toggle + stale-frame
    banner. Only visible while tracking_locked is True."""
    bl_label = "Tracking Status"
    bl_idname = "PHOTOMATCH_PT_tracking_status"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Photo Match"
    bl_parent_id = "PHOTOMATCH_PT_panel"

    @classmethod
    def poll(cls, context):
        try:
            return context.scene.photo_match_props.tracking_locked
        except AttributeError:
            return False

    def draw(self, context):
        layout = self.layout
        props = context.scene.photo_match_props

        # Big regime indicator — scale_y=2.0 makes it the visual focal point
        # of this sub-panel, matching the handoff's "big regime indicator"
        regime = props.tracking_state
        row = layout.row()
        row.scale_y = 2.0
        row.label(
            text=f"{regime}  {props.tracking_last_score:.1f}%",
            icon=_regime_icon(regime),
        )

        # Stale-frame banner (handoff edge case §404)
        if getattr(props, 'tracking_stale_frame', False):
            banner = layout.box()
            banner.alert = True
            banner.label(text="Phone disconnected, waiting…", icon='UNLINKED')

        # Auto-recover toggle
        layout.prop(props, "tracking_auto_recover")
        if props.tracking_auto_recover:
            layout.label(
                text=f"  Falls back below {props.threshold_tracking_to_lost:.0f}%",
                icon='INFO',
            )

        # Stop button — duplicated from Live Feed sub-panel for proximity
        # to the regime indicator. UX win at the cost of one extra row.
        layout.operator("photomatch.stop_tracking",
                        text="Stop Tracking", icon='X')


# ============================================================================
# Sub-panel: Camera Intrinsics (handoff §7.4)
# ============================================================================

class PHOTOMATCH_PT_Intrinsics(Panel):
    """Focal length / sensor dimensions with phone presets.

    Useful when matching against a phone-shot photo or live feed — Blender's
    default 50mm sensor produces a different FOV than any phone camera, and
    alignment never quite locks in until these match. Always visible so the
    user can preconfigure before starting a live feed; collapsible so it
    doesn't dominate the panel."""
    bl_label = "Camera Intrinsics"
    bl_idname = "PHOTOMATCH_PT_intrinsics"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Photo Match"
    bl_parent_id = "PHOTOMATCH_PT_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.photo_match_props
        intr = props.intrinsics

        # Three presets in a row
        row = layout.row(align=True)
        row.operator("photomatch.preset_iphone_main", text="iPhone")
        row.operator("photomatch.preset_android_generic", text="Android")
        row.operator("photomatch.preset_blender_default", text="50mm")

        # Editable values
        col = layout.column(align=True)
        col.prop(intr, "focal_length_mm")
        col.prop(intr, "sensor_width_mm")
        col.prop(intr, "sensor_height_mm")

        # Apply checkbox — prominent because it changes whether edits affect
        # the actual camera or just sit in the addon
        layout.prop(intr, "apply_to_player_camera")


# ============================================================================
# Sub-panel: Advanced (handoff §7.5)
# ============================================================================

class PHOTOMATCH_PT_Advanced(Panel):
    """Advanced state-machine tuning — thresholds, budgets, match interval.

    Default-closed so the casual user never sees these. The thresholds are
    bound to update= callbacks that push changes into the running SM
    immediately, so dragging a slider during active tracking shows the
    effect in real time.
    """
    bl_label = "Advanced"
    bl_idname = "PHOTOMATCH_PT_advanced"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Photo Match"
    bl_parent_id = "PHOTOMATCH_PT_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.photo_match_props

        # Thresholds (handoff §5.4 / §7.5)
        box = layout.box()
        box.label(text="Hysteresis Thresholds", icon='DECORATE_DRIVER')
        col = box.column(align=True)
        col.prop(props, "threshold_lost_to_tracking", slider=True)
        col.prop(props, "threshold_tracking_to_locked", slider=True)
        col.prop(props, "threshold_locked_to_tracking", slider=True)
        col.prop(props, "threshold_tracking_to_lost", slider=True)
        # Sanity hint — show a warning if the user's set them in a
        # nonsensical order (e.g. tracking_to_locked < locked_to_tracking).
        # Without this they'd just see weird regime flicker without knowing
        # why; with it, the panel surfaces the issue immediately.
        if (props.threshold_locked_to_tracking
                >= props.threshold_tracking_to_locked):
            box.label(text="LOCKED→TRACKING should be < TRACKING→LOCKED",
                      icon='ERROR')
        if (props.threshold_tracking_to_lost
                >= props.threshold_lost_to_tracking):
            box.label(text="TRACKING→LOST should be < LOST→TRACKING",
                      icon='ERROR')

        # Budgets (handoff §5.5 / §7.5)
        box = layout.box()
        box.label(text="Evaluation Budgets", icon='SORTTIME')
        col = box.column(align=True)
        col.prop(props, "budget_full_solve")
        col.prop(props, "budget_warm_solve")

        # Match interval — also drives fine-tune cadence (v2.7.1+ item 4):
        # the same slider controls both the live-tracking match-tick AND
        # fine-tune's polishing tick, so the user has one knob for "how
        # often does scoring run?". Renaming the panel label (not the
        # property) keeps backward-compat for any saved .blend files.
        box = layout.box()
        box.label(text="Match / Polish Tick Rate", icon='TIME')
        box.prop(props, "match_interval", text="Interval (s)", slider=True)
        box.label(text="Controls live-tracking ticks AND fine-tune polishing.",
                  icon='INFO')


# ============================================================================
# Registration
# ============================================================================

classes = (
    PHOTOMATCH_PT_Panel,
    # Sub-panels — must register AFTER the parent so bl_parent_id resolves
    PHOTOMATCH_PT_LiveFeed,
    PHOTOMATCH_PT_TrackingStatus,
    PHOTOMATCH_PT_Intrinsics,
    PHOTOMATCH_PT_Advanced,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
