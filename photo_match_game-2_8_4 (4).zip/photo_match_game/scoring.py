"""Match scoring.

Three independent metrics, combined with weights tuned for the game feel:

- **Pixel similarity** (60%) — average per-pixel RGB difference at 128x128.
  This is the actual goal: making the player's view *look like* the reference.
- **Position similarity** (25%) — Euclidean distance between the player and
  reference cameras, normalized by the camera-to-target distance. Acts as a
  tiebreaker when the pixel score plateaus.
- **Rotation similarity** (15%) — angle between the camera forward vectors.
  Important when the target is symmetrical and pixels alone can't tell.

The reference camera's pose is *only* used here for scoring. The player never
sees it directly during gameplay — the screenshot is the only visual reference.
"""

import math

import numpy as np
from mathutils import Vector


# ----------------------------------------------------------------------------
# Pixel similarity
# ----------------------------------------------------------------------------

def _resize_nearest(arr, new_h, new_w):
    """Tiny dependency-free nearest-neighbor resize for an HxWxC array."""
    h, w = arr.shape[:2]
    ys = np.linspace(0, h - 1, new_h).astype(np.int64)
    xs = np.linspace(0, w - 1, new_w).astype(np.int64)
    return arr[ys][:, xs]


def _image_to_array(img):
    """Convert a bpy Image to an HxWx4 float32 numpy array."""
    pixels = np.array(img.pixels[:], dtype=np.float32)
    return pixels.reshape(img.size[1], img.size[0], 4)


def pixel_similarity(reference_image, render_image, target_size=128):
    """Return 0..100 score from RGB pixel difference, downsampled for speed."""
    ref = _resize_nearest(_image_to_array(reference_image), target_size, target_size)
    rendered = _resize_nearest(_image_to_array(render_image), target_size, target_size)
    diff = np.abs(ref[..., :3] - rendered[..., :3])
    mean_diff = float(np.mean(diff))  # 0..1
    return max(0.0, min(100.0, (1.0 - mean_diff) * 100.0))


def _gradient_magnitude(rgb):
    """Per-pixel image-gradient magnitude (Sobel-ish, finite differences).

    Captures structural content (edges, corners) — a flat color shift won't
    move this number much, but a misaligned silhouette will. Used as the
    structural component of strict scoring.
    """
    gray = np.mean(rgb, axis=2)  # H x W
    # Forward differences with edge replication
    gx = np.zeros_like(gray)
    gy = np.zeros_like(gray)
    gx[:, :-1] = gray[:, 1:] - gray[:, :-1]
    gy[:-1, :] = gray[1:, :] - gray[:-1, :]
    return np.sqrt(gx * gx + gy * gy)


def strict_pixel_similarity(reference_image, render_image, target_size=128):
    """Stricter pixel similarity score in 0..100.

    Three changes vs the lenient `pixel_similarity`:

      1. **Power-curve compression**: raw match `m = 1 - mean_diff` is mapped
         through `m^2.5` before being scaled to 0..100. A response that is
         "vaguely the right colors" (m ~0.7) used to score 70; now scores ~41.
         A near-perfect match (m ~0.97) still scores ~92. The curve squeezes
         the middle and rewards excellence.

      2. **Structural term**: in addition to pixel RGB diff, we also compare
         per-pixel gradient magnitudes. This penalizes shape/silhouette
         mismatches that mean-RGB alone would smooth over. Weighted 30%.

      3. **Stricter overall**: the combined formula returns lower numbers for
         the same input than the lenient version. To hit 90% you actually
         need to be aligned, not just sort-of-similar.
    """
    ref = _resize_nearest(_image_to_array(reference_image), target_size, target_size)
    rendered = _resize_nearest(_image_to_array(render_image), target_size, target_size)

    ref_rgb = ref[..., :3]
    rendered_rgb = rendered[..., :3]

    # --- Color similarity (compressed) ---
    color_diff = float(np.mean(np.abs(ref_rgb - rendered_rgb)))
    color_match = max(0.0, 1.0 - color_diff)
    color_compressed = color_match ** 2.5

    # --- Structural similarity (compressed) ---
    ref_grad = _gradient_magnitude(ref_rgb)
    rendered_grad = _gradient_magnitude(rendered_rgb)
    # Normalize each gradient map by its max so brightness differences don't dominate
    ref_norm = ref_grad / (np.max(ref_grad) + 1e-6)
    rendered_norm = rendered_grad / (np.max(rendered_grad) + 1e-6)
    grad_diff = float(np.mean(np.abs(ref_norm - rendered_norm)))
    grad_match = max(0.0, 1.0 - grad_diff)
    grad_compressed = grad_match ** 2.0

    combined = 0.7 * color_compressed + 0.3 * grad_compressed
    return max(0.0, min(100.0, combined * 100.0))


def quick_pixel_score(scene, cam, reference_image, output_path=None, strict=True):
    """Render-and-score in one call, optimized for many fast iterations.

    The caller is expected to have already lowered `scene.render.resolution_*`
    to something cheap (e.g. 256px). Comparison is done at 64x64. Used by the
    auto-solver, which makes ~60 of these in a row.

    `strict` controls which scoring function is used. Defaults to the strict
    version, which has more discriminating gradients near the optimum and
    produces a better-converging search.
    """
    import os
    import tempfile
    import bpy
    from . import rendering

    if output_path is None:
        output_path = os.path.join(tempfile.gettempdir(), "photomatch_quick.png")

    rendering.render_camera_to_path(scene, cam, output_path)

    img = bpy.data.images.load(output_path, check_existing=False)
    try:
        if strict:
            return strict_pixel_similarity(reference_image, img, target_size=64)
        return pixel_similarity(reference_image, img, target_size=64)
    finally:
        bpy.data.images.remove(img)


# ----------------------------------------------------------------------------
# Pose similarity
# ----------------------------------------------------------------------------

def position_similarity(player_loc, reference_loc, characteristic_distance):
    """Score 0..100 based on how close the player camera is to the reference cam.

    `characteristic_distance` should be the reference cam's distance to the
    target — that way "on the opposite side at the same range" scores ~0
    regardless of how big the object is.
    """
    if characteristic_distance <= 0:
        characteristic_distance = 1.0
    distance = (player_loc - reference_loc).length
    normalized = distance / (1.5 * characteristic_distance)
    return max(0.0, min(100.0, (1.0 - normalized) * 100.0))


def rotation_similarity(player_quat, reference_quat):
    """Score 0..100 based on the angle between the camera forward vectors."""
    forward = Vector((0, 0, -1))  # Blender camera local-forward
    p_forward = (player_quat @ forward).normalized()
    r_forward = (reference_quat @ forward).normalized()
    dot = max(-1.0, min(1.0, p_forward.dot(r_forward)))
    angle_degrees = math.degrees(math.acos(dot))
    # 0° = full score, 90° = zero
    normalized = angle_degrees / 90.0
    return max(0.0, min(100.0, (1.0 - normalized) * 100.0))


# ----------------------------------------------------------------------------
# Combined
# ----------------------------------------------------------------------------

PIXEL_WEIGHT = 0.60
POSITION_WEIGHT = 0.25
ROTATION_WEIGHT = 0.15


def combined_score(pixel, position, rotation):
    return (
        PIXEL_WEIGHT * pixel
        + POSITION_WEIGHT * position
        + ROTATION_WEIGHT * rotation
    )
