"""Camera search v3-360 — modified V3 with a thorough 360° azimuth sweep.

When the user opts in via the "Do Full 360 with Stepout Check" toggle, this
variant runs in place of plain V3. It replaces V3's local + global discovery
phases with an exhaustive horizontal grid sweep — a configurable number of
azimuths × a configurable number of distance rings — before drilling with
V3's gradient + pattern phases on the best candidate.

When to use it:
  - Ambiguous scenes where standard V3 keeps locking onto a wrong basin
  - Initial setup where the user wants the "best of all possible angles"
  - Anywhere thoroughness > speed (this costs ~5× the eval budget of V3)

Geometry:
  - Sweep is in the HORIZONTAL plane (around the world Z axis), preserving
    the starting elevation. The user's tilt-up/tilt-down preference is
    respected.
  - Distance rings concentric with the target. Closest ring at one step out
    from the target center; outer rings at multiples of the step distance.
  - Candidates are sampled at every (azimuth × distance) combination and
    fed through the standard V3 scoring pipeline (no special handling).

Defaults: 36 azimuths (10° step) × 5 rings (0.5m step) = 180 candidates.
With contour scoring at 192px, that's ~5 seconds of search time before
gradient/pattern kick in. Worth it for the "I want the BEST start" case
the user described.

What stays the same as V3:
  - Scoring (contour features, chamfer distance — set by operator)
  - Gradient PID descent (FD_EPSILON_THETA, GRADIENT_GAIN, etc.)
  - Pattern search Hooke-Jeeves (PATTERN_INITIAL_STEP)
  - Tabu/escape phases (kicks in when the sweep+gradient+pattern still
    didn't crack 90% — uses V3's existing zone-tracking + escape logic)

What's different:
  - LOCAL_SAMPLES = 0  (sweep replaces local warm-start)
  - GLOBAL_SAMPLES = 0 (sweep replaces global Fibonacci sphere)
  - Plan starts with `_sweep_360_phase()`, then yields from V3's tail
    (which is just gradient + pattern + tabu/escape after the disabled local
    and global)
"""

import math

from . import search_v3
from .search_v2 import (
    direction_to_spherical, spherical_to_direction,
    clamp_theta, wrap_phi,
)


class CameraSolveStateV3_360(search_v3.CameraSolveStateV3):
    """V3 with a 360° horizontal stepout sweep replacing local + global."""

    # Sweep parameters — defaults match the user's stated requirements:
    # 10° azimuth steps, 0.5m distance steps, 5 distance rings.
    AZIMUTH_STEP_DEG = 10.0
    DISTANCE_STEP_M = 0.5
    DISTANCE_RING_COUNT = 5

    def __init__(self, *args,
                 sweep_azimuth_step_deg=10.0,
                 sweep_distance_step=0.5,
                 sweep_distance_count=5,
                 **kwargs):
        """
        Args:
            sweep_azimuth_step_deg: degrees between azimuth samples per ring.
                10° → 36 azimuths/ring. Must be > 0; clamped to 0.5° minimum.
            sweep_distance_step: meters between distance rings, measured
                from the target center.
            sweep_distance_count: number of rings to sweep. Total candidates
                = (360/step) × count.
        """
        # Per-instance sweep params — pulled from constructor args. Setting
        # before super().__init__ matters for nothing here (V3.__init__
        # doesn't reference these), but keeping the order explicit anyway.
        self.AZIMUTH_STEP_DEG = max(0.5, float(sweep_azimuth_step_deg))
        self.DISTANCE_STEP_M = max(0.05, float(sweep_distance_step))
        self.DISTANCE_RING_COUNT = max(1, int(sweep_distance_count))

        super().__init__(*args, **kwargs)

        # Disable V3's local and global phases — the sweep replaces both.
        # Local would waste 8 evals sampling around the user's ORIGINAL pose
        # (it uses self.theta, not self.best_theta), ignoring the sweep
        # result. Global would waste another ~24 evals on a Fibonacci sphere
        # when our sweep already covered the user-relevant angles thoroughly.
        self.LOCAL_SAMPLES = 0
        self.GLOBAL_SAMPLES = 0
        # Belt-and-braces: even with LOCAL_SAMPLES=0 the global phase only
        # runs when best_score < LOCAL_PHASE_THRESHOLD. Push the threshold
        # to infinity so the global phase NEVER triggers, regardless of how
        # the sweep scored.
        self.LOCAL_PHASE_THRESHOLD = 1e9

        # Re-build the plan now that we have our sweep params + disabled
        # local/global. (The parent V3 __init__ already built one with
        # default values; we replace it.)
        self._plan = self._build_plan()

    # ------------------------------------------------------------------
    # Sweep candidate count — exposed so the UI can show the user the
    # eval budget BEFORE they hit "Solve".
    # ------------------------------------------------------------------

    @property
    def sweep_candidate_count(self):
        n_azim = max(1, int(round(360.0 / self.AZIMUTH_STEP_DEG)))
        return n_azim * self.DISTANCE_RING_COUNT

    # ------------------------------------------------------------------
    # Plan composition
    # ------------------------------------------------------------------

    def _build_plan(self):
        """Sweep first, then yield from V3's tail (gradient → pattern → escape).

        The local+global parts of V3's plan are disabled in __init__, so
        chaining super()._build_plan() effectively gives us just the
        gradient+pattern+escape phases starting from the sweep's best.
        """
        yield from self._sweep_360_phase()
        yield from super()._build_plan()

    def _sweep_360_phase(self):
        """Yield all sweep candidates in (ring, azimuth) order.

        Why ring-major over azimuth-major: each ring at a distance is a
        meaningful "altitude" of the search. Iterating ring-by-ring lets
        the user watch the camera spiral outward in the viewport, giving
        clearer visual feedback that the sweep is progressing. With
        azimuth-major, the camera would jump around erratically.

        The sweep keeps the starting THETA (elevation) — we sweep around
        the world Z axis. If the user wanted to sweep elevation too,
        plain V3's Fibonacci sphere is the right tool; this variant is
        specifically for the "walk around the object" use case.
        """
        n_azim = max(1, int(round(360.0 / self.AZIMUTH_STEP_DEG)))
        # Distances: ring_idx + 1 multiplied by step. Ring 1 = 0.5m, ring 2
        # = 1.0m, etc. (Ring 0 would be 0m — inside the object — so we
        # 1-index.)
        distances = [
            (k + 1) * self.DISTANCE_STEP_M
            for k in range(self.DISTANCE_RING_COUNT)
        ]
        elevation_theta = self.theta
        for distance in distances:
            for az_idx in range(n_azim):
                phi = wrap_phi(az_idx * (2.0 * math.pi) / n_azim)
                direction = spherical_to_direction(elevation_theta, phi)
                yield '360_sweep', direction, distance
