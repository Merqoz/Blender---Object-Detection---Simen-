# Photo Match Game — v2.5

A Blender add-on that turns scene composition into a memory game.

## What's new in v2.5

- **Contour-aware camera search (v3)** — the new default. Multi-scale Chamfer (contour) matching makes the auto-solver way better at distinguishing camera angles for symmetric objects like cubes, repeating panels, and silhouettes.
- **Algorithm dropdown** in the N-panel: choose between v1 (original), v2 (PID + warm-start), and v3 (contour-aware, default).
- **Edge sensitivity slider** and **auto-invert** for line-art renders, exposed in the N-panel.

## Two ways to play

### 1. Random Challenge

1. Open the **Photo Match** sidebar tab in the 3D viewport (press `N`)
2. Highlight an object **or** pick one in the *Target* slot
3. Click **Generate Random Challenge**

### 2. Free reference image

Click **Load Image File** to use any image from disk.

## How v3 works (the contour upgrade)

The previous scorers compared *pixels* (mean RGB difference) or *gradient magnitudes*. Both throw away spatial structure — two images with the same brightness statistics can look completely different. v3 fixes this by comparing *where the edges are*, not just whether they exist.

The pipeline:

1. **Edge detection** — Sobel + threshold, applied to both reference and rendered images at three pyramid scales (32, 64, 128 px).
2. **Distance transform** — for the reference, every pixel is labeled with its distance to the nearest edge. This is computed once per reference (~30ms) and cached. Uses the two-pass chamfer 3-4 algorithm in pure numpy.
3. **Chamfer score** — symmetric average distance between rendered edges and reference edges. Lower distance = better contour alignment.
4. **Multi-scale combination** — coarse scales smooth out local minima, fine scales drive precision.

Per-scoring-call cost: ~5-10ms (much of which is rendering, not scoring). The cache means the search runs at the same speed as v2 despite the more sophisticated metric.

### Why this works for hard cases

- **Cube/symmetric objects**: different rotations produce *visibly different* edge layouts (the front-face outline is in a different position than the side-face). Pixel similarity could give nearly identical scores at 0° and 90° because the same regions are bright; chamfer correctly distinguishes them.
- **Smooth silhouettes (e.g., colored spheres)**: even featureless shapes have *outlines*. Chamfer locks onto silhouette position even when interior pixels are uniform.
- **Lighting/color shifts**: edges survive both shifts that pixel-RGB difference would penalize. So if your scene lighting differs from the reference, v3 still locks onto the right shape.

### V3 algorithm tuning

V3 inherits the V2 search algorithm (warm-start + PID gradient descent + Hooke-Jeeves pattern search) with retuned constants for the contour score landscape:

| Parameter | V2 | V3 | Why |
|---|---:|---:|---|
| `EARLY_STOP_SCORE` | 98 | 95 | Chamfer hits a ceiling around 92-95 (Sobel edges are 2-px wide; DT min-distance never quite reaches zero) |
| `GRADIENT_GAIN` | 0.08 | 0.06 | Contour landscape has steeper cliffs; smaller steps prevent overshoot |
| `FD_EPSILON_THETA/PHI` | 0.08 | 0.12 | Bigger probes ensure edges fall in *different* chamfer bins → real gradient signal |
| `LOCAL_PHASE_THRESHOLD` | 60 | 50 | Contour scores are honest about warm-start quality, so v3 skips global sweep more eagerly |

## Algorithm choices summary

| Algorithm | Best for |
|---|---|
| **v1** — Coarse + Refine | Cold starts on simple objects with strong color contrast |
| **v2** — Warm-start + PID | Hand-aligned starting points; pixel-similarity sufficient |
| **v3** — Contour-aware | Default. Symmetric/repeating geometry, real photos, line-art renders |

## Live scoring

Position and rotation scores update live as you move the camera (~5×/second). Pixel score still requires a render, so it stays cached from the last **Calculate** press.

## Auto-Solve (Object) — 6-DOF object pose

Searches `(rotation_xyz, location_xyz)` to find the object pose that best matches the reference, with the camera held fixed.

Uses phased coarse-to-fine search with block-coordinate decomposition: Latin Hypercube → rotation block → translation block → joint refinement → final polish. ~59 evaluations.

## Image management

When you load a new reference or generate a new challenge, the previous reference image's data-block is removed automatically. Images linked elsewhere (via Blender's user count) are preserved. The contour-feature cache is also cleared on image change.

## Installation

1. `Edit → Preferences → Add-ons → Install...`
2. Pick `photo_match_game.zip`
3. Enable "Photo Match Game"
4. Press `N` in the 3D viewport — the **Photo Match** tab appears

## Code structure

| File | Purpose |
|------|---------|
| `__init__.py` | bl_info + register/unregister |
| `properties.py` | `PhotoMatchProperties` — including algorithm dropdown, scoring config |
| `geometry.py` | Bounding box / sphere math |
| `camera_utils.py` | Random direction, look-at, camera creation, viewport redraws |
| `rendering.py` | OpenGL render to PNG with overlay disabled |
| `image_features.py` | Sobel edges, two-pass chamfer DT, multi-scale pyramid, Chamfer score |
| `scoring.py` | Lenient + strict pixel similarity, gradient-magnitude term, pose similarity |
| `search.py` | v1 — Fibonacci + adaptive Gaussian |
| `search_v2.py` | v2 — warm-start + PID gradient + pattern search |
| `search_v3.py` | v3 — same algorithm, retuned for contour score landscape |
| `object_search.py` | 6-DOF object search: LHS + block-coordinate descent |
| `live_scoring.py` | Background timer for live pose-score updates |
| `operators.py` | All `bpy.types.Operator` subclasses (incl. ReferenceFeatures cache) |
| `ui.py` | Sidebar `Panel` |
