# Photo Match Game — Live Phone Feed Feature: Handoff for New Chat

## Purpose of this document

This document is a complete handoff for the next chat. It captures:

1. **What the existing addon does** so the new chat doesn't have to relearn it
2. **The new feature being built** (live phone camera feed → Blender camera background)
3. **Every design decision already made** so we don't re-litigate them
4. **The full implementation plan** broken into ordered steps

The attached zip (`photo_match_game.zip`, v2.6) is the working starting point. The new chat should treat it as a template to extend, not rebuild from scratch.

---

## Part 1 — What the existing addon does (v2.6)

A Blender addon that turns scene composition into a memory game. Pin a reference image to the camera, then align your scene (or have the addon align it for you) until the rendered scene matches the reference.

### Core concepts

- **Reference image**: pinned to the active camera as a semi-transparent background. Visible only in camera view.
- **Score**: 0–100% measure of how well the current rendered scene matches the reference. Three components:
  - **Pixel similarity** (60% weight): strict color match with power-curve compression + structural-gradient term
  - **Position similarity** (25% weight): camera Euclidean distance from the hidden ground-truth reference camera
  - **Rotation similarity** (15% weight): angle between camera forward vectors
- **Live scoring**: position + rotation update ~5×/second as the camera moves. Pixel score is cached from the last Calculate.

### Reference sources (current)

1. **Random Challenge** — addon places a hidden reference camera at a random angle around the target object's bounding sphere, captures a screenshot, drops the player camera at a different angle.
2. **Image File** — load any image from disk.

### Auto-Solve algorithms (camera, 3-DOF: direction-on-sphere + distance)

User picks via dropdown:

- **v1** — Fibonacci sphere coarse sweep + adaptive Gaussian refinement.
- **v2** — Warm-start (tight Gaussian shell around current camera) → optional global Fibonacci fallback → PID-controlled gradient descent (finite-difference probes + PID step sizing) → Hooke-Jeeves pattern-search polish.
- **v3 (default)** — v2 algorithm with retuned constants for contour-based scoring (smaller gradient gain, larger FD epsilons, lower early-stop threshold). Uses multi-scale Chamfer matching against pre-built reference contour features.

### Auto-Solve algorithm (object, 6-DOF: rotation_xyz + location_xyz)

Phased coarse-to-fine with block-coordinate decomposition: Latin Hypercube → rotation block → translation block → joint refinement → final polish. ~59 evaluations.

### V3 contour scoring pipeline (`image_features.py`)

1. Sobel + threshold → binary edge map at 3 pyramid scales (32, 64, 128 px)
2. Two-pass chamfer 3-4 distance transform on each scale (cached per reference, ~30ms one-time cost)
3. Per scoring call: edge-detect rendered image, compute symmetric chamfer distance against cached reference DT, weighted average across scales
4. Power curve (m^2.5) for stricter scoring discrimination

### Fine-Tune mode

A continuous polishing loop. Each ~400ms tick: pick one axis randomly, perturb by current step size, render, score, accept-or-revert. Hooke-Jeeves step adaptation (×1.4 expand on accept, ×0.6 contract on reject). Hard caps prevent jumps: max 0.05 rad rotation, 5% distance, 3% bounding-sphere location.

Auto-enables when Auto-Solve finishes above a threshold (default 93%). Also manually toggleable. Pauses while Auto-Solve is running.

### Module map (existing)

| File | Purpose | LOC |
|------|---------|----:|
| `__init__.py` | bl_info + register/unregister | 56 |
| `properties.py` | `PhotoMatchProperties` (all per-scene state) | 221 |
| `geometry.py` | Bounding box / sphere math | 54 |
| `camera_utils.py` | Random direction, look-at, camera creation, viewport redraws | 155 |
| `rendering.py` | OpenGL render to PNG with overlay disabled | 74 |
| `scoring.py` | Lenient + strict pixel similarity, gradient term, pose similarity | 184 |
| `image_features.py` | Sobel + chamfer DT + multi-scale pyramid + Chamfer scoring | 412 |
| `search.py` | v1 camera search | 200 |
| `search_v2.py` | v2 camera search (warm-start + PID + pattern) | 409 |
| `search_v3.py` | v3 camera search (v2 retuned for contour scoring) | 55 |
| `object_search.py` | 6-DOF object search | 249 |
| `live_scoring.py` | Background timer for live pose-score updates | 131 |
| `fine_tune.py` | Continuous polishing modal operator | 510 |
| `operators.py` | All `bpy.types.Operator` subclasses | 962 |
| `ui.py` | Sidebar `Panel` | 215 |

**Total: ~3900 lines of Python.**

### Key files to understand before extending

In priority order:

1. `properties.py` — see `PhotoMatchProperties`, the central state object
2. `operators.py` — see `_set_reference_image()` and `_get_or_build_reference_features()` — these are the integration points for live feed
3. `image_features.py` — see `ReferenceFeatures` class and `contour_score()`
4. `search_v3.py` + `search_v2.py` — the camera search algorithm
5. `fine_tune.py` — see `_step_camera()` for the polishing logic to reuse

---

## Part 2 — The new feature: Live Phone Camera Feed

### What we're building

A third reference source: **phone camera streamed live to the Blender camera background image**, with score-adaptive tracking that maintains alignment as the phone moves.

### High-level flow

1. User picks "Live Phone Feed" from the new Source dropdown
2. User clicks Start Server → addon starts an HTTPS server on the LAN, generates a self-signed cert, displays a QR code in the panel
3. User scans QR with phone → phone browser opens, asks for camera permission, starts streaming JPEG frames over WebSocket
4. Frames update Blender's camera background image at 5 Hz (display rate)
5. User roughly aims the Blender camera by hand, then clicks **Initial Lock**
6. Initial Lock freezes the current frame, runs the full V3 Auto-Solve against it. ~10s.
7. After successful lock, score-adaptive tracking starts: every 1 second a new frame becomes the reference, and the system runs an appropriately-sized search depending on the current score
8. UI shows current state: 🟢 LOCKED 94% / 🟡 TRACKING 71% / 🔴 LOST

### Architecture leverages existing previous work

There's a previous chat (`https://claude.ai/chat/945fe629-39b2-4706-af4c-62882a0f8b30`) that built an M3T phone tracker with all the networking pieces we need:

- Pure-Python WebSocket implementation (RFC 6455, ~80 lines, no `aiohttp` dependency)
- Self-signed cert generation via the `cryptography` library (Blender ships this) with openssl CLI fallback
- Phone HTML page with `getUserMedia()`, camera flip, JPEG canvas encode, WebSocket upload
- QR code generation
- LAN IP discovery

We're lifting these primitives, throwing away the M3T tracking, and using the frames to update Blender's camera background image instead of an OpenCV display window.

### Score-adaptive state machine (the central new idea)

Once locked onto a pose, we have prior information about where the object is. The probability of a 180° flip between 1-second frames is essentially zero. The probability of small angular drift is high. The search radius should reflect that prior. Three states with hysteresis:

```
                    ┌──────────────────┐
                    │      LOST        │
                    │ Full V3 solve    │
                    │ (~60 evals)      │
                    └──┬─────────────▲─┘
              score≥55 │             │ score<40
                    ▼               │ (only via Re-Lock unless
                                    │  Auto-recover is on)
                    ┌──────────────────┐
                    │    TRACKING      │
                    │ Warm V3 solve    │
                    │ (~15 evals)      │
                    └──┬─────────────▲─┘
              score≥92 │             │ score<80
                    ▼               │
                    ┌──────────────────┐
                    │     LOCKED       │
                    │ Hooke-Jeeves     │
                    │ (1 perturb/tick) │
                    └──────────────────┘
```

**Hysteresis matters**: without dual thresholds, a score wobbling around 50% would oscillate between Lost and Tracking, restarting full solves repeatedly.

**Regime transition rule**: decided from the **last accepted score**, not from probe scores. Hooke-Jeeves probes can dip lower temporarily without indicating actual lock loss.

**Auto-recover**: a checkbox (default OFF) that allows automatic Tracking→Lost transitions when score drops below 40. With it off, only manual Re-Lock can trigger a full solve.

---

## Part 3 — Design decisions already made (don't re-debate)

### Live feed mechanics

- **Display rate**: 5 Hz (overlay update in viewport — feels smooth)
- **Match rate**: 1 Hz (used by state machine — gives V3 features time to rebuild)
- These two rates are decoupled
- **Phone-side framerate**: 5 Hz (sending more wastes bandwidth)
- **JPEG decoder in Blender**: PIL/Pillow (Blender ships it, no new dependency)
- **Lock workflow**: manual button presses for Initial Lock and Re-Lock, no auto-acquire
- **Re-Lock strategy**: warm solve first (~20 evals), fall back to full solve if warm result < 60%
- **Network jitter**: not addressed in code — at 1 Hz, jitter is irrelevant

### Camera intrinsics

- **User-adjustable in N-panel**, no auto-detection
- **Presets**: iPhone Main (26mm equiv), Android Generic (24mm), Blender Default (50mm)
- **Apply to player camera**: checkbox (default ON)

### Silhouette-only mode

- **Default ON** for Live Feed source (clean approach to background interference)
- Implemented as: largest connected edge component only, both reference and rendered

### Lens distortion

- **Not addressed in this iteration** — known limitation, deferred

### Adaptive thresholds

- All four hysteresis thresholds (40 / 55 / 80 / 92) exposed as advanced sliders
- Per-regime evaluation budgets (60 / 15 / 1) exposed as advanced sliders

### Things explicitly rejected

- ❌ Auto-FOV solver
- ❌ Frame masking UI for arbitrary segmentation (silhouette-only is the v1)
- ❌ Continuous high-rate (5 Hz) matching — match runs at 1 Hz
- ❌ Per-tick "should I be in a different regime?" check — regime decided from last-accepted score only
- ❌ Auto Lost-acquire on connection — user must press Initial Lock

---

## Part 4 — Full implementation list

### Module 1: `live_feed.py` (new, ~600 lines)

The core of the feature.

**1.1 Networking primitives**
- `get_local_ip()` — UDP-socket trick for LAN IP
- `ensure_ssl_cert(ip)` — generate self-signed cert via `cryptography`, cache to `tempfile.gettempdir()`, fall back to openssl CLI
- `find_free_port(start=8443)` — try ports until one binds

**1.2 Pure-Python WebSocket implementation**
- `ws_handshake_response(key)` — RFC 6455 handshake
- `ws_read_frame(conn)` — frame parser (handles 16/64-bit length, masking)
- `ws_send_frame(conn, opcode, payload)` — for ping/close
- Connection handler thread: reads binary frames, writes JPEG bytes into a thread-safe `latest_frame` slot

**1.3 HTTP server**
- Plain stdlib `http.server.HTTPServer` wrapped with `ssl.SSLContext`
- Routes: `/` serves embedded HTML, `/ws` upgrades to WebSocket
- Daemon thread

**1.4 Embedded phone HTML page** (single string constant)
- `getUserMedia()` with environment camera preference
- Front/back flip button
- JPEG canvas encode at quality 0.7
- WebSocket sending at 5 Hz
- Connection status indicator, FPS display
- Mobile-friendly CSS

**1.5 QR code generation**
- Try `qrcode` lib if available, fall back to URL-only display
- Render to a Blender image data-block for panel display

**1.6 Frame consumer (main thread, called by `bpy.app.timers`)**
- `_pull_latest_frame()` — pop the latest JPEG bytes from the shared slot
- `_decode_jpeg_to_image(jpeg_bytes, target_image_name)` — use PIL to decode, write into `bpy.data.images['photomatch_live_feed']`
- Two timer callbacks:
  - **Display timer (5 Hz)**: update the camera background image
  - **Match timer (1 Hz)**: kick the state machine when locked

**1.7 Server lifecycle operators**
- `PHOTOMATCH_OT_StartLiveFeed` — bind cert, start server thread, register timers, generate QR
- `PHOTOMATCH_OT_StopLiveFeed` — stop server, unregister timers, clear last frame

### Module 2: `tracking_state.py` (new, ~200 lines)

Score-adaptive state machine.

**2.1 Three regimes** (LOST, TRACKING, LOCKED)

**2.2 Hysteresis transitions**
- Lost → Tracking when score rises above 55
- Tracking → Locked when score rises above 92
- Locked → Tracking when score drops below 80
- Tracking → Lost only via manual Re-Lock by default; via score < 40 only if Auto-recover is ON

**2.3 State machine class**
- Tracks current regime, last-accepted score, last-pose
- `tick(scene, props)` method: run appropriate search depth, return new score
- Uses last-accepted score (not probe scores) for transition decisions

**2.4 Per-regime executors**
- `_run_full_solve()` — V3 cold-start parameters (long-running, multi-tick)
- `_run_warm_solve()` — V3 warm-start, narrow radius, 15 evals (fits in one tick)
- `_run_locked_polish()` — single Hooke-Jeeves perturbation via existing fine_tune logic

**2.5 Multi-tick full solve handling**
- Implement as a generator that survives across ticks so the UI stays responsive

### Module 3: Camera intrinsics (extend `properties.py` or new `camera_intrinsics.py`)

**3.1 New PropertyGroup** `PhotoMatchCameraIntrinsics`
- `focal_length_mm: FloatProperty` (default 50)
- `sensor_width_mm: FloatProperty` (default 36)
- `sensor_height_mm: FloatProperty` (default 24)
- `apply_to_player_camera: BoolProperty` (default True)

**3.2 Update callbacks**
- When any value changes AND `apply_to_player_camera=True`: write to `scene.camera.data.lens`, `sensor_width`, `sensor_height`

**3.3 Preset operators**
- `PHOTOMATCH_OT_PresetIPhoneMain` — 26mm equiv, ~5.7mm sensor width
- `PHOTOMATCH_OT_PresetAndroidGeneric` — 24mm equiv, ~5.4mm sensor
- `PHOTOMATCH_OT_PresetBlenderDefault` — 50mm, 36mm sensor

### Module 4: Silhouette-only mode (extend `image_features.py`)

**4.1 New function** `extract_largest_silhouette(edges)`
- Connected-component analysis on binary edge map (pure numpy two-pass labeling)
- Find largest connected component
- Return new edge map containing only that component

**4.2 Extend `ReferenceFeatures.__init__`**
- New parameter `silhouette_only: bool = False`
- When True: replace edges with `extract_largest_silhouette(edges)` before distance transform

**4.3 Same processing applied to rendered images** in `contour_score`
- Add `silhouette_only` parameter, propagate through the pipeline

### Module 5: Properties additions (`properties.py`)

**5.1 Source dropdown**
- New `EnumProperty reference_source`: `RANDOM` / `FILE` / `LIVE_FEED`
- Replaces the current "two buttons" pattern

**5.2 Live feed properties**
- `live_feed_running: BoolProperty(default=False)` — read-only
- `live_feed_phone_connected: BoolProperty(default=False)` — read-only
- `live_feed_url: StringProperty` — for display
- `live_feed_qr_image: PointerProperty(type=bpy.types.Image)` — generated QR
- `live_feed_last_frame_age_ms: IntProperty` — for status display
- `live_feed_silhouette_only: BoolProperty(default=True)`

**5.3 State machine properties**
- `tracking_state: EnumProperty` (Lost / Tracking / Locked) — display only
- `tracking_locked: BoolProperty(default=False)` — has user pressed Initial Lock?
- `tracking_auto_recover: BoolProperty(default=False)`
- `tracking_last_score: FloatProperty(default=0.0)`

**5.4 Adaptive thresholds (advanced sub-panel)**
- `threshold_lost_to_tracking: FloatProperty(default=55)`
- `threshold_tracking_to_locked: FloatProperty(default=92)`
- `threshold_locked_to_tracking: FloatProperty(default=80)`
- `threshold_tracking_to_lost: FloatProperty(default=40)`

**5.5 Per-regime evaluation budgets (advanced)**
- `budget_full_solve: IntProperty(default=60)`
- `budget_warm_solve: IntProperty(default=15)`

**5.6 Camera intrinsics nested group**
- `intrinsics: PointerProperty(type=PhotoMatchCameraIntrinsics)`

### Module 6: Operator additions (`operators.py`)

**6.1 `PHOTOMATCH_OT_InitialLock`**
- Captures current live frame as `bpy.data.images['photomatch_lock_frame']`
- Runs full V3 Auto-Solve against the frozen frame
- On success: sets `tracking_locked = True`, transitions to LOCKED, kicks off live-tracking timer

**6.2 `PHOTOMATCH_OT_ReLock`**
- Tries warm solve first (~20 evals), falls back to full solve if warm result < 60%

**6.3 `PHOTOMATCH_OT_ApplyIntrinsicsPreset`**
- Helper for preset buttons

**6.4 Live-tracking timer** (not an operator)
- `bpy.app.timers` callback
- Fires every 1 second when `tracking_locked = True` and `live_feed_running = True`
- Calls `tracking_state.tick()`

### Module 7: UI rework (`ui.py`)

**7.1 Replace section 1 with source dropdown**
- "Source" enum
- Conditional sub-section based on selection

**7.2 New Live Feed sub-panel** (visible when source == LIVE_FEED)
- Start / Stop Server toggle
- Status block (server, phone, last frame age)
- QR code preview (Blender image preview in panel)
- Silhouette-only toggle
- Initial Lock button (only enabled when phone connected)
- Re-Lock button (only enabled when locked)

**7.3 New Tracking Status sub-panel** (visible when locked)
- Big regime indicator with color
- Last frame age
- Stop tracking button
- Auto-recover checkbox

**7.4 New Camera Intrinsics sub-panel**
- Three preset buttons in a row
- Focal length, sensor width, sensor height sliders
- Apply-to-player-camera checkbox

**7.5 Advanced settings (collapsible)**
- Threshold sliders (4)
- Budget sliders (2)
- Match update interval

### Module 8: Integration touchpoints (existing code)

**8.1 `_set_reference_image` in operators.py**
- Already invalidates feature cache ✓
- Add `live_feed=True` flag — skip file-load path, use in-memory live frame
- Don't remove old image data-block for live frames

**8.2 V3 search (`search_v3.py`)**
- Add `cold_start: bool` parameter to differentiate Lost full solve from Tracking warm solve

**8.3 `fine_tune.py`**
- Refactor: extract core perturbation logic into a standalone function the state machine can call without going through the modal

**8.4 Auto-Solve operators**
- When live feed is active: auto-grab the latest live frame as a frozen reference and run normally

**8.5 `__init__.py`**
- Register new modules: `live_feed`, `tracking_state`, new operators
- Bump version to 2.7.0

### Edge cases (must-handle)

- User stops live feed while locked → tracking stops, last frame remains as static reference
- Phone disconnects mid-tracking → state machine pauses, UI shows "Phone disconnected, waiting…"
- User loads a file reference while live feed is running → live feed stops first
- User unchecks Auto-recover during a Lost-state full solve → solve completes, but next Lost transition pauses
- User changes intrinsics during tracking → existing tick uses old, next tick uses new
- Server start fails (port busy / cert generation fails) → clear panel error, not Python traceback

### Threading safety

- All `bpy.data` mutation on the main thread (via timers)
- Server thread only writes to a `threading.Lock`-protected slot
- Latest-frame slot is overwritten, never queued

### Graceful shutdown

- On addon unregister: stop server, kill timers, clear properties
- On Blender exit: same (handled via cleanup hook)

### Testing plan

Standalone tests for algorithmic pieces:

- State machine transitions (synthetic score sequences)
- Hysteresis behavior (no oscillation at boundaries)
- Silhouette extraction (synthetic edge maps)
- WebSocket frame parser (round-trip a frame)

Real-world testing requires actual phone — user must do this.

---

## Part 5 — Build order

Implement in this order so each step is testable on its own:

1. **Camera intrinsics module + UI** — small, immediately useful, no live feed needed
2. **Silhouette-only mode in `image_features.py`** — extends existing tested code
3. **State machine module standalone** — testable with mocked score functions
4. **Live feed networking + HTML page** — server runs, phone connects, frames fill a Blender image, no matching yet
5. **Wire state machine + live feed together** — Initial Lock, tracking loop
6. **UI rework, polish, edge cases**

**Estimated total work**: ~2000-2500 new lines across 4-5 new files plus modifications to 4-5 existing files.

---

## Part 6 — How to start the new chat

Open a new chat. Upload `photo_match_game.zip` (the v2.6 build attached). Then paste this prompt:

> I'm extending a Blender addon called "Photo Match Game". The attached zip is the working v2.6 base. I have a complete handoff document below describing the existing addon, the new feature being built (live phone camera feed), all design decisions already made, and the full implementation plan.
>
> Please read the handoff carefully before writing any code. Don't re-debate decisions in the "Design decisions already made" section.
>
> Start with **step 1** of the build order: Camera Intrinsics module + UI. Deliver as a working zip extending the v2.6 base. Then I'll review and we'll move to step 2.
>
> [paste contents of HANDOFF.md here]

The new chat starts fresh with full context, no token waste rediscovering decisions.

---

## Reference: the previous M3T project

Source: chat at `https://claude.ai/chat/945fe629-39b2-4706-af4c-62882a0f8b30`

What to lift:
- `server.py` — pure-Python WebSocket implementation (RFC 6455, ~80 lines)
- `server.py` — `ensure_ssl_cert(ip)` with cryptography + openssl fallback
- `server.py` — `get_local_ip()` UDP-socket trick
- `static/phone_camera.html` — `getUserMedia()` page with camera flip and WebSocket upload
- QR generation snippet

What to discard:
- All M3T tracking code (`tracker.py`)
- OpenCV display window
- Pose estimation
- Mesh handling
- Eel monitor

Lift the networking layer and embedded HTML; throw away everything domain-specific to M3T.

---

## Versioning

Current version: **v2.6.0**
Target version after live feed: **v2.7.0**

bl_info goes in `__init__.py`. Bump version, update description string, add new modules to the reload list.
