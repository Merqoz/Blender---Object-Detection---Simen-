"""Freeform 3D camera search — not locked to a sphere around the object.

The standard search algorithms orbit the target on a bounding sphere:
    camera_pos = target_center + direction * distance

This works for isolated objects but fails for:
  - Large architectural scenes (you want ground-level shots of a building face)
  - Interior scenes (camera at eye height, not overhead)
  - Scenes where the reference was taken from an unusual angle

Freeform search instead starts from the user's CURRENT camera position and
explores outward in full 3D space. The camera always points at the target,
but its position is unconstrained — it can be at ground level, above, to
the side, close up, far away, anywhere.

Exploration strategy:
  1. Concentric shells around the starting position (expanding outward)
  2. Ground-level sweep (fix Z near start height, fan out in XY)
  3. Height sweep (same XY region, vary Z from ground to overhead)
  4. Azimuth fan (arc around the target at similar distance/height)
  5. Distance sweep (closer and farther from the start direction)
  6. Lévy-flight random jumps for long-range exploration

Phase 1 uses vertex reprojection (no renders) when a reference camera and
target object are available. Otherwise falls back to render-based scoring.

Phase 2 verifies top candidates with actual renders.
Phase 3 polishes with gradient descent in XYZ space.
"""

import math
import random

from mathutils import Vector

from .search_v2 import (
    direction_to_spherical, spherical_to_direction,
    clamp_theta, wrap_phi,
)


class FreeformSearch:
    """3D freeform camera search starting from the current camera position.

    The camera always points at target_center but its position is free
    in 3D space. Explores using expanding shells, ground sweeps, height
    sweeps, azimuth fans, and random jumps.

    When a reference camera + target object are available, Phase 1 uses
    vertex reprojection for fast geometric scoring (no renders). Otherwise
    all candidates go through render-based scoring.

    Usage (from operator):
        state = FreeformSearch(target_center, start_position, ...)
        while True:
            cand = state.next_candidate()
            if cand is None: break
            phase, position = cand
            # position camera at `position`, look at target_center
            # render + score
            state.report_score(position, score)
    """

    # --- Config ---
    # Phase 1: geometric candidates (no renders)
    SHELL_RADII = [0.5, 1.0, 2.0, 4.0, 8.0, 16.0]  # meters from start
    POINTS_PER_SHELL = 30
    GROUND_SWEEP_POINTS = 40
    HEIGHT_SWEEP_POINTS = 20
    AZIMUTH_FAN_POINTS = 36  # every 10 degrees
    DISTANCE_SWEEP_POINTS = 15
    RANDOM_JUMPS = 30
    TOP_AFTER_PHASE1 = 8

    # Phase 2: render verification
    # (top candidates from Phase 1)

    # Phase 3: render-based polish
    GRADIENT_STEPS = 8
    FD_EPSILON_START = 0.5   # meters — larger than spherical search
    PATTERN_STEPS = 20
    PATTERN_STEP_START = 0.3

    EARLY_STOP = 96.0

    def __init__(self, target_center, start_position,
                 upper_hemisphere=True,
                 scene=None, reference_cam=None, target_obj=None):
        """
        Args:
            target_center: Vector — the point the camera always looks at
            start_position: Vector — where the camera is NOW (user's pose)
            upper_hemisphere: if True, don't go below the target center Z
            scene, reference_cam, target_obj: needed for Phase 1 geometric
                scoring. If any is None, Phase 1 is skipped and all
                candidates go through render scoring.
        """
        self.target_center = Vector(target_center)
        self.start_position = Vector(start_position)
        self.upper_hemisphere = upper_hemisphere

        # Geometric scoring availability
        self._has_geo = (scene is not None
                         and reference_cam is not None
                         and target_obj is not None)
        self._scene = scene
        self._ref_cam = reference_cam
        self._target_obj = target_obj

        # Best tracking
        self.best_score = -1.0
        self.best_position = self.start_position.copy()
        self.evaluations_done = 0

        # Derived geometry
        self._start_to_target = self.target_center - self.start_position
        self._start_distance = max(0.1, self._start_to_target.length)
        self._start_direction = self._start_to_target.normalized()
        self._start_height = self.start_position.z

        # Estimate scene scale from start distance
        self._scale = max(1.0, self._start_distance * 0.3)

        # Build the plan
        self._plan = self._build_plan()
        self._pattern_step = self.PATTERN_STEP_START

    @property
    def total_evaluations_planned(self):
        if self._has_geo:
            return self.TOP_AFTER_PHASE1 + self.GRADIENT_STEPS * 6 + self.PATTERN_STEPS
        # No geo: all candidates need renders
        total_phase1 = (len(self.SHELL_RADII) * self.POINTS_PER_SHELL
                        + self.GROUND_SWEEP_POINTS
                        + self.HEIGHT_SWEEP_POINTS
                        + self.AZIMUTH_FAN_POINTS
                        + self.DISTANCE_SWEEP_POINTS
                        + self.RANDOM_JUMPS)
        return total_phase1 + self.GRADIENT_STEPS * 6 + self.PATTERN_STEPS

    def _clamp_position(self, pos):
        """Optionally enforce upper-hemisphere constraint."""
        if self.upper_hemisphere and pos.z < self.target_center.z + 0.05:
            pos = Vector((pos.x, pos.y, self.target_center.z + 0.05))
        return pos

    def _ensure_looks_at_target(self, pos):
        """Ensure position isn't ON the target (would break look-at)."""
        to_target = self.target_center - pos
        if to_target.length < 0.05:
            # Nudge away
            pos = pos + Vector((0.1, 0.1, 0.1))
        return pos

    def _make_candidate(self, pos):
        """Clamp + validate a candidate position."""
        pos = self._clamp_position(pos)
        pos = self._ensure_looks_at_target(pos)
        return pos

    # --- Candidate generators ---

    def _shell_candidates(self):
        """Points on concentric spheres around the start position."""
        golden_angle = math.pi * (3.0 - math.sqrt(5.0))
        for radius in self.SHELL_RADII:
            r = radius * self._scale
            for i in range(self.POINTS_PER_SHELL):
                # Fibonacci sphere distribution
                z = 1.0 - (i / max(1, self.POINTS_PER_SHELL - 1)) * 2.0
                xy_r = math.sqrt(max(0.0, 1.0 - z * z))
                theta = golden_angle * i
                offset = Vector((
                    math.cos(theta) * xy_r * r,
                    math.sin(theta) * xy_r * r,
                    z * r,
                ))
                yield self._make_candidate(self.start_position + offset)

    def _ground_sweep_candidates(self):
        """Positions at approximately the same height as the start, fanning
        out in the horizontal plane around the target."""
        height = self._start_height
        for i in range(self.GROUND_SWEEP_POINTS):
            angle = 2.0 * math.pi * i / self.GROUND_SWEEP_POINTS
            # Vary the distance from target center
            dist = self._start_distance * random.uniform(0.3, 2.5)
            x = self.target_center.x + math.cos(angle) * dist
            y = self.target_center.y + math.sin(angle) * dist
            # Small height jitter
            z = height + random.gauss(0, self._scale * 0.1)
            yield self._make_candidate(Vector((x, y, z)))

    def _height_sweep_candidates(self):
        """Vary height from ground level to overhead, keeping XY near start."""
        base_x = self.start_position.x
        base_y = self.start_position.y
        min_z = self.target_center.z + 0.1 if self.upper_hemisphere else self.target_center.z - self._start_distance
        max_z = self.target_center.z + self._start_distance * 2.0
        for i in range(self.HEIGHT_SWEEP_POINTS):
            frac = i / max(1, self.HEIGHT_SWEEP_POINTS - 1)
            z = min_z + frac * (max_z - min_z)
            # Small XY jitter
            x = base_x + random.gauss(0, self._scale * 0.3)
            y = base_y + random.gauss(0, self._scale * 0.3)
            yield self._make_candidate(Vector((x, y, z)))

    def _azimuth_fan_candidates(self):
        """Arc around the target at the same height and distance as start.
        This gives all the side views."""
        height = self._start_height
        dist = self._start_distance
        for i in range(self.AZIMUTH_FAN_POINTS):
            angle = 2.0 * math.pi * i / self.AZIMUTH_FAN_POINTS
            x = self.target_center.x + math.cos(angle) * dist
            y = self.target_center.y + math.sin(angle) * dist
            yield self._make_candidate(Vector((x, y, height)))

    def _distance_sweep_candidates(self):
        """Move closer to and farther from target along the start direction."""
        for i in range(self.DISTANCE_SWEEP_POINTS):
            frac = i / max(1, self.DISTANCE_SWEEP_POINTS - 1)
            # Range: 20% to 300% of starting distance
            factor = 0.2 + frac * 2.8
            dist = self._start_distance * factor
            pos = self.target_center - self._start_direction * dist
            # Small angular jitter
            jitter = Vector((
                random.gauss(0, self._scale * 0.1),
                random.gauss(0, self._scale * 0.1),
                random.gauss(0, self._scale * 0.05),
            ))
            yield self._make_candidate(pos + jitter)

    def _random_jump_candidates(self):
        """Lévy-flight random jumps from the current best for long-range
        exploration. Occasionally discovers completely unexpected viewpoints."""
        for _ in range(self.RANDOM_JUMPS):
            # Lévy-distributed step
            u = random.gauss(0, 1)
            v = abs(random.gauss(0, 1))
            levy = u / (v ** (1.0 / 3.0))
            step = levy * self._scale * 0.5
            offset = Vector((
                random.gauss(0, 1) * step,
                random.gauss(0, 1) * step,
                random.gauss(0, 1) * step * 0.5,  # less vertical
            ))
            yield self._make_candidate(self.best_position + offset)

    # --- Geometric scoring (Phase 1 fast path) ---

    def _geo_score_position(self, position):
        """Score a position using vertex reprojection — no render needed."""
        if not self._has_geo:
            return None  # Caller must use render scoring

        import bpy
        from . import camera_utils, cv_scoring

        cam = self._scene.camera
        if cam is None:
            return None

        saved_mat = cam.matrix_world.copy()
        camera_utils.position_camera(cam, position, self.target_center)

        try:
            reproj_score, _ = cv_scoring.vertex_reprojection_score(
                self._scene, self._ref_cam, cam, self._target_obj)
            bbox_score = cv_scoring.bbox_iou_score(
                self._scene, self._ref_cam, cam, self._target_obj)
            geo_rot = cv_scoring.geodesic_rotation_score(
                self._ref_cam.matrix_world.to_quaternion(),
                cam.matrix_world.to_quaternion())
            return 0.50 * reproj_score + 0.20 * bbox_score + 0.30 * geo_rot
        except Exception:
            return None
        finally:
            cam.matrix_world = saved_mat

    # --- Plan builder ---

    def _build_plan(self):
        """Generator yielding (phase_label, position) tuples."""

        # Collect ALL Phase 1 candidates
        all_candidates = []

        generators = [
            ('shells', self._shell_candidates()),
            ('ground', self._ground_sweep_candidates()),
            ('height', self._height_sweep_candidates()),
            ('azimuth', self._azimuth_fan_candidates()),
            ('distance', self._distance_sweep_candidates()),
            ('random', self._random_jump_candidates()),
        ]

        if self._has_geo:
            # Phase 1: Score everything geometrically (no renders)
            for gen_name, gen in generators:
                for pos in gen:
                    geo_score = self._geo_score_position(pos)
                    if geo_score is not None:
                        all_candidates.append((geo_score, pos))

            # Sort and keep top N for render verification
            all_candidates.sort(key=lambda x: x[0], reverse=True)
            top = all_candidates[:self.TOP_AFTER_PHASE1]

            # Update best from Phase 1
            if top:
                self.best_score = top[0][0]
                self.best_position = top[0][1].copy()

            # Phase 1b: Local perturbation around top candidates
            refined = list(top)
            for score, pos in top[:4]:
                for _ in range(15):
                    jitter = Vector((
                        random.gauss(0, self._scale * 0.1),
                        random.gauss(0, self._scale * 0.1),
                        random.gauss(0, self._scale * 0.05),
                    ))
                    ppos = self._make_candidate(pos + jitter)
                    gs = self._geo_score_position(ppos)
                    if gs is not None:
                        refined.append((gs, ppos))

            refined.sort(key=lambda x: x[0], reverse=True)
            render_candidates = refined[:self.TOP_AFTER_PHASE1]

            if render_candidates and render_candidates[0][0] > self.best_score:
                self.best_score = render_candidates[0][0]
                self.best_position = render_candidates[0][1].copy()

            # Phase 2: Render verification of top geometric candidates
            for _, pos in render_candidates:
                yield 'verify', pos

        else:
            # No geometric scoring — all candidates need renders
            for gen_name, gen in generators:
                for pos in gen:
                    yield gen_name, pos

        # Phase 3: Gradient + pattern polish in XYZ space

        # Gradient descent (finite differences along X, Y, Z axes)
        for step in range(self.GRADIENT_STEPS):
            eps = self.FD_EPSILON_START * (0.85 ** step) * self._scale
            bp = self.best_position
            # ±X
            yield 'gradient', self._make_candidate(bp + Vector((eps, 0, 0)))
            yield 'gradient', self._make_candidate(bp + Vector((-eps, 0, 0)))
            # ±Y
            yield 'gradient', self._make_candidate(bp + Vector((0, eps, 0)))
            yield 'gradient', self._make_candidate(bp + Vector((0, -eps, 0)))
            # ±Z
            yield 'gradient', self._make_candidate(bp + Vector((0, 0, eps)))
            yield 'gradient', self._make_candidate(bp + Vector((0, 0, -eps)))

        # Pattern search with adaptive step
        for _ in range(self.PATTERN_STEPS):
            axis = random.choice(('x', 'y', 'z'))
            sign = random.choice((1, -1))
            step = self._pattern_step * self._scale
            bp = self.best_position
            if axis == 'x':
                yield 'polish', self._make_candidate(bp + Vector((sign * step, 0, 0)))
            elif axis == 'y':
                yield 'polish', self._make_candidate(bp + Vector((0, sign * step, 0)))
            else:
                yield 'polish', self._make_candidate(bp + Vector((0, 0, sign * step)))
            self._pattern_step *= 0.93

    def next_candidate(self):
        """Return (phase_label, position_vector) or None."""
        if self.best_score >= self.EARLY_STOP:
            return None
        try:
            return next(self._plan)
        except StopIteration:
            return None

    def report_score(self, position, score):
        """Report a render-based score."""
        self.evaluations_done += 1
        if score > self.best_score:
            self.best_score = score
            self.best_position = Vector(position)
            # Re-expand pattern step on improvement
            self._pattern_step = min(0.3, self._pattern_step * 1.3)
        else:
            self._pattern_step = max(0.01, self._pattern_step * 0.5)

    @property
    def phase1_stats(self):
        return f"Explored 3D space from current camera, best geo: {self.best_score:.1f}%"
