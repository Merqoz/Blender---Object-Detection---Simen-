"""Camera placement and creation helpers.

Two cameras are involved in the game:

- **Player camera**: the active scene camera that the user moves around to try
  to match the reference shot. Created on demand if the scene has none.
- **Reference camera**: a hidden camera the add-on places at a random angle
  around the target object. Used to capture the challenge screenshot, then kept
  around (hidden) so we can score how close the player's pose is to the answer.
"""

import math
import random

import bpy
from mathutils import Vector


REFERENCE_CAMERA_NAME = "PhotoMatch_ReferenceCamera"
PLAYER_CAMERA_NAME = "PhotoMatch_PlayerCamera"


def random_unit_vector(upper_hemisphere=False):
    """Uniformly distributed point on the unit sphere.

    Uses the standard inverse-CDF method: sample cos(theta) uniformly so the
    polar distribution doesn't bunch at the poles. With `upper_hemisphere=True`
    the camera stays above the object's equator (more natural-looking shots).
    """
    phi = random.uniform(0, 2 * math.pi)
    if upper_hemisphere:
        cos_theta = random.uniform(0.05, 1.0)  # avoid pure top-down
    else:
        cos_theta = random.uniform(-1.0, 1.0)
    sin_theta = math.sqrt(1.0 - cos_theta * cos_theta)
    return Vector((
        sin_theta * math.cos(phi),
        sin_theta * math.sin(phi),
        cos_theta,
    ))


def look_at_quaternion(camera_location, target_location):
    """Quaternion orienting a camera at `camera_location` to look at `target_location`.

    Blender cameras look down their local -Z axis with +Y as up.
    """
    direction = target_location - camera_location
    if direction.length < 1e-6:
        direction = Vector((0, 0, -1))
    return direction.to_track_quat('-Z', 'Y')


def remove_existing_reference_camera():
    """Delete any leftover reference camera from a previous challenge."""
    cam_obj = bpy.data.objects.get(REFERENCE_CAMERA_NAME)
    if cam_obj is None:
        return
    cam_data = cam_obj.data if cam_obj.type == 'CAMERA' else None
    for col in list(cam_obj.users_collection):
        col.objects.unlink(cam_obj)
    bpy.data.objects.remove(cam_obj, do_unlink=True)
    if cam_data is not None and cam_data.users == 0:
        bpy.data.cameras.remove(cam_data)


def _copy_camera_settings(target_cam_data, source_cam):
    """Copy lens/sensor settings so the reference cam frames things the same
    way the player will."""
    if source_cam is None or source_cam.type != 'CAMERA':
        return
    src = source_cam.data
    target_cam_data.lens = src.lens
    target_cam_data.sensor_width = src.sensor_width
    target_cam_data.sensor_height = src.sensor_height
    target_cam_data.sensor_fit = src.sensor_fit


def create_reference_camera(scene, location, target_location, mimic_camera=None):
    """Create a hidden camera at `location` aimed at `target_location`.

    Replaces any existing reference camera. Optionally clones lens/sensor
    settings from `mimic_camera` so framing is consistent with the player's cam.
    """
    remove_existing_reference_camera()

    cam_data = bpy.data.cameras.new(REFERENCE_CAMERA_NAME)
    cam_obj = bpy.data.objects.new(REFERENCE_CAMERA_NAME, cam_data)
    _copy_camera_settings(cam_data, mimic_camera)

    cam_obj.location = location
    cam_obj.rotation_mode = 'QUATERNION'
    cam_obj.rotation_quaternion = look_at_quaternion(location, target_location)
    cam_obj.rotation_mode = 'XYZ'  # more conventional for the outliner

    # Hidden in viewport AND render — we don't want it spoiling the game
    cam_obj.hide_viewport = True
    cam_obj.hide_render = True
    cam_obj.hide_select = True

    scene.collection.objects.link(cam_obj)
    return cam_obj


def ensure_player_camera(scene, context):
    """Return the active scene camera, creating one if needed.

    Refuses to use the reference camera as the player camera.
    """
    cam = scene.camera
    if cam is not None and cam.name != REFERENCE_CAMERA_NAME and cam.type == 'CAMERA':
        return cam

    # Look for any non-reference camera already in the scene
    for obj in scene.objects:
        if obj.type == 'CAMERA' and obj.name != REFERENCE_CAMERA_NAME:
            scene.camera = obj
            return obj

    # None found — create one
    cam_data = bpy.data.cameras.new(PLAYER_CAMERA_NAME)
    cam_obj = bpy.data.objects.new(PLAYER_CAMERA_NAME, cam_data)
    scene.collection.objects.link(cam_obj)
    scene.camera = cam_obj
    return cam_obj


def position_camera(cam, location, target_location):
    """Move `cam` to `location` and aim it at `target_location`."""
    cam.location = location
    quat = look_at_quaternion(location, target_location)
    original_mode = cam.rotation_mode
    cam.rotation_mode = 'QUATERNION'
    cam.rotation_quaternion = quat
    cam.rotation_mode = original_mode if original_mode != 'QUATERNION' else 'XYZ'


def tag_redraw_3d_viewports(context=None):
    """Force every 3D viewport to redraw.

    Used after camera-data changes (background image, opacity, transforms)
    so the viewport reflects them immediately. Falls back to `bpy.context`
    when called from places that don't have a context handy (e.g. timers).
    """
    try:
        ctx = context if context is not None else bpy.context
        wm = ctx.window_manager
        if wm is None:
            return
        for window in wm.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass
