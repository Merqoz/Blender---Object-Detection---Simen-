"""Computer-vision scoring metrics inspired by COLMAP and MediaPipe Objectron.

Four geometry-aware metrics that go beyond pixel comparison:

  1. **Vertex reprojection error** (from COLMAP's bundle adjustment)
     Project the target object's mesh vertices through both cameras.
     Measure mean 2D pixel distance. NO RENDER NEEDED — pure math.

  2. **FAST corner + BRIEF descriptor matching** (from ORB-SLAM)
     Detect corners, compute binary descriptors, match via Hamming
     distance with Lowe's ratio test. Score = inlier ratio.

  3. **Geodesic rotation distance** (from Objectron)
     Full quaternion geodesic on SO(3). Captures roll, pitch, yaw
     without gimbal lock.

  4. **Projected bounding box IoU** (from Objectron)
     Project the 3D bounding box through both cameras, compute 2D IoU
     of the convex hulls. Geometry-aware alignment metric.

The vertex reprojection score is the game-changer: it evaluates camera
alignment WITHOUT rendering, using just matrix multiplication. This lets
the search algorithm evaluate thousands of candidates per second.
"""

import math
import numpy as np


# ============================================================================
# 1. Vertex Reprojection Error (COLMAP-style)
# ============================================================================

def _get_object_vertices_world(obj):
    """Get world-space vertex positions from a Blender object.

    Returns an Nx3 numpy array. For non-mesh objects, falls back to
    the 8 bounding-box corners.
    """
    from mathutils import Vector

    if obj.type == 'MESH' and obj.data is not None:
        verts = obj.data.vertices
        mat = obj.matrix_world
        # Sample up to 200 verts for speed (uniform stride)
        n = len(verts)
        stride = max(1, n // 200)
        points = []
        for i in range(0, n, stride):
            world_co = mat @ verts[i].co
            points.append((world_co.x, world_co.y, world_co.z))
        return np.array(points, dtype=np.float64)
    else:
        # Bounding box fallback
        corners = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
        return np.array([(c.x, c.y, c.z) for c in corners], dtype=np.float64)


def _project_points(scene, cam, points_world):
    """Project Nx3 world-space points through a Blender camera.

    Returns Nx2 array of (x, y) in pixel coordinates, plus Nx1 depths.
    Uses bpy_extras for correct lens distortion handling.
    """
    import bpy
    from bpy_extras.object_utils import world_to_camera_view
    from mathutils import Vector

    res_x = scene.render.resolution_x
    res_y = scene.render.resolution_y
    scale = scene.render.resolution_percentage / 100.0

    projected = np.zeros((len(points_world), 2), dtype=np.float64)
    depths = np.zeros(len(points_world), dtype=np.float64)

    for i, (wx, wy, wz) in enumerate(points_world):
        co = world_to_camera_view(scene, cam, Vector((wx, wy, wz)))
        # co.x, co.y are in [0,1] normalized; co.z is depth
        projected[i, 0] = co.x * res_x * scale
        projected[i, 1] = co.y * res_y * scale
        depths[i] = co.z

    return projected, depths


def vertex_reprojection_score(scene, reference_cam, candidate_cam, target_obj):
    """Score 0..100 based on how well projected vertices align between cameras.

    This is the core COLMAP insight: reprojection error directly measures
    geometric alignment. Lower mean pixel distance = higher score.

    Returns 0..100. Also returns the raw mean pixel error for search use.
    NO RENDER NEEDED — this is pure matrix math.
    """
    verts = _get_object_vertices_world(target_obj)
    if len(verts) == 0:
        return 50.0, 999.0

    ref_proj, ref_depths = _project_points(scene, reference_cam, verts)
    cand_proj, cand_depths = _project_points(scene, candidate_cam, verts)

    # Only consider vertices visible to both cameras (positive depth)
    visible = (ref_depths > 0) & (cand_depths > 0)
    if np.sum(visible) < 2:
        return 0.0, 999.0

    ref_visible = ref_proj[visible]
    cand_visible = cand_proj[visible]

    # Mean pixel distance between corresponding projected vertices
    pixel_errors = np.sqrt(np.sum((ref_visible - cand_visible) ** 2, axis=1))
    mean_error = float(np.mean(pixel_errors))

    # Normalize: what counts as "good" depends on resolution.
    # At 256px, a mean error of 5px is excellent; 50px is poor.
    res = max(scene.render.resolution_x, scene.render.resolution_y)
    scale = scene.render.resolution_percentage / 100.0
    effective_res = res * scale
    normalized = mean_error / max(1.0, effective_res * 0.15)  # 15% of res = worst

    # Power curve for discrimination near the optimum
    match = max(0.0, 1.0 - min(1.0, normalized))
    score = (match ** 2.0) * 100.0

    return max(0.0, min(100.0, score)), mean_error


def vertex_reprojection_error_fast(scene, reference_cam, candidate_cam,
                                   target_obj, _cache={}):
    """Fast version that caches the reference projection.

    Returns raw mean pixel error (lower = better). Designed for the search
    algorithm where we need to evaluate thousands of candidates against
    the same reference.
    """
    # Cache key: reference camera + target object
    ref_key = (id(reference_cam), id(target_obj), reference_cam.matrix_world.copy().freeze())
    if ref_key not in _cache:
        verts = _get_object_vertices_world(target_obj)
        ref_proj, ref_depths = _project_points(scene, reference_cam, verts)
        _cache.clear()  # Only keep one entry to bound memory
        _cache[ref_key] = (verts, ref_proj, ref_depths)

    verts, ref_proj, ref_depths = _cache[ref_key]

    cand_proj, cand_depths = _project_points(scene, candidate_cam, verts)
    visible = (ref_depths > 0) & (cand_depths > 0)
    if np.sum(visible) < 2:
        return 999.0

    errors = np.sqrt(np.sum((ref_proj[visible] - cand_proj[visible]) ** 2, axis=1))
    return float(np.mean(errors))


def clear_reprojection_cache():
    """Call when the reference camera or target changes."""
    vertex_reprojection_error_fast.__defaults__[0].clear()


# ============================================================================
# 2. FAST Corner Detection + BRIEF Descriptors (ORB-SLAM-style)
# ============================================================================

# Pre-generated random pixel pair offsets for BRIEF descriptors.
# 256 pairs in a 31x31 patch → 256-bit (32-byte) binary descriptor.
# Generated once at module load with a fixed seed for reproducibility.
_rng = np.random.RandomState(42)
_BRIEF_PAIRS = _rng.randint(-15, 16, size=(256, 4)).astype(np.int32)
# Each row: (dy1, dx1, dy2, dx2) — offsets from keypoint center


def fast_corners(gray, threshold=0.12, n_contiguous=9):
    """Simplified FAST corner detector (pure numpy).

    Checks a ring of 16 pixels at radius 3 around each candidate.
    A pixel is a corner if at least `n_contiguous` ring pixels are
    all brighter (or darker) than center ± threshold.

    Args:
        gray: HxW float32 array in [0, 1]
        threshold: intensity difference threshold
        n_contiguous: minimum contiguous ring pixels (default 9 of 16)

    Returns:
        Nx2 array of (row, col) keypoint positions
    """
    h, w = gray.shape
    if h < 8 or w < 8:
        return np.zeros((0, 2), dtype=np.int32)

    # 16-pixel Bresenham circle at radius 3
    ring_offsets = np.array([
        (-3, 0), (-3, 1), (-2, 2), (-1, 3),
        (0, 3),  (1, 3),  (2, 2),  (3, 1),
        (3, 0),  (3, -1), (2, -2), (1, -3),
        (0, -3), (-1, -3), (-2, -2), (-3, -1),
    ], dtype=np.int32)

    # Work on interior pixels only (skip border of 3)
    pad = 3
    interior = gray[pad:h - pad, pad:w - pad]
    ih, iw = interior.shape

    # Quick pre-filter: check pixels 0, 4, 8, 12 (the 4 cardinal points)
    # At least 3 of 4 must be brighter or darker for the full check to pass
    candidates = np.ones((ih, iw), dtype=bool)
    for check_idx in [0, 4, 8, 12]:
        dy, dx = ring_offsets[check_idx]
        shifted = gray[pad + dy:pad + dy + ih, pad + dx:pad + dx + iw]
        bright = shifted > interior + threshold
        dark = shifted < interior - threshold
        candidates &= (bright | dark)

    # Full check on surviving candidates
    ys, xs = np.nonzero(candidates)
    keypoints = []

    for y, x in zip(ys, xs):
        cy, cx = y + pad, x + pad
        center_val = gray[cy, cx]
        ring_vals = np.array([gray[cy + dy, cx + dx] for dy, dx in ring_offsets])

        bright = ring_vals > center_val + threshold
        dark = ring_vals < center_val - threshold

        # Check contiguous runs (wrap-around: duplicate the ring)
        for test in [bright, dark]:
            doubled = np.concatenate([test, test])
            run = 0
            max_run = 0
            for v in doubled:
                run = run + 1 if v else 0
                max_run = max(max_run, run)
            if max_run >= n_contiguous:
                keypoints.append((cy, cx))
                break

    if not keypoints:
        return np.zeros((0, 2), dtype=np.int32)

    # Non-maximum suppression: simple grid-based (keep strongest per 5x5 cell)
    kp_arr = np.array(keypoints, dtype=np.int32)
    # Corner response = sum of absolute differences with ring
    responses = np.zeros(len(kp_arr))
    for i, (cy, cx) in enumerate(kp_arr):
        center_val = gray[cy, cx]
        ring_vals = np.array([gray[cy + dy, cx + dx] for dy, dx in ring_offsets])
        responses[i] = np.sum(np.abs(ring_vals - center_val))

    # Grid NMS
    cell_size = 5
    grid = {}
    for i, (cy, cx) in enumerate(kp_arr):
        key = (cy // cell_size, cx // cell_size)
        if key not in grid or responses[i] > responses[grid[key]]:
            grid[key] = i

    nms_indices = list(grid.values())
    return kp_arr[nms_indices]


def brief_descriptors(gray, keypoints):
    """Compute 256-bit BRIEF descriptors for each keypoint.

    Args:
        gray: HxW float32 array
        keypoints: Nx2 array of (row, col)

    Returns:
        Nx32 uint8 array (each row is a 256-bit descriptor packed into 32 bytes)
    """
    h, w = gray.shape
    n_kp = len(keypoints)
    if n_kp == 0:
        return np.zeros((0, 32), dtype=np.uint8)

    descriptors = np.zeros((n_kp, 32), dtype=np.uint8)

    for ki in range(n_kp):
        cy, cx = int(keypoints[ki, 0]), int(keypoints[ki, 1])
        bits = np.zeros(256, dtype=np.uint8)

        for bi in range(256):
            dy1, dx1, dy2, dx2 = _BRIEF_PAIRS[bi]
            y1, x1 = cy + dy1, cx + dx1
            y2, x2 = cy + dy2, cx + dx2

            # Clamp to image bounds
            y1 = max(0, min(h - 1, y1))
            x1 = max(0, min(w - 1, x1))
            y2 = max(0, min(h - 1, y2))
            x2 = max(0, min(w - 1, x2))

            bits[bi] = 1 if gray[y1, x1] < gray[y2, x2] else 0

        # Pack 256 bits into 32 bytes
        for byte_i in range(32):
            val = 0
            for bit_i in range(8):
                val |= bits[byte_i * 8 + bit_i] << bit_i
            descriptors[ki, byte_i] = val

    return descriptors


def _hamming_distance(desc1, desc2):
    """Hamming distance between two 32-byte descriptors."""
    xor = np.bitwise_xor(desc1, desc2)
    # Popcount per byte via lookup
    return int(sum(bin(b).count('1') for b in xor))


def match_features(desc1, desc2, ratio_threshold=0.75):
    """Brute-force match descriptors with Lowe's ratio test.

    Returns list of (idx1, idx2, distance) for accepted matches.
    """
    if len(desc1) == 0 or len(desc2) == 0:
        return []

    matches = []
    for i in range(len(desc1)):
        distances = np.array([_hamming_distance(desc1[i], desc2[j])
                              for j in range(len(desc2))])
        sorted_idx = np.argsort(distances)

        if len(sorted_idx) < 2:
            if len(sorted_idx) == 1:
                matches.append((i, sorted_idx[0], distances[sorted_idx[0]]))
            continue

        best = distances[sorted_idx[0]]
        second = distances[sorted_idx[1]]

        # Lowe's ratio test: reject ambiguous matches
        if second > 0 and best / second < ratio_threshold:
            matches.append((i, sorted_idx[0], best))

    return matches


def feature_match_score(ref_gray, rendered_gray, target_size=96):
    """Score 0..100 based on FAST/BRIEF feature matching inlier ratio.

    Detect corners in both images, compute descriptors, match them,
    and return the ratio of good matches to total keypoints as a score.
    """
    from .image_features import resize_nearest

    # Resize to working resolution
    ref = resize_nearest(ref_gray, target_size, target_size).astype(np.float32)
    ren = resize_nearest(rendered_gray, target_size, target_size).astype(np.float32)

    # Detect corners
    kp1 = fast_corners(ref, threshold=0.10)
    kp2 = fast_corners(ren, threshold=0.10)

    if len(kp1) < 3 or len(kp2) < 3:
        return 0.0

    # Compute descriptors
    d1 = brief_descriptors(ref, kp1)
    d2 = brief_descriptors(ren, kp2)

    # Match with ratio test
    good_matches = match_features(d1, d2, ratio_threshold=0.75)

    # Inlier ratio = good matches / min keypoints
    total = min(len(kp1), len(kp2))
    if total == 0:
        return 0.0

    ratio = len(good_matches) / total
    # Power curve for better discrimination
    score = (min(1.0, ratio * 2.0) ** 1.5) * 100.0
    return max(0.0, min(100.0, score))


# ============================================================================
# 3. Geodesic Rotation Distance (Objectron-style)
# ============================================================================

def geodesic_rotation_score(quat1, quat2):
    """Score 0..100 from quaternion geodesic distance on SO(3).

    The geodesic distance is the minimal rotation angle between two
    orientations: angle = 2 * arccos(|q1 · q2|).

    This captures the FULL rotation difference (roll + pitch + yaw)
    unlike forward-vector dot product which ignores roll.

    Args:
        quat1, quat2: Blender Quaternion objects or 4-element arrays

    Returns:
        0..100 where 100 = identical rotation, 0 = opposite
    """
    # Quaternion dot product (absolute value handles double-cover)
    dot = abs(float(
        quat1[0] * quat2[0] +
        quat1[1] * quat2[1] +
        quat1[2] * quat2[2] +
        quat1[3] * quat2[3]
    ))
    dot = min(1.0, dot)  # numerical safety

    # Geodesic angle in radians
    angle_rad = 2.0 * math.acos(dot)
    angle_deg = math.degrees(angle_rad)

    # Map to score: 0° = 100, 90° = 0
    score = max(0.0, 1.0 - angle_deg / 90.0)
    return max(0.0, min(100.0, (score ** 1.5) * 100.0))


# ============================================================================
# 4. Projected Bounding Box IoU (Objectron-style)
# ============================================================================

def _project_bbox_2d(scene, cam, target_obj):
    """Project the object's 3D bounding box into 2D pixel coordinates.

    Returns Nx2 array of projected corner positions.
    """
    import bpy
    from bpy_extras.object_utils import world_to_camera_view
    from mathutils import Vector

    corners_world = [target_obj.matrix_world @ Vector(c)
                     for c in target_obj.bound_box]

    res_x = scene.render.resolution_x
    res_y = scene.render.resolution_y
    scale = scene.render.resolution_percentage / 100.0

    projected = []
    for corner in corners_world:
        co = world_to_camera_view(scene, cam, corner)
        if co.z > 0:  # Only front-facing points
            projected.append((co.x * res_x * scale, co.y * res_y * scale))

    return np.array(projected, dtype=np.float64) if projected else np.zeros((0, 2))


def _convex_hull_area(points):
    """Compute the area of the convex hull of 2D points.

    Uses the gift-wrapping (Jarvis march) algorithm + shoelace formula.
    Pure numpy, no scipy needed.
    """
    if len(points) < 3:
        return 0.0

    # Gift wrapping to find convex hull
    n = len(points)
    hull = []

    # Start from leftmost point
    start = int(np.argmin(points[:, 0]))
    current = start

    for _ in range(n + 1):
        hull.append(current)
        candidate = 0
        for j in range(n):
            if j == current:
                continue
            # Cross product to determine if j is more counter-clockwise
            cross = float(
                (points[j, 0] - points[current, 0]) *
                (points[candidate, 1] - points[current, 1]) -
                (points[j, 1] - points[current, 1]) *
                (points[candidate, 0] - points[current, 0])
            )
            if candidate == current or cross > 0:
                candidate = j
        current = candidate
        if current == start:
            break

    if len(hull) < 3:
        return 0.0

    # Shoelace formula for polygon area
    hull_pts = points[hull]
    n_h = len(hull_pts)
    area = 0.0
    for i in range(n_h):
        j = (i + 1) % n_h
        area += hull_pts[i, 0] * hull_pts[j, 1]
        area -= hull_pts[j, 0] * hull_pts[i, 1]
    return abs(area) / 2.0


def _axis_aligned_iou(pts_a, pts_b):
    """Approximate IoU using axis-aligned bounding boxes of two point sets.

    Much faster than exact convex hull intersection; good enough for scoring.
    """
    if len(pts_a) < 2 or len(pts_b) < 2:
        return 0.0

    # AABB of each set
    a_min = np.min(pts_a, axis=0)
    a_max = np.max(pts_a, axis=0)
    b_min = np.min(pts_b, axis=0)
    b_max = np.max(pts_b, axis=0)

    # Intersection
    inter_min = np.maximum(a_min, b_min)
    inter_max = np.minimum(a_max, b_max)
    inter_size = np.maximum(0.0, inter_max - inter_min)
    inter_area = inter_size[0] * inter_size[1]

    # Union
    a_area = (a_max[0] - a_min[0]) * (a_max[1] - a_min[1])
    b_area = (b_max[0] - b_min[0]) * (b_max[1] - b_min[1])
    union_area = a_area + b_area - inter_area

    if union_area <= 0:
        return 0.0
    return inter_area / union_area


def bbox_iou_score(scene, reference_cam, candidate_cam, target_obj):
    """Score 0..100 from 2D bounding box IoU of projected 3D bbox.

    Projects the target's 3D bounding box through both cameras and
    computes how much the 2D projections overlap.

    NO RENDER NEEDED — pure matrix math.
    """
    ref_pts = _project_bbox_2d(scene, reference_cam, target_obj)
    cand_pts = _project_bbox_2d(scene, candidate_cam, target_obj)

    if len(ref_pts) < 3 or len(cand_pts) < 3:
        return 0.0

    iou = _axis_aligned_iou(ref_pts, cand_pts)
    # Power curve — IoU is already a strict metric, lighten it slightly
    return max(0.0, min(100.0, (iou ** 0.8) * 100.0))


# ============================================================================
# Combined CV Score
# ============================================================================

def cv_combined_score(scene, reference_cam, candidate_cam, target_obj,
                      ref_gray=None, rendered_gray=None):
    """Combine all CV metrics into a single 0..100 score.

    Geometry-only metrics (vertex reproj + bbox IoU + geodesic) don't need
    renders. Feature matching (FAST/BRIEF) needs grayscale images — pass
    them if available, or they'll be skipped.

    Returns dict with individual scores + combined.
    """
    # --- Geometry metrics (no render needed) ---
    reproj_score, reproj_error = vertex_reprojection_score(
        scene, reference_cam, candidate_cam, target_obj)

    bbox_score = bbox_iou_score(
        scene, reference_cam, candidate_cam, target_obj)

    ref_quat = reference_cam.matrix_world.to_quaternion()
    cand_quat = candidate_cam.matrix_world.to_quaternion()
    geo_rot = geodesic_rotation_score(ref_quat, cand_quat)

    # --- Feature matching (needs images) ---
    feat_score = 0.0
    if ref_gray is not None and rendered_gray is not None:
        try:
            feat_score = feature_match_score(ref_gray, rendered_gray)
        except Exception:
            feat_score = 0.0

    # --- Combine with weights ---
    # Vertex reprojection is the strongest signal (direct geometric measure)
    # BBox IoU is a coarse but robust sanity check
    # Geodesic rotation captures the full orientation difference
    # Feature matching adds image-level verification
    if feat_score > 0:
        combined = (
            0.40 * reproj_score +
            0.15 * bbox_score +
            0.20 * geo_rot +
            0.25 * feat_score
        )
    else:
        # No images — geometry only
        combined = (
            0.50 * reproj_score +
            0.20 * bbox_score +
            0.30 * geo_rot
        )

    return {
        'vertex_reprojection': reproj_score,
        'vertex_reproj_error_px': reproj_error,
        'bbox_iou': bbox_score,
        'geodesic_rotation': geo_rot,
        'feature_match': feat_score,
        'cv_combined': max(0.0, min(100.0, combined)),
    }
