"""Camera intrinsics — focal length and sensor dimensions for the player camera.

Useful when the reference image was shot on a phone (or any camera other than
Blender's default 50mm/36mm sensor): aligning a phone photo to a 50mm-equivalent
viewport never looks right because the FOVs don't match. Set the intrinsics here
to mirror the device that took the reference, and the auto-solve / fine-tune
algorithms will be searching in a properly-scaled space.

Three presets cover the common cases (iPhone, Android, Blender default), and
the values can be edited freely afterwards.

When `apply_to_player_camera` is on (default), changes here are immediately
written to the active scene camera (`scene.camera.data.lens`, `sensor_width`,
`sensor_height`). Turn it off to decouple the stored intrinsics from the
camera data — useful for example if you want to keep the Blender camera at
50mm for viewport reasons but still record the phone's intrinsics for some
future use (e.g. Live Phone Feed, coming in v2.7).
"""

import bpy
from bpy.props import FloatProperty, BoolProperty
from bpy.types import Operator, PropertyGroup


# ----------------------------------------------------------------------------
# Update callback
# ----------------------------------------------------------------------------

def _apply_to_player_camera(self, context):
    """Push the current intrinsic values to the active scene camera, if the
    "apply" checkbox is on and there's a real camera to update.

    Wired as the `update=` callback for every editable field on the property
    group, so user edits in the N-panel propagate live into camera-view
    rendering, and a flip of the checkbox from off→on immediately syncs.

    Silently no-ops if there's no active camera or the checkbox is off — the
    user wants the values stored regardless.
    """
    if not self.apply_to_player_camera:
        return
    cam_obj = context.scene.camera
    if cam_obj is None or cam_obj.type != 'CAMERA':
        return
    cam_data = cam_obj.data
    cam_data.lens = self.focal_length_mm
    cam_data.sensor_width = self.sensor_width_mm
    cam_data.sensor_height = self.sensor_height_mm


# ----------------------------------------------------------------------------
# Property group
# ----------------------------------------------------------------------------

class PhotoMatchCameraIntrinsics(PropertyGroup):
    """Stored intrinsics for the player camera. Mirrored to scene.camera while
    `apply_to_player_camera` is on."""

    focal_length_mm: FloatProperty(
        name="Focal Length",
        description="Physical focal length in millimeters. NOT the 35mm "
                    "equivalent — for a phone's '26mm equivalent' main lens, "
                    "the physical focal length is around 4mm. Use the presets "
                    "if you want equivalent-FOV numbers without the math",
        default=50.0, min=1.0, max=300.0, soft_max=200.0,
        unit='CAMERA',
        update=_apply_to_player_camera,
    )
    sensor_width_mm: FloatProperty(
        name="Sensor Width",
        description="Physical sensor width in millimeters. Full-frame is 36mm; "
                    "phone main sensors are typically 5–8mm wide",
        default=36.0, min=0.5, max=100.0, soft_max=50.0,
        unit='CAMERA',
        update=_apply_to_player_camera,
    )
    sensor_height_mm: FloatProperty(
        name="Sensor Height",
        description="Physical sensor height in millimeters. Full-frame is 24mm; "
                    "phone main sensors are typically 4:3 aspect, so ~75% of width",
        default=24.0, min=0.5, max=100.0, soft_max=50.0,
        unit='CAMERA',
        update=_apply_to_player_camera,
    )
    apply_to_player_camera: BoolProperty(
        name="Apply to Player Camera",
        description="When on, edits and presets immediately update the active "
                    "scene camera. When off, intrinsics are stored on the "
                    "addon but the Blender camera is left alone",
        default=True,
        update=_apply_to_player_camera,
    )


# ----------------------------------------------------------------------------
# Preset operators
# ----------------------------------------------------------------------------
#
# The values below are chosen so that Blender's lens/sensor-width FOV formula
# reproduces each device's published 35mm-equivalent FOV. Sensor heights are
# 4:3 for phones (matching their main-camera native aspect) and 3:2 for the
# full-frame default.
#
# To convert a 35mm-equivalent focal length F_eq to a physical focal length F
# at sensor width W_sensor:    F = F_eq * (W_sensor / 36)
#

class PHOTOMATCH_OT_PresetIPhoneMain(Operator):
    """iPhone main camera — 26mm full-frame-equivalent FOV"""
    bl_idname = "photomatch.preset_iphone_main"
    bl_label = "iPhone Main"
    bl_description = "Set intrinsics to an iPhone main lens (26mm equiv, 4:3)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        intr = context.scene.photo_match_props.intrinsics
        # 26mm-equiv on a 5.7mm-wide 4:3 sensor → ~4.12mm physical lens.
        intr.sensor_width_mm = 5.7
        intr.sensor_height_mm = 4.28
        intr.focal_length_mm = 4.12
        return {'FINISHED'}


class PHOTOMATCH_OT_PresetAndroidGeneric(Operator):
    """Generic Android main camera — 24mm full-frame-equivalent FOV"""
    bl_idname = "photomatch.preset_android_generic"
    bl_label = "Android Generic"
    bl_description = "Set intrinsics to a typical Android main lens (24mm equiv, 4:3)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        intr = context.scene.photo_match_props.intrinsics
        # 24mm-equiv on a 5.4mm-wide 4:3 sensor → ~3.6mm physical lens.
        intr.sensor_width_mm = 5.4
        intr.sensor_height_mm = 4.05
        intr.focal_length_mm = 3.6
        return {'FINISHED'}


class PHOTOMATCH_OT_PresetBlenderDefault(Operator):
    """Blender's default 50mm full-frame camera"""
    bl_idname = "photomatch.preset_blender_default"
    bl_label = "Blender Default"
    bl_description = "Reset to Blender's default 50mm full-frame camera (3:2)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        intr = context.scene.photo_match_props.intrinsics
        intr.sensor_width_mm = 36.0
        intr.sensor_height_mm = 24.0
        intr.focal_length_mm = 50.0
        return {'FINISHED'}


# ----------------------------------------------------------------------------
# Registration
# ----------------------------------------------------------------------------

# PropertyGroup must come first — properties.py references
# PhotoMatchCameraIntrinsics in a PointerProperty, which requires the class to
# already be registered when properties.py is registered.

classes = (
    PhotoMatchCameraIntrinsics,
    PHOTOMATCH_OT_PresetIPhoneMain,
    PHOTOMATCH_OT_PresetAndroidGeneric,
    PHOTOMATCH_OT_PresetBlenderDefault,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
