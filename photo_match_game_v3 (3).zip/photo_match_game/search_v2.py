"""Camera search v2 — warm-start + PID gradient descent + pattern-search fallback.

Goals over v1 (`search.py`):

  - **Warm-start from current camera.** v1 always runs an 18-sample Fibonacci
    coarse sweep, even when the camera is already close. That's wasteful when
    the user has hand-aligned roughly. v2 starts with a tight Gaussian shell
    around the current pose and only escalates to a full sphere sweep if the
    local search comes back empty.

  - **PID-controlled gradient descent.** Once we've found a good basin, v1
    just keeps shrinking the perturbation size and hopes for the best. v2
    estimates ∂score/∂param via finite differences and steps along the
    gradient with a PID controller:
        P — current gradient (immediate response)
        I — accumulator (persistent push out of plateaus, decayed each step)
        D — change in gradient (dampens oscillation near the optimum)
    This converges much faster and more reliably than blind perturbation.

  - **Pattern search fallback.** When the gradient signal goes noisy (small
    parameter changes don't change score reliably — usually means we're near
    the optimum), v2 switches to Hooke-Jeeves pattern search: try ±step on
    each axis, expand the step on success, contract on failure. Robust when
    gradients are unreliable.

The 3 parameters are the same as v1: spherical (theta, phi) for direction
plus distance. Camera always points at the target center.
"""

import math
import random

from mathutils import Vector


# ----------------------------------------------------------------------------
# Coordinate conversions
# ----------------------------------------------------------------------------

def direction_to_spherical(direction):
    """Cartesian unit vector → (theta, phi).

    theta: polar angle from +Z axis, in [0, π]
    phi:   azimuthal angle around Z, in (-π, π]
    """
    direction = Vector(direction).normalized()
    z = max(-1.0, min(1.0, direction.z))
    theta = math.acos(z)
    phi = math.atan2(direction.y, direction.x)
    return theta, phi


def spherical_to_direction(theta, phi):
    """(theta, phi) → Cartesian unit vector."""
    sin_theta = math.sin(theta)
    return Vector((
        sin_theta * math.cos(phi),
        sin_theta * math.sin(phi),
        math.cos(theta),
    ))


def clamp_theta(theta, upper_hemisphere):
    """Keep theta in valid range. With upper_hemisphere, also keep above the
    equator-plus-a-hair so the camera doesn't end up underground-ish."""
    if upper_hemisphere:
        # theta=0 is +Z, theta=π/2 is equator. Cap a bit below the equator.
        return max(0.01, min(math.pi * 0.5 - 0.05, theta))
    return max(0.01, min(math.pi - 0.01, theta))


def wrap_phi(phi):
    """Wrap phi into (-π, π]."""
    return ((phi + math.pi) % (2.0 * math.pi)) - math.pi


# ----------------------------------------------------------------------------
# Sampling primitives
# ----------------------------------------------------------------------------

_GOLDEN_ANGLE = math.pi * (3.0 - math.sqrt(5.0))


def fibonacci_sphere(n, upper_hemisphere=False):
    """Return `n` evenly distributed points on the unit sphere."""
    points = []
    for i in range(n):
        if upper_hemisphere:
            z = 0.05 + (i / max(1, n - 1)) * 0.95
        else:
            z = 1.0 - (i / max(1, n - 1)) * 2.0
        radius = math.sqrt(max(0.0, 1.0 - z * z))
        theta = _GOLDEN_ANGLE * i
        points.append(Vector((
            math.cos(theta) * radius,
            math.sin(theta) * radius,
            z,
        )))
    return points


# ----------------------------------------------------------------------------
# PID controller for parameter updates
# ----------------------------------------------------------------------------

class PIDController3D:
    """3D PID controller — one parameter triple (theta, phi, distance).

    Standard discrete-time PID:
        output = Kp * error
               + Ki * integral_of_error
               + Kd * (error - prev_error)

    The "error" here is the *gradient* of score with respect to params (we
    want to *increase* score, so we step in the +gradient direction). The
    integral accumulates persistent pushes — useful for crawling out of
    plateaus. The derivative term dampens oscillation as we approach the
    optimum and the gradient flips sign.

    Tuning: Kp dominates early (large gradient → big steps). Ki kicks in on
    plateaus where Kp alone gives a small but consistent push. Kd activates
    near the optimum where gradient noise causes overshooting.
    """

    def __init__(self, kp=0.6, ki=0.05, kd=0.25, integral_decay=0.9):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.integral_decay = integral_decay  # forget old accumulation slowly
        self.integral = [0.0, 0.0, 0.0]
        self.prev_error = [0.0, 0.0, 0.0]

    def step(self, error):
        """Return a 3-element control output for the given error vector."""
        # Decay the integrator before adding new error — this prevents
        # integrator wind-up on long runs.
        self.integral = [i * self.integral_decay + e for i, e in zip(self.integral, error)]
        derivative = [e - p for e, p in zip(error, self.prev_error)]
        output = [
            self.kp * e + self.ki * i + self.kd * d
            for e, i, d in zip(error, self.integral, derivative)
        ]
        self.prev_error = list(error)
        return output

    def reset(self):
        self.integral = [0.0, 0.0, 0.0]
        self.prev_error = [0.0, 0.0, 0.0]


# ----------------------------------------------------------------------------
# Search state machine
# ----------------------------------------------------------------------------

class CameraSolveStateV2:
    """Camera-pose search with warm-start + PID gradient descent + pattern fallback.

    Usage:
        state = CameraSolveStateV2(target_center, current_dir, current_dist,
                                    upper_hemisphere=True)
        while True:
            cand = state.next_candidate()
            if cand is None:
                break
            phase, direction, distance = cand
            # ... position camera, render, score ...
            state.report_score(direction, distance, score)

    Algorithm overview (the state machine drives this; each phase yields
    candidates, and `report_score` decides whether to advance phase):

        Phase 1 — local warm-start (8 tight Gaussian samples around start)
        Phase 2 — global fallback (24-sample Fibonacci, only if Phase 1 weak)
        Phase 3 — PID gradient descent (~20 candidates: 6 finite diffs + steps)
        Phase 4 — pattern search polish (~12 candidates with adaptive step)

    The total budget is comparable to v1 (~50-65 candidates) but converges
    faster on warm starts and more reliably on cold starts.
    """

    # --- Phase tuning ---
    LOCAL_SAMPLES = 8
    LOCAL_SIGMA_DIR = 0.35       # ~20° angular spread initially
    LOCAL_SIGMA_DIST = 0.25      # ±25% distance variation

    GLOBAL_SAMPLES = 24
    LOCAL_PHASE_THRESHOLD = 60.0  # if local best < this, run global fallback

    GRADIENT_STEPS = 6
    FD_EPSILON_THETA = 0.08
    FD_EPSILON_PHI = 0.08
    FD_EPSILON_DIST_REL = 0.06   # 6% of current distance
    GRADIENT_GAIN = 0.08         # base gain on top of PID; small to avoid overshoot

    PATTERN_STEPS = 12
    PATTERN_INITIAL_STEP = 0.05
    PATTERN_EXPAND_FACTOR = 1.4
    PATTERN_CONTRACT_FACTOR = 0.5

    EARLY_STOP_SCORE = 98.0  # stricter threshold matches the stricter scorer

    def __init__(self, target_center, start_direction, start_distance,
                 upper_hemisphere=True):
        self.target_center = Vector(target_center)
        self.upper_hemisphere = upper_hemisphere

        start_direction = Vector(start_direction).normalized()
        start_theta, start_phi = direction_to_spherical(start_direction)
        self.theta = clamp_theta(start_theta, upper_hemisphere)
        self.phi = wrap_phi(start_phi)
        self.distance = max(float(start_distance), 0.1)

        self.best_theta = self.theta
        self.best_phi = self.phi
        self.best_distance = self.distance
        self.best_score = -1.0

        self.evaluations_done = 0
        self._pid = PIDController3D()
        self._gradient_buffer = {}  # holds finite-diff probes mid-step
        self._pattern_step = self.PATTERN_INITIAL_STEP
        self._plan = self._build_plan()

    @property
    def total_evaluations_planned(self):
        # Upper bound — phase 2 is conditional, phase 4 may stop early
        return (
            self.LOCAL_SAMPLES
            + self.GLOBAL_SAMPLES
            + self.GRADIENT_STEPS * 7  # 6 probes + 1 step per iteration
            + self.PATTERN_STEPS
        )

    @property
    def best_direction(self):
        return spherical_to_direction(self.best_theta, self.best_phi)

    # ------------------------------------------------------------------
    # Plan generator — yields ('phase_label', direction_vec, distance_float)
    # ------------------------------------------------------------------

    def _build_plan(self):
        # --- Phase 1: Local warm-start ---
        # Tight Gaussian shell around the current camera pose.
        for _ in range(self.LOCAL_SAMPLES):
            d_theta = random.gauss(0, self.LOCAL_SIGMA_DIR)
            d_phi = random.gauss(0, self.LOCAL_SIGMA_DIR)
            d_dist_rel = random.gauss(0, self.LOCAL_SIGMA_DIST)
            theta = clamp_theta(self.theta + d_theta, self.upper_hemisphere)
            phi = wrap_phi(self.phi + d_phi)
            dist = self.distance * max(0.3, 1.0 + d_dist_rel)
            yield 'local', spherical_to_direction(theta, phi), dist

        # --- Phase 2: Global fallback (only if local was weak) ---
        if self.best_score < self.LOCAL_PHASE_THRESHOLD:
            for direction in fibonacci_sphere(
                self.GLOBAL_SAMPLES, self.upper_hemisphere
            ):
                yield 'global', direction, self.best_distance

        # --- Phase 3: PID gradient descent ---
        # Each iteration: 6 finite-diff probes (±θ, ±φ, ±d) + 1 step.
        for it in range(self.GRADIENT_STEPS):
            probes = self._fd_probes(self.best_theta, self.best_phi, self.best_distance)
            self._gradient_buffer = {'probes': probes, 'scores': {}, 'iter': it}
            for key, (theta, phi, dist) in probes.items():
                yield ('gradient_probe', spherical_to_direction(theta, phi), dist)
            # After the 6 probes, report_score will have populated _gradient_buffer.
            # We compute the gradient and the PID-adjusted step lazily — yield
            # placeholder None and let next_candidate intercept.
            yield ('gradient_step', None, None)

        # --- Phase 4: Pattern search polish ---
        for _ in range(self.PATTERN_STEPS):
            yield ('pattern', None, None)

    def _fd_probes(self, theta, phi, dist):
        """Build the 6 finite-difference probes around (theta, phi, dist)."""
        eps_d = max(self.FD_EPSILON_DIST_REL * dist, 0.05)
        return {
            'theta+': (clamp_theta(theta + self.FD_EPSILON_THETA, self.upper_hemisphere), phi, dist),
            'theta-': (clamp_theta(theta - self.FD_EPSILON_THETA, self.upper_hemisphere), phi, dist),
            'phi+':   (theta, wrap_phi(phi + self.FD_EPSILON_PHI), dist),
            'phi-':   (theta, wrap_phi(phi - self.FD_EPSILON_PHI), dist),
            'dist+':  (theta, phi, max(0.1, dist + eps_d)),
            'dist-':  (theta, phi, max(0.1, dist - eps_d)),
        }

    # ------------------------------------------------------------------
    # Iteration interface
    # ------------------------------------------------------------------

    def next_candidate(self):
        """Pull the next candidate from the plan, intercepting the special
        gradient_step and pattern markers to compute them on the fly."""
        if self.best_score >= self.EARLY_STOP_SCORE:
            return None

        try:
            phase, direction, distance = next(self._plan)
        except StopIteration:
            return None

        if phase == 'gradient_step':
            return self._make_gradient_step()
        if phase == 'pattern':
            return self._make_pattern_step()
        return phase, direction, distance

    def _make_gradient_step(self):
        """Apply the PID-controlled step using the probe scores in the buffer."""
        scores = self._gradient_buffer.get('scores', {})
        probes = self._gradient_buffer.get('probes', {})
        if len(scores) < 6:
            # Some probes missing — bail by yielding the current best
            return ('gradient_step',
                    spherical_to_direction(self.best_theta, self.best_phi),
                    self.best_distance)

        # Symmetric finite differences → gradient of score w.r.t. each param
        eps_d = max(self.FD_EPSILON_DIST_REL * self.best_distance, 0.05)
        grad_theta = (scores['theta+'] - scores['theta-']) / (2 * self.FD_EPSILON_THETA)
        grad_phi   = (scores['phi+']   - scores['phi-'])   / (2 * self.FD_EPSILON_PHI)
        grad_dist  = (scores['dist+']  - scores['dist-'])  / (2 * eps_d)

        # PID-adjusted step in each parameter
        pid_out = self._pid.step([grad_theta, grad_phi, grad_dist])
        step_theta = self.GRADIENT_GAIN * pid_out[0]
        step_phi   = self.GRADIENT_GAIN * pid_out[1]
        step_dist  = self.GRADIENT_GAIN * pid_out[2] * 0.1  # distance lives on a different scale

        # Clip to reasonable per-step magnitudes — the PID can demand large jumps
        # when integral wind-up is large; clipping makes the search more stable.
        step_theta = max(-0.4, min(0.4, step_theta))
        step_phi   = max(-0.4, min(0.4, step_phi))
        step_dist  = max(-0.3 * self.best_distance, min(0.3 * self.best_distance, step_dist))

        new_theta = clamp_theta(self.best_theta + step_theta, self.upper_hemisphere)
        new_phi = wrap_phi(self.best_phi + step_phi)
        new_dist = max(0.1, self.best_distance + step_dist)

        return ('gradient_step', spherical_to_direction(new_theta, new_phi), new_dist)

    def _make_pattern_step(self):
        """Hooke-Jeeves: try ±step on a random axis. report_score adapts the step."""
        axis = random.choice(('theta', 'phi', 'dist'))
        sign = random.choice((1, -1))
        step = self._pattern_step

        if axis == 'theta':
            theta = clamp_theta(self.best_theta + sign * step, self.upper_hemisphere)
            phi, dist = self.best_phi, self.best_distance
        elif axis == 'phi':
            theta, dist = self.best_theta, self.best_distance
            phi = wrap_phi(self.best_phi + sign * step)
        else:
            theta, phi = self.best_theta, self.best_phi
            dist = max(0.1, self.best_distance * (1.0 + sign * step))

        return ('pattern', spherical_to_direction(theta, phi), dist)

    def report_score(self, direction, distance, score):
        """Feed back the score for the most recent candidate.

        We don't get told which phase the candidate was from — we infer it
        from the gradient buffer state. This keeps the iteration interface
        simple for the caller.
        """
        self.evaluations_done += 1

        # If a gradient probe set is in progress, route the score to the buffer
        if self._gradient_buffer.get('probes') and \
                len(self._gradient_buffer.get('scores', {})) < 6:
            scores = self._gradient_buffer.setdefault('scores', {})
            # Match this candidate to one of the probes by coordinate (cheapest:
            # try each key and compare direction+distance approximately)
            target_dir = Vector(direction).normalized()
            target_dist = float(distance)
            best_key = None
            best_match = float('inf')
            for key, (theta, phi, dist) in self._gradient_buffer['probes'].items():
                if key in scores:
                    continue
                probe_dir = spherical_to_direction(theta, phi)
                err = (probe_dir - target_dir).length + abs(dist - target_dist) * 0.1
                if err < best_match:
                    best_match = err
                    best_key = key
            if best_key is not None:
                scores[best_key] = score

        # Update best-so-far
        improved = score > self.best_score
        if improved:
            self.best_score = score
            theta, phi = direction_to_spherical(direction)
            self.best_theta = clamp_theta(theta, self.upper_hemisphere)
            self.best_phi = wrap_phi(phi)
            self.best_distance = float(distance)

        # Adapt pattern-search step size on success/failure
        if self._gradient_buffer.get('iter') is None:
            # Heuristic: if recent eval improved best, expand; else contract.
            # Pattern phase only — but cheap to apply throughout; stays bounded.
            if improved:
                self._pattern_step *= self.PATTERN_EXPAND_FACTOR
            else:
                self._pattern_step *= self.PATTERN_CONTRACT_FACTOR
            self._pattern_step = max(0.005, min(0.3, self._pattern_step))
