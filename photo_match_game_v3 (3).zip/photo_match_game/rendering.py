"""Rendering helpers.

Both the challenge capture and the score capture go through `render_camera_to_path`,
which:
  1. Temporarily makes the requested cam the active scene camera
  2. Hides any background image pinned to that cam (so the overlay can't
     contaminate the render)
  3. Optionally forces a specific viewport shading mode (SOLID, MATERIAL,
     RENDERED) so the capture matches what the user sees
  4. Triggers an OpenGL render to a PNG
  5. Restores everything

The shading mode matters because `bpy.ops.render.opengl()` renders using
whatever shading the 3D viewport is set to. In Solid mode, materials are
invisible. In Material Preview, textures/colors/roughness appear. In
Rendered mode, the full Eevee/Cycles preview is captured.

By explicitly setting the shading before every render, both the reference
challenge image and every auto-solve evaluation see the same materials and
lighting — the comparison is always apples-to-apples.
"""

import bpy


# Valid Blender viewport shading types
_SHADING_TYPES = {'WIREFRAME', 'SOLID', 'MATERIAL', 'RENDERED'}


def _find_3d_viewport():
    """Return the first VIEW_3D SpaceView3D, or None."""
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    return space
    return None


def render_camera_to_path(scene, cam, output_path, shading_mode=None):
    """OpenGL-render from `cam` to `output_path` (PNG) without any overlay.

    Args:
        scene: bpy.types.Scene
        cam: bpy.types.Object (camera) to render from
        output_path: file path for the PNG output
        shading_mode: one of 'SOLID', 'MATERIAL', 'RENDERED', 'WIREFRAME',
                      or None. When None (or 'VIEWPORT'), the current
                      viewport shading is left untouched — whatever you
                      see is what gets captured. When set, the viewport
                      shading is temporarily forced to that mode and
                      restored after the render.
    """
    saved = {
        'filepath': scene.render.filepath,
        'format': scene.render.image_settings.file_format,
        'active_cam': scene.camera,
        'bg_visible': cam.data.show_background_images,
        'cam_hidden': cam.hide_viewport,
    }

    # Find the 3D viewport and optionally force its shading mode
    space = _find_3d_viewport()
    saved_shading = None
    if (space is not None
            and shading_mode is not None
            and shading_mode in _SHADING_TYPES):
        saved_shading = space.shading.type
        space.shading.type = shading_mode

    # render.opengl(view_context=False) renders from scene.camera, so swap in
    # the cam we actually want to capture from.
    scene.camera = cam
    cam.hide_viewport = False  # has to be visible to be the active scene cam
    cam.data.show_background_images = False
    scene.render.filepath = output_path
    scene.render.image_settings.file_format = 'PNG'

    try:
        bpy.ops.render.opengl(write_still=True, view_context=False)
    finally:
        scene.render.filepath = saved['filepath']
        scene.render.image_settings.file_format = saved['format']
        cam.data.show_background_images = saved['bg_visible']
        cam.hide_viewport = saved['cam_hidden']
        scene.camera = saved['active_cam']

        # Restore viewport shading
        if saved_shading is not None and space is not None:
            space.shading.type = saved_shading


def setup_camera_background(scene, cam, img, opacity):
    """Pin `img` as a semi-transparent overlay on the camera and resize the
    render output to match the image's aspect ratio.

    Defensive ordering: enable show_background_images both before and after
    creating the new background entry. Some users have reported the checkbox
    being unchecked after this function runs; the redundant set is cheap and
    rules out any save/restore issue from elsewhere flipping it.
    """
    # Defensive: enable once before mutating the list (some Blender builds
    # auto-disable the toggle when the list goes empty)
    cam.data.show_background_images = True
    cam.data.background_images.clear()

    bg = cam.data.background_images.new()
    bg.image = img
    bg.alpha = opacity
    bg.display_depth = 'FRONT'
    bg.frame_method = 'FIT'
    bg.show_background_image = True  # per-entry visibility flag

    # Defensive: re-enable after mutation, in case clear() or new() side-effects
    # toggled the camera-level flag
    cam.data.show_background_images = True

    img_w, img_h = img.size
    if img_w > 0 and img_h > 0:
        max_dim = 1280  # cap so big reference images don't slow scoring renders
        scale = min(1.0, max_dim / max(img_w, img_h))
        scene.render.resolution_x = max(2, int(img_w * scale))
        scene.render.resolution_y = max(2, int(img_h * scale))
        scene.render.resolution_percentage = 100
