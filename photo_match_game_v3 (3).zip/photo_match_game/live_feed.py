"""Live phone-camera feed over the local network.

This module is the bridge between the user's phone and the photo_match_game
addon. The phone connects over HTTPS, opens a small HTML page served by this
module, and POSTs JPEG frames to `/frame` ~15 times per second. A Blender
timer drains the latest frame, decodes it, and writes it into a Blender
image data-block so the camera background can show what the phone is seeing.

────────────────────────────────────────────────────────────────────────────
v2.8.4 (post-rewrite): transport swapped from WebSocket to plain HTTP POST.

The previous version implemented its own pure-Python WebSocket handshake +
framing to push JPEGs phone→host. That works but it's a lot of moving parts
for what is, end-to-end, a one-way binary stream. The phone_camera_stream
addon takes the much simpler approach of POSTing each JPEG as the body of
an HTTPS request; a single slot on the host hands frames off to the main
thread. We've adopted that architecture here.

What stays the same — the *integration surface* the rest of the addon talks
to is unchanged so live_tracking.py, operators.py, properties.py and ui.py
keep working without edits:

  * Constants:
      LIVE_FEED_IMAGE_NAME    — bpy.data.images slot that receives frames
      OVERLAY_IMAGE_NAME       — transparent-scene render layered on top
      LIVE_FEED_CAMERA_NAME    — auto-created camera object name

  * Lifecycle:
      is_running()             — bool, true while server thread is alive
      start_server()           — returns (ok, ServerState | error_message)
      stop_server()            — idempotent teardown; also stops tracking

  * Cross-thread frame slot (read under _frame_lock):
      _latest_frame            — bytes, raw JPEG payload of newest frame
      _latest_frame_seq        — monotonic counter; live_tracking uses this
                                 to no-op when no new frame has arrived
      _latest_frame_at         — time.monotonic() the frame landed
      _decode_jpeg_to_rgb()    — PIL-backed JPEG → (w, h, np.uint8 RGB)

  * Operators:
      photomatch.start_live_feed / photomatch.stop_live_feed

  * Auto-camera & overlay:
      ensure_live_feed_camera() and the 1 Hz `_overlay_render_tick` that
      renders the Blender scene with a transparent film and layers it on
      top of the live feed in the camera's background-images list.

What's different — internals only:

  * HTTPS server now uses `socketserver.ThreadingMixIn` with a single
    `_Handler.do_POST` for `/frame` and `_Handler.do_GET` for `/`. No
    WebSocket handshake, no per-connection long-lived thread.
  * SSL cert generation prefers `cryptography` and runs synchronously in
    `start_server`. The old `openssl` shell-out fallback is dropped —
    Blender ships `cryptography` and the openssl path was never the
    primary route.
  * Dependencies (`qrcode[pil]`, `Pillow`, `cryptography`) are auto-pip-
    installed in a background thread at register-time, mirroring the
    phone_camera_stream UX. Start operator falls back to a synchronous
    install if the background install hasn't finished.
  * Phone-side HTML page is the cleaner phone_camera_stream version
    (start/stop/switch-cam buttons, no WebSocket plumbing).

Threading rules (unchanged):
  * `bpy.data` mutation: main thread only, via the display timer.
  * HTTP handler threads: only touch the `_frame_lock`-protected slot and
    the connection counter. Never `bpy.*`.
  * Server thread: only runs serve_forever(); per-request threads are
    spawned by ThreadingMixIn.
"""

import datetime
import importlib
import io
import ipaddress
import math
import os
import socket
import socketserver
import ssl
import subprocess
import sys
import tempfile
import threading
import time
import http.server

# bpy and PIL imports are guarded — this module imports cleanly without them
# so the network/cert primitives can be unit-tested headless.
try:
    import bpy
    from bpy.types import Operator
    _HAS_BPY = True
except ImportError:
    _HAS_BPY = False
    bpy = None  # type: ignore
    Operator = object  # type: ignore


# ----------------------------------------------------------------------------
# Constants
# ----------------------------------------------------------------------------

# Display rate. 5 Hz is documented in handoff Part 3 — feels smooth in the
# viewport without burning CPU on JPEG decode. Phone sends ~15 fps; we
# downsample on the host so render impact stays bounded.
DISPLAY_HZ = 5.0
DISPLAY_INTERVAL = 1.0 / DISPLAY_HZ

# Image data-block name that frames are written to. Camera background slot
# references this image by name, so renaming would break the auto-wire path.
LIVE_FEED_IMAGE_NAME = "photomatch_live_feed"

# v2.8.1 overlay: Blender scene rendered with transparent film, layered on
# top of the live feed in the camera background slots.
OVERLAY_IMAGE_NAME = "photomatch_overlay"
LIVE_FEED_CAMERA_NAME = "PhotoMatch_LiveCam"
OVERLAY_INTERVAL_SECONDS = 1.0
# Render resolution for the overlay. Smaller = faster renders, less impact
# on UI responsiveness. 512px is a sweet spot — visible enough to read the
# alignment, fast enough that 1Hz cadence isn't disruptive.
OVERLAY_RENDER_LONG_EDGE = 512

# Port search starts here. 8443 is HTTPS-alt and avoids needing root.
DEFAULT_PORT_START = 8443

# Cert validity (days). One year is plenty — these are LAN-only certs.
CERT_VALIDITY_DAYS = 365

# After this many seconds without a frame, we consider the phone "disconnected"
# even if no connection-close has arrived (e.g. phone in pocket, tab paused).
PHONE_STALE_SECONDS = 2.0


# ----------------------------------------------------------------------------
# Module-level state
# ----------------------------------------------------------------------------
#
# Cross-thread frame slot. Two locks rather than one big lock so the HTTP
# handler thread doesn't fight the connection-counter update path.

_frame_lock = threading.Lock()
_latest_frame = None        # bytes — raw JPEG payload of newest received frame
_latest_frame_at = 0.0      # time.monotonic() the frame landed
_latest_frame_seq = 0       # monotonic counter; live_tracking reads this
                            # to skip work when nothing new has arrived

_state_lock = threading.Lock()
_phone_connection_count = 0  # bumped on /frame POST, decayed by staleness


class _ServerState:
    """Container for the live HTTPS server thread + metadata.

    A `None` global means "not running"; an instance means running. Using
    sentinel-by-existence rather than a `running` bool removes a class of
    "started but no thread" inconsistency bugs.
    """
    def __init__(self, server, thread, ip, port, cert_path, key_path,
                 url, qr_image_name):
        self.server = server          # ThreadingHTTPServer (SSL-wrapped)
        self.thread = thread          # serve_forever() thread
        self.ip = ip
        self.port = port
        self.cert_path = cert_path
        self.key_path = key_path
        self.url = url
        self.qr_image_name = qr_image_name


_server_state = None             # _ServerState | None
_display_timer_registered = False
_install_thread = None           # background dependency installer


# ----------------------------------------------------------------------------
# Dependency auto-install (qrcode, Pillow, cryptography)
# ----------------------------------------------------------------------------
#
# Borrowed verbatim from phone_camera_stream.py. The reasoning: end users
# install the addon by dropping a zip into Blender's preferences, they don't
# `pip install` anything themselves. We auto-install in a background thread
# at register() so addon-enable isn't blocked. The Start operator retries
# synchronously if needed.

_REQUIRED_DEPS = [
    ("qrcode[pil]",  "qrcode"),
    ("Pillow",       "PIL"),
    ("cryptography", "cryptography"),
]


def _deps_installed() -> bool:
    for _, mod in _REQUIRED_DEPS:
        try:
            importlib.import_module(mod)
        except ImportError:
            return False
    return True


def _install_deps():
    """Synchronously install any missing dependencies into Blender's Python.

    Uses Blender's bundled pip (via `python -m pip`). Three steps:
      1. `ensurepip` — bootstraps pip if it isn't installed yet (some
         Blender distros ship without it).
      2. `pip install --upgrade pip` — older pip can choke on modern wheels.
      3. `pip install <missing>` — only the packages whose import failed.
    Failures in steps 1+2 are swallowed; only step 3 matters and it raises.
    """
    py = sys.executable
    try:
        subprocess.check_call([py, "-m", "ensurepip", "--upgrade"])
    except Exception:
        pass
    try:
        subprocess.check_call([py, "-m", "pip", "install", "--upgrade", "pip"])
    except Exception:
        pass
    missing = [pkg for pkg, mod in _REQUIRED_DEPS
               if importlib.util.find_spec(mod) is None]
    if missing:
        subprocess.check_call([py, "-m", "pip", "install", *missing])
    # Make freshly installed packages findable without restarting Blender
    importlib.invalidate_caches()


def _background_install():
    """Install missing deps without blocking the main thread."""
    try:
        if _deps_installed():
            return
        print("[photomatch.live_feed] installing required Python packages "
              "(qrcode[pil], Pillow, cryptography)...", flush=True)
        _install_deps()
        if _deps_installed():
            print("[photomatch.live_feed] dependencies installed.",
                  flush=True)
        else:
            print("[photomatch.live_feed] install ran but imports still "
                  "fail. Start the live feed to retry synchronously.",
                  flush=True)
    except Exception as e:
        print(f"[photomatch.live_feed] auto-install failed: {e}", flush=True)


# ----------------------------------------------------------------------------
# Networking primitives
# ----------------------------------------------------------------------------

def get_local_ip():
    """Return the LAN IP the machine would use for outbound traffic.

    Trick: open a UDP socket and `connect()` to a public address. UDP
    `connect()` does no actual packets — it just lets the kernel decide
    which interface would be used, and `getsockname()` reveals that
    interface's IP. Falls back to 127.0.0.1 if there's no network at all.

    Note: returns the *single* route-to-internet IP. For multi-interface
    hosts (laptop with Wi-Fi + Ethernet + VPN tunnels), prefer
    `get_best_lan_ip()` below — it enumerates every interface and scores
    each so the phone gets the IP it can actually reach.
    """
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('8.8.8.8', 80))
        return s.getsockname()[0]
    except Exception:
        return '127.0.0.1'
    finally:
        s.close()


def _all_local_ipv4():
    """Enumerate every non-loopback IPv4 address on this machine."""
    ips = set()
    try:
        host = socket.gethostname()
        for info in socket.getaddrinfo(host, None, socket.AF_INET,
                                        socket.SOCK_STREAM):
            ip = info[4][0]
            if ip and not ip.startswith("127."):
                ips.add(ip)
    except Exception:
        pass

    rt = get_local_ip()
    if rt and not rt.startswith("127."):
        ips.add(rt)

    return sorted(ips)


def _pick_lan_ip(ips):
    """From a list of IPv4 strings, return the most likely LAN IP.

    Why this exists: Hyper-V / Docker / VPN tunnels often add interfaces
    that get a 172.x address only routable from the host itself. Picking
    that as "the URL to put in the QR" gives the user a phone that can't
    connect with no clue why. We score so a typical home Wi-Fi address
    (192.168.x.x) wins over a vEthernet adapter.

    Scoring:
        192.168.x.x          100  (typical home Wi-Fi router)
         10.x.x.x              90  (corporate networks; some home ISPs)
        172.16.x.x – 172.31.x.x  80  (Docker default; some corp)
        169.254.x.x           10  (auto-IP / link-local)
        127.x.x.x             -1  (loopback — phone can never reach)
        anything else         50  (Hyper-V vEthernet, VPN tunnels: rare)
    """
    if not ips:
        return None

    def score(ip):
        try:
            parts = ip.split(".")
            a, b = int(parts[0]), int(parts[1])
        except (ValueError, IndexError):
            return -1
        if a == 192 and b == 168:           return 100
        if a == 10:                         return  90
        if a == 172 and 16 <= b <= 31:      return  80
        if a == 169 and b == 254:           return  10
        if a == 127:                        return  -1
        return 50

    return max(ips, key=score)


def get_best_lan_ip():
    """Enumerate + pick in one call. Falls back to `get_local_ip()` if
    enumeration found nothing — keeps offline laptops happy."""
    ips = _all_local_ipv4()
    picked = _pick_lan_ip(ips)
    if picked:
        return picked
    return get_local_ip()


def find_free_port(start=DEFAULT_PORT_START, search=100):
    """Probe ports from `start` upward, return the first we can bind."""
    for port in range(start, start + search):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(('', port))
                return port
            except OSError:
                continue
    raise RuntimeError(
        f"No free port in range {start}..{start + search - 1}")


# ----------------------------------------------------------------------------
# SSL certificate generation
# ----------------------------------------------------------------------------
#
# Self-signed, LAN-only certs. The phone will still warn about an untrusted
# cert — there's no avoiding that without a real CA. User has to tap
# "Proceed anyway" / "Visit Website" once per session.
#
# Cert is regenerated every start_server() call. That's a few hundred ms
# of work and removes a class of "cached cert is for the wrong IP" bugs
# the previous version had to handle with a sidecar `.sig` file.

def generate_cert(cert_path: str, key_path: str, ip: str):
    """Generate a self-signed RSA-2048 cert with the LAN IP as a SAN.

    SAN entries include the IP, 127.0.0.1, and `localhost` so the same
    cert works whether the user scans the QR from the phone or opens
    the URL from a browser on the host machine.
    """
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,
                                        "PhotoMatch Phone Cam")])
    san = x509.SubjectAlternativeName([
        x509.IPAddress(ipaddress.ip_address(ip)),
        x509.IPAddress(ipaddress.ip_address("127.0.0.1")),
        x509.DNSName("localhost"),
    ])
    now = datetime.datetime.utcnow()
    cert = (
        x509.CertificateBuilder()
        .subject_name(name)
        .issuer_name(name)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now - datetime.timedelta(minutes=1))
        .not_valid_after(now + datetime.timedelta(days=CERT_VALIDITY_DAYS))
        .add_extension(san, critical=False)
        .sign(key, hashes.SHA256())
    )
    with open(cert_path, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))
    with open(key_path, "wb") as f:
        f.write(key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        ))


# ----------------------------------------------------------------------------
# Phone-side HTML page
# ----------------------------------------------------------------------------
#
# Adapted from phone_camera_stream.py. Single static string. The page asks
# for the back camera, captures frames to a hidden canvas, encodes as JPEG
# (quality 0.6), and POSTs each frame to `/frame`. Sending throttles at
# ~15 fps which is plenty — the host downsamples to DISPLAY_HZ anyway.

_HTML_PAGE = r"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Photo Match — Phone Camera</title>
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; }
  body { font-family: -apple-system, system-ui, sans-serif; margin: 0; padding: 16px;
         background: #111; color: #eee; }
  h1 { font-size: 18px; margin: 0 0 12px; }
  video { width: 100%; max-width: 640px; background: #000; border-radius: 8px; }
  .row { display: flex; flex-wrap: wrap; gap: 8px; margin: 12px 0; }
  button { flex: 1; min-width: 120px; padding: 14px 12px; font-size: 16px;
           border: 0; border-radius: 8px; background: #444; color: #fff; }
  button.primary { background: #3a78d8; }
  button:disabled { opacity: .5; }
  #status { font-size: 14px; opacity: .85; }
  small { opacity: .6; }
</style>
</head>
<body>
<h1>Photo Match Phone Camera</h1>
<video id="v" autoplay playsinline muted></video>
<div class="row">
  <button id="start" class="primary">Start streaming</button>
  <button id="stop">Stop</button>
  <button id="switch">Switch cam</button>
</div>
<div id="status">Idle. Tap &quot;Start streaming&quot; and allow camera access.</div>
<small>This page is served by Blender on your LAN.</small>
<script>
const v = document.getElementById('v');
const statusEl = document.getElementById('status');
let stream = null, intervalId = null;
let facing = 'environment';
let sending = false;
const canvas = document.createElement('canvas');
const ctx = canvas.getContext('2d');

async function startStream() {
  try {
    stopStream();
    stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: facing },
               width: { ideal: 1280 }, height: { ideal: 720 } },
      audio: false
    });
    v.srcObject = stream;
    await v.play();
    canvas.width = v.videoWidth || 1280;
    canvas.height = v.videoHeight || 720;
    intervalId = setInterval(sendFrame, 1000 / 15);  // ~15 fps from phone
    statusEl.textContent = 'Streaming ' + canvas.width + ' x ' + canvas.height;
  } catch (e) {
    statusEl.textContent = 'Error: ' + e.message;
  }
}

function stopStream() {
  if (intervalId) { clearInterval(intervalId); intervalId = null; }
  if (stream) { stream.getTracks().forEach(t => t.stop()); stream = null; }
  statusEl.textContent = 'Stopped';
}

async function sendFrame() {
  if (sending || !stream || !v.videoWidth) return;
  sending = true;
  try {
    if (canvas.width !== v.videoWidth) {
      canvas.width = v.videoWidth;
      canvas.height = v.videoHeight;
    }
    ctx.drawImage(v, 0, 0, canvas.width, canvas.height);
    const blob = await new Promise(r => canvas.toBlob(r, 'image/jpeg', 0.6));
    if (blob) {
      await fetch('/frame', { method: 'POST', body: blob,
                              headers: { 'Content-Type': 'image/jpeg' } });
    }
  } catch (e) {
    statusEl.textContent = 'Send error: ' + e.message;
  } finally {
    sending = false;
  }
}

document.getElementById('start').onclick  = startStream;
document.getElementById('stop').onclick   = stopStream;
document.getElementById('switch').onclick = () => {
  facing = (facing === 'environment') ? 'user' : 'environment';
  if (stream) startStream();
};
</script>
</body>
</html>
"""


# ----------------------------------------------------------------------------
# HTTPS server
# ----------------------------------------------------------------------------

class _Handler(http.server.BaseHTTPRequestHandler):
    """Serves the phone HTML on `/` and receives JPEG POSTs on `/frame`."""

    # Suppress per-request logging — keeps Blender's console quiet at 15 fps.
    def log_message(self, *args, **kwargs):
        pass

    def do_GET(self):
        if self.path in ("/", "/index.html"):
            body = _HTML_PAGE.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_error(404)

    def do_POST(self):
        global _latest_frame, _latest_frame_at, _latest_frame_seq
        global _phone_connection_count

        if self.path != "/frame":
            self.send_error(404)
            return

        n = int(self.headers.get("Content-Length", 0))
        data = self.rfile.read(n) if n > 0 else b""

        if data:
            # Replace the slot atomically. We don't queue old frames — by
            # the time the display timer next fires the newest frame is
            # all that matters, and keeping a backlog just adds latency.
            with _frame_lock:
                _latest_frame = data
                _latest_frame_at = time.monotonic()
                _latest_frame_seq += 1

            # Bump connection count. The display timer decays this based on
            # frame staleness, so we don't need an explicit disconnect path.
            with _state_lock:
                _phone_connection_count = max(_phone_connection_count, 1)

        # 204 No Content is the right success code for "received, nothing
        # to send back" — saves the phone parsing an empty body.
        self.send_response(204)
        self.end_headers()


class _ThreadingHTTPS(socketserver.ThreadingMixIn, http.server.HTTPServer):
    """Per-request threads so a slow POST doesn't block GETs (and vice
    versa). `daemon_threads=True` lets process exit even if a request
    handler is wedged."""
    daemon_threads = True
    allow_reuse_address = True


def _make_https_server(host, port, cert_path, key_path):
    """Bind, then SSL-wrap the listening socket. The wrapped socket is
    used for the accept loop; per-connection sockets inherit the wrap.
    """
    server = _ThreadingHTTPS((host, port), _Handler)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(cert_path, key_path)
    server.socket = ctx.wrap_socket(server.socket, server_side=True)
    return server


# ----------------------------------------------------------------------------
# QR code generation
# ----------------------------------------------------------------------------

def _generate_qr_image(url, image_name="photomatch_live_qr"):
    """Render `url` as a QR code into a Blender image data-block.

    Returns the image data-block on success, or None if `qrcode` isn't
    importable (dependency install hasn't finished) — caller treats that
    as "no QR available, show the URL as text".

    Caller must be on the main thread (bpy.data mutation).
    """
    if not _HAS_BPY:
        return None
    try:
        import qrcode
    except ImportError:
        return None

    try:
        import numpy as np
        from PIL import Image as PILImage  # noqa: F401  (qrcode uses it)
    except ImportError:
        return None

    qr = qrcode.QRCode(border=2, box_size=10,
                       error_correction=qrcode.constants.ERROR_CORRECT_M)
    qr.add_data(url)
    qr.make(fit=True)
    pil = qr.make_image(fill_color="black", back_color="white").convert("RGBA")
    w, h = pil.size
    arr = np.asarray(pil, dtype=np.float32) / 255.0
    arr = np.flipud(arr)  # Blender pixel origin is bottom-left

    img = bpy.data.images.get(image_name)
    if img is None:
        img = bpy.data.images.new(image_name, width=w, height=h, alpha=True)
    elif img.size[0] != w or img.size[1] != h:
        img.scale(w, h)

    img.pixels.foreach_set(arr.ravel())
    img.update()
    return img


# ----------------------------------------------------------------------------
# Frame consumer (display-Hz timer, main thread)
# ----------------------------------------------------------------------------

# Cache the last sequence number we processed so the timer can no-op when
# nothing new has arrived (e.g. phone in pocket). Saves a JPEG decode per
# tick during idle periods.
_last_consumed_seq = -1


def _decode_jpeg_to_rgb(jpeg_bytes):
    """PIL JPEG decode → (width, height, uint8 RGB ndarray). None on failure.

    Exported because live_tracking.py calls it on the lock-frame.
    """
    try:
        from PIL import Image
        import numpy as np
    except ImportError:
        return None
    try:
        pil = Image.open(io.BytesIO(jpeg_bytes)).convert('RGB')
    except Exception:
        return None
    return pil.size[0], pil.size[1], np.asarray(pil, dtype=np.uint8)


def _write_rgb_to_blender_image(name, w, h, rgb_uint8):
    """Update or create `bpy.data.images[name]` with the given RGB frame.

    Phone-rotation / camera-switch produces a resolution change, which we
    handle by removing and recreating the image data-block. References
    held by name (camera background slots) rebind on next update.
    """
    import numpy as np
    img = bpy.data.images.get(name)
    if img is not None and (img.size[0] != w or img.size[1] != h):
        bpy.data.images.remove(img)
        img = None
    if img is None:
        img = bpy.data.images.new(name, w, h, alpha=True)

    rgba = np.empty((h, w, 4), dtype=np.float32)
    # Blender pixel origin is bottom-left; JPEG decode is top-left.
    # Flip rows so the phone's "up" stays Blender's "up".
    rgba[..., :3] = rgb_uint8[::-1].astype(np.float32) / 255.0
    rgba[..., 3] = 1.0
    img.pixels.foreach_set(rgba.ravel())
    img.update_tag()
    return img


def _display_timer_tick():
    """Pull the latest frame, update the live-feed image, refresh status props.

    Returns the next-call delay (seconds), or None to unregister the timer.
    The interval is read from `props.live_feed_snapshot_interval` each tick
    so a user-changed slider takes effect immediately.

    v2.8.4: the freeze toggle short-circuits the image-write so the user
    can pin a frame as a static reference. We still advance the consumed-
    seq so unfreezing picks up the *latest* frame, not a backlog.
    """
    global _last_consumed_seq, _phone_connection_count

    if _server_state is None:
        return None  # server stopped — unregister

    # Read snapshot props up front for both the next-tick interval and the
    # freeze decision. Defaults match property defaults so headless tests
    # (no props attached) still work.
    next_interval = DISPLAY_INTERVAL
    frozen = False
    try:
        scene = bpy.context.scene
        props = scene.photo_match_props
        next_interval = float(getattr(
            props, 'live_feed_snapshot_interval', DISPLAY_INTERVAL))
        frozen = bool(getattr(props, 'live_feed_snapshot_freeze', False))
    except (AttributeError, ReferenceError):
        pass

    # Snapshot the frame slot under lock (cheap; pointer copy).
    with _frame_lock:
        seq = _latest_frame_seq
        if seq == _last_consumed_seq:
            jpeg_bytes = None  # no new frame since last tick
        else:
            jpeg_bytes = _latest_frame
        frame_at = _latest_frame_at

    now = time.monotonic()
    age_seconds = (now - frame_at) if frame_at > 0 else 999.0

    # Decay the connection counter based on frame staleness. There's no
    # explicit disconnect signal in plain HTTP POSTs (each request closes
    # at the TCP layer), so "is the phone alive?" becomes "have we seen a
    # frame recently?". Bumps happen in do_POST.
    if age_seconds >= PHONE_STALE_SECONDS:
        with _state_lock:
            _phone_connection_count = 0

    # Update status props (cheap; safe every tick even when frozen — the
    # status panel should still update so the user can see whether the
    # phone is alive behind the frozen snapshot).
    try:
        scene = bpy.context.scene
        props = scene.photo_match_props
        with _state_lock:
            count = _phone_connection_count
        connected = count > 0 and age_seconds < PHONE_STALE_SECONDS
        if props.live_feed_phone_connected != connected:
            props.live_feed_phone_connected = connected
        new_age_ms = min(int(age_seconds * 1000), 99999)
        if props.live_feed_last_frame_age_ms != new_age_ms:
            props.live_feed_last_frame_age_ms = new_age_ms
    except (AttributeError, ReferenceError):
        # Scene gone, props removed — defensive; don't crash the timer.
        pass

    # Freeze: bail before writing the image so the frozen frame stays
    # pinned. We still advance _last_consumed_seq so when the user
    # unfreezes, the next tick picks up the latest frame (not a stale
    # backlog of in-between frames). The matcher reads from `_latest_frame`
    # directly, not from the image data-block, so freezing doesn't affect
    # tracking accuracy.
    if frozen:
        if jpeg_bytes is not None:
            _last_consumed_seq = seq
        return next_interval

    if jpeg_bytes is None:
        return next_interval  # nothing new

    decoded = _decode_jpeg_to_rgb(jpeg_bytes)
    if decoded is None:
        # Corrupt frame — don't update consumed_seq so the next legitimate
        # frame still overrides. Try again next tick.
        return next_interval

    w, h, rgb = decoded
    try:
        _write_rgb_to_blender_image(LIVE_FEED_IMAGE_NAME, w, h, rgb)
    except Exception:
        import traceback
        traceback.print_exc()
        return next_interval

    _last_consumed_seq = seq
    return next_interval


# ----------------------------------------------------------------------------
# Auto-camera + transparent-background overlay (v2.8.1 carryover)
# ----------------------------------------------------------------------------
#
# Goal: when the live feed connects, the user shouldn't have to set up a
# camera, wire the live feed as background, and switch to camera view by
# hand. The auto-camera path does all three. The overlay timer then renders
# the Blender scene every second with a transparent film, layered on top
# of the live feed in the camera's background-images list — giving the
# user a live composite of phone-feed + Blender model in the camera view.

_overlay_lock = threading.Lock()


def ensure_live_feed_camera(scene, props):
    """Get-or-create a Blender camera for the live feed.

    If `scene.camera` is already set: respect the user's choice — don't
    create a new camera, just wire the live feed as ITS background.
    If `scene.camera` is None: create `PhotoMatch_LiveCam`, drop it at a
    sensible default position, set it active, switch the first 3D viewport
    to camera view.

    Returns the camera object, or None if bpy isn't usable yet.
    """
    if not _HAS_BPY:
        return None

    cam_obj = scene.camera
    if cam_obj is None:
        # Reuse a pre-existing PhotoMatch_LiveCam (e.g. user stopped + restarted)
        cam_obj = bpy.data.objects.get(LIVE_FEED_CAMERA_NAME)
        if cam_obj is None or cam_obj.type != 'CAMERA':
            cam_data = bpy.data.cameras.new(name=LIVE_FEED_CAMERA_NAME)
            cam_obj = bpy.data.objects.new(LIVE_FEED_CAMERA_NAME, cam_data)
            scene.collection.objects.link(cam_obj)
            # Default pose: roughly chest-height, looking forward and slightly
            # down. The user will move it; we just need the camera looking at
            # the scene origin instead of straight up.
            cam_obj.location = (0.0, -5.0, 1.5)
            cam_obj.rotation_euler = (math.radians(80), 0.0, 0.0)
        scene.camera = cam_obj

    # Wire the live feed image as the FIRST background slot (depth=BACK)
    img = bpy.data.images.get(LIVE_FEED_IMAGE_NAME)
    if img is not None:
        _wire_image_as_camera_bg(
            cam_obj.data, img,
            slot_id=f"livefeed:{LIVE_FEED_IMAGE_NAME}",
            alpha=1.0, depth='BACK',
        )

    # Switch the first 3D viewport to camera view. Don't fail if no viewport.
    try:
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        if space.region_3d.view_perspective != 'CAMERA':
                            space.region_3d.view_perspective = 'CAMERA'
                        break
                break
    except (AttributeError, RuntimeError):
        pass

    return cam_obj


def _wire_image_as_camera_bg(cam_data, image, *, slot_id, alpha=1.0,
                             depth='BACK'):
    """Add or update a camera background-image slot, tagged so we can
    find/replace OUR slots without disturbing user-added ones.

    Convention for slot_id: "livefeed:<image_name>" or "overlay:<image_name>".
    """
    cam_data.show_background_images = True

    existing = None
    for bg in cam_data.background_images:
        if bg.image is None:
            continue
        if bg.image.get('photomatch_slot_id') == slot_id:
            existing = bg
            break

    if existing is None:
        bg = cam_data.background_images.new()
    else:
        bg = existing

    bg.image = image
    bg.alpha = alpha
    bg.frame_method = 'FIT'
    bg.display_depth = depth
    image['photomatch_slot_id'] = slot_id
    return bg


def _remove_camera_bg_by_slot_id(cam_data, slot_id):
    """Remove our tagged background slot if present. Safe when no slot
    exists. Used on stop_server to clean up the overlay slot but leave
    the live feed slot in place (handoff §403: lock-frame stays).
    """
    if cam_data is None:
        return
    to_remove = []
    for i, bg in enumerate(cam_data.background_images):
        if bg.image is not None and bg.image.get('photomatch_slot_id') == slot_id:
            to_remove.append(i)
    for i in reversed(to_remove):
        cam_data.background_images.remove(cam_data.background_images[i])


def _overlay_render_tick():
    """Render the scene with transparent film, write to disk, refresh the
    overlay image, ensure it's wired as a camera background.

    Returns the next delay (seconds) or None to unregister.

    Concurrency note: `bpy.ops.render.render` is blocking and runs on the
    main thread. While it executes, no other timer can fire. Save/restore
    of render settings is atomic from Python's perspective — no race with
    fine-tune or live-tracking renders.
    """
    if _server_state is None:
        return None  # server stopped — unregister

    try:
        scene = bpy.context.scene
        props = scene.photo_match_props
    except (AttributeError, RuntimeError):
        return None

    # Don't bail when overlay_enabled is False — keep the timer alive so the
    # user can toggle it on without restarting the server. Just skip render.
    if not getattr(props, 'live_feed_overlay_enabled', False):
        return OVERLAY_INTERVAL_SECONDS

    cam_obj = scene.camera
    if cam_obj is None or cam_obj.type != 'CAMERA':
        return OVERLAY_INTERVAL_SECONDS

    # Skip if another render-using component is mid-flight. They render
    # at low res and fast, but if we fired our 1s render right between
    # their ticks the user would feel the stutter.
    try:
        if bool(getattr(props, 'auto_solve_running', False)):
            return OVERLAY_INTERVAL_SECONDS
        if bool(getattr(props, 'fine_tune_running', False)):
            return OVERLAY_INTERVAL_SECONDS
        if bool(getattr(props, 'tracking_locked', False)):
            return OVERLAY_INTERVAL_SECONDS
    except (AttributeError, RuntimeError):
        pass

    if not _overlay_lock.acquire(blocking=False):
        return OVERLAY_INTERVAL_SECONDS

    try:
        _do_overlay_render(scene, cam_obj, props)
    except Exception as e:
        print(f"[photomatch.live_feed.overlay] render failed: {e}")
    finally:
        _overlay_lock.release()

    return OVERLAY_INTERVAL_SECONDS


def _do_overlay_render(scene, cam_obj, props):
    """Render + image-update body. Save/restore render settings so we
    don't trample user values if the render raises mid-flight.
    """
    render = scene.render

    # Pick a target resolution matching the live feed's aspect, capped by
    # OVERLAY_RENDER_LONG_EDGE so render time stays bounded.
    target_w = OVERLAY_RENDER_LONG_EDGE
    target_h = OVERLAY_RENDER_LONG_EDGE
    feed_img = bpy.data.images.get(LIVE_FEED_IMAGE_NAME)
    if feed_img is not None and feed_img.size[0] > 0 and feed_img.size[1] > 0:
        fw, fh = feed_img.size[0], feed_img.size[1]
        if fw >= fh:
            target_w = OVERLAY_RENDER_LONG_EDGE
            target_h = max(2, int(OVERLAY_RENDER_LONG_EDGE * fh / fw))
        else:
            target_h = OVERLAY_RENDER_LONG_EDGE
            target_w = max(2, int(OVERLAY_RENDER_LONG_EDGE * fw / fh))

    saved = {
        'resolution_x': render.resolution_x,
        'resolution_y': render.resolution_y,
        'film_transparent': render.film_transparent,
        'filepath': render.filepath,
        'image_settings_format': render.image_settings.file_format,
    }

    out_path = os.path.join(tempfile.gettempdir(), 'photomatch_overlay.png')

    try:
        render.resolution_x = target_w
        render.resolution_y = target_h
        render.film_transparent = True
        render.filepath = out_path
        render.image_settings.file_format = 'PNG'
        bpy.ops.render.render(write_still=True)
    finally:
        render.resolution_x = saved['resolution_x']
        render.resolution_y = saved['resolution_y']
        render.film_transparent = saved['film_transparent']
        render.filepath = saved['filepath']
        render.image_settings.file_format = saved['image_settings_format']

    # Refresh the overlay image data-block from disk
    img = bpy.data.images.get(OVERLAY_IMAGE_NAME)
    if img is None:
        try:
            img = bpy.data.images.load(out_path, check_existing=False)
            img.name = OVERLAY_IMAGE_NAME
        except RuntimeError as e:
            print(f"[photomatch.live_feed.overlay] could not load: {e}")
            return
    else:
        img.filepath = out_path
        try:
            img.reload()
        except RuntimeError:
            pass

    alpha = float(getattr(props, 'live_feed_overlay_alpha', 0.7))
    _wire_image_as_camera_bg(
        cam_obj.data, img,
        slot_id=f"overlay:{OVERLAY_IMAGE_NAME}",
        alpha=alpha, depth='FRONT',
    )


def _register_overlay_timer():
    if not _HAS_BPY:
        return
    if not bpy.app.timers.is_registered(_overlay_render_tick):
        bpy.app.timers.register(_overlay_render_tick,
                                first_interval=OVERLAY_INTERVAL_SECONDS)


def _unregister_overlay_timer():
    if not _HAS_BPY:
        return
    if bpy.app.timers.is_registered(_overlay_render_tick):
        try:
            bpy.app.timers.unregister(_overlay_render_tick)
        except (ValueError, RuntimeError):
            pass


# ----------------------------------------------------------------------------
# Lifecycle
# ----------------------------------------------------------------------------

def is_running():
    return _server_state is not None


def start_server():
    """Start the live feed server. Synchronous: blocks ~1s on first start
    (cert generation, possibly dependency install). Returns
    (True, ServerState) on success, (False, error_message) on failure.

    Idempotent — calling twice returns the existing state.
    """
    global _server_state, _last_consumed_seq, _latest_frame
    global _latest_frame_at, _latest_frame_seq, _phone_connection_count

    if _server_state is not None:
        return True, _server_state

    # Synchronous dependency install fallback. Background install at
    # register() usually handles this, but if the user clicks Start before
    # it finishes, or it failed silently, we retry here.
    if not _deps_installed():
        try:
            _install_deps()
        except Exception as e:
            return False, f"dependency install failed: {e}"
        if not _deps_installed():
            return False, ("required Python packages still missing — "
                           "check Blender's console for pip errors")

    try:
        ip = get_best_lan_ip()
        port = find_free_port(DEFAULT_PORT_START)

        # Fresh cert per session. The previous version cached per-IP and
        # tracked SAN signatures to invalidate stale certs; regenerating
        # every time removes that whole cache-validity surface for ~200ms.
        tmp = tempfile.gettempdir()
        cert_path = os.path.join(tmp, "photomatch_phonecam.crt")
        key_path  = os.path.join(tmp, "photomatch_phonecam.key")
        generate_cert(cert_path, key_path, ip)

        server = _make_https_server('', port, cert_path, key_path)
    except Exception as e:
        return False, str(e)

    url = f"https://{ip}:{port}/"

    # Reset frame state so a previous session's stale frame doesn't show.
    with _frame_lock:
        _latest_frame = None
        _latest_frame_at = 0.0
        _latest_frame_seq = 0
    with _state_lock:
        _phone_connection_count = 0
    _last_consumed_seq = -1

    # QR generation needs main-thread bpy.data access — must run before
    # we hand control back to the operator's caller.
    qr_image = _generate_qr_image(url) if _HAS_BPY else None
    qr_name = qr_image.name if qr_image is not None else ""

    thread = threading.Thread(target=server.serve_forever,
                              name="photomatch_live_feed",
                              daemon=True)
    thread.start()

    state = _ServerState(
        server=server, thread=thread, ip=ip, port=port,
        cert_path=cert_path, key_path=key_path,
        url=url, qr_image_name=qr_name,
    )
    _server_state = state

    if _HAS_BPY:
        _register_display_timer()

        # Auto-create camera + start overlay render timer. Both gated by
        # user-toggleable props so anyone with their own camera workflow
        # can opt out. Skip if context.scene isn't usable yet.
        try:
            scene = bpy.context.scene
            props = scene.photo_match_props
            if getattr(props, 'live_feed_auto_camera', True):
                ensure_live_feed_camera(scene, props)
            # Always register the overlay timer — it self-skips when
            # overlay_enabled is False, so toggling the prop later works
            # without restarting the server.
            _register_overlay_timer()
        except (AttributeError, RuntimeError):
            pass

    return True, state


def stop_server():
    """Stop the server and unregister the display timer. Idempotent.

    If live tracking is active when this is called (handoff edge case
    §403: user stops live feed while locked), the tracking state machine
    is also torn down. The lock-frame image stays in place so static
    scoring can still run against the last received frame.
    """
    global _server_state, _phone_connection_count

    state = _server_state
    if state is None:
        return

    # Stop tracking FIRST so its 1 Hz timer doesn't fire one more time
    # against a feed that's about to disappear. live_tracking is imported
    # lazily to avoid a circular dependency at module load.
    try:
        from . import live_tracking
        if live_tracking.is_tracking():
            try:
                scene = bpy.context.scene if _HAS_BPY else None
                props = scene.photo_match_props if scene is not None else None
                live_tracking.stop_tracking(scene, props)
            except (AttributeError, RuntimeError):
                live_tracking.stop_tracking(None, None)
    except ImportError:
        pass

    # 1. Mark stopped first so the display timer's next tick unregisters
    #    itself (it returns None when _server_state is None).
    _server_state = None

    # 2. Unregister timers explicitly (faster than waiting for ticks).
    if _HAS_BPY:
        _unregister_display_timer()
        _unregister_overlay_timer()

        # Clean up the overlay BG slot from the camera. Leave the live-feed
        # BG slot AND the camera object in place — user may want to keep
        # matching against the last frame as a static reference
        # (handoff §403). Removing only the overlay restores the camera to
        # "shows just the live feed" rather than "shows live feed +
        # outdated render".
        try:
            scene = bpy.context.scene
            cam_obj = scene.camera
            if cam_obj is not None and cam_obj.type == 'CAMERA':
                _remove_camera_bg_by_slot_id(
                    cam_obj.data, f"overlay:{OVERLAY_IMAGE_NAME}")
        except (AttributeError, RuntimeError):
            pass

    # 3. Stop the HTTP server. shutdown() blocks until serve_forever()
    #    returns, then close the socket. Worker threads die on their own
    #    (daemon=True).
    try:
        state.server.shutdown()
    except Exception:
        pass
    try:
        state.server.server_close()
    except Exception:
        pass

    # 4. Reset connection count — handlers may not have all returned cleanly.
    with _state_lock:
        _phone_connection_count = 0


# --- Display timer registration --------------------------------------------

def _register_display_timer():
    """Register the display timer at the user's configured snapshot rate.

    First-interval reads from `live_feed_snapshot_interval` so the first
    tick fires at the right cadence; subsequent ticks re-read the prop
    in `_display_timer_tick`. Falls back to DISPLAY_INTERVAL if props
    aren't available (headless test paths).
    """
    global _display_timer_registered
    if _display_timer_registered:
        return
    first = DISPLAY_INTERVAL
    try:
        first = float(getattr(
            bpy.context.scene.photo_match_props,
            'live_feed_snapshot_interval', DISPLAY_INTERVAL))
    except (AttributeError, ReferenceError):
        pass
    bpy.app.timers.register(_display_timer_tick,
                            first_interval=first,
                            persistent=False)
    _display_timer_registered = True


def _unregister_display_timer():
    global _display_timer_registered
    if not _display_timer_registered:
        return
    try:
        if bpy.app.timers.is_registered(_display_timer_tick):
            bpy.app.timers.unregister(_display_timer_tick)
    except Exception:
        pass
    _display_timer_registered = False


# ----------------------------------------------------------------------------
# Operators
# ----------------------------------------------------------------------------

class PHOTOMATCH_OT_StartLiveFeed(Operator):
    """Start the local HTTPS server, generate a QR code, and begin
    accepting phone connections."""
    bl_idname = "photomatch.start_live_feed"
    bl_label = "Start Live Feed Server"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return not is_running()

    def execute(self, context):
        # If background install is still running, surface that — start
        # would otherwise fail with a less-clear "module not found".
        if _install_thread is not None and _install_thread.is_alive():
            self.report({'INFO'},
                "Dependencies are still installing in the background — "
                "try again in a few seconds.")
            return {'CANCELLED'}

        ok, result = start_server()
        if not ok:
            self.report({'ERROR'}, f"Live feed start failed: {result}")
            return {'CANCELLED'}

        state = result
        props = context.scene.photo_match_props
        props.live_feed_running = True
        props.live_feed_url = state.url
        props.live_feed_last_frame_age_ms = 0
        props.live_feed_phone_connected = False

        if state.qr_image_name and _HAS_BPY:
            qr = bpy.data.images.get(state.qr_image_name)
            props.live_feed_qr_image = qr
        else:
            props.live_feed_qr_image = None

        self.report({'INFO'}, f"Live feed at {state.url}")
        return {'FINISHED'}


class PHOTOMATCH_OT_StopLiveFeed(Operator):
    """Stop the live feed server. Any tracking session is left untouched —
    last frame remains in the Blender image as a static reference (handoff
    edge case requirement)."""
    bl_idname = "photomatch.stop_live_feed"
    bl_label = "Stop Live Feed Server"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return is_running()

    def execute(self, context):
        stop_server()
        props = context.scene.photo_match_props
        props.live_feed_running = False
        props.live_feed_phone_connected = False
        props.live_feed_url = ""
        # Don't clear live_feed_qr_image — leaving it gives a visual clue
        # that a feed was active, and the image data-block is harmless.
        # Don't clear the live-feed image either — handoff says last frame
        # remains as static reference after stop.
        self.report({'INFO'}, "Live feed stopped")
        return {'FINISHED'}


# ----------------------------------------------------------------------------
# Registration
# ----------------------------------------------------------------------------

classes = (
    PHOTOMATCH_OT_StartLiveFeed,
    PHOTOMATCH_OT_StopLiveFeed,
)


def register():
    global _install_thread
    if not _HAS_BPY:
        return  # pure-Python test mode, no Blender
    for cls in classes:
        bpy.utils.register_class(cls)

    # Auto-install missing dependencies in the background so addon-enable
    # isn't blocked. The Start operator retries synchronously if needed.
    if not _deps_installed():
        _install_thread = threading.Thread(target=_background_install,
                                           daemon=True)
        _install_thread.start()


def unregister():
    # Safety: stop the server before unregistering operators, otherwise a
    # running daemon would outlive the addon and try to access dead refs
    # on its next frame.
    if is_running():
        stop_server()
    if not _HAS_BPY:
        return
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
