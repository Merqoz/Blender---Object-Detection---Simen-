"""Camera search v3 — same algorithm shape as v2, retuned for contour scoring.

v3 differs from v2 in tuning constants AND in adding two algorithmic features
on top of the inherited V2 search:

  1. `cold_start` mode (Step 5): skip the warm-start phase entirely. Used by
     the live-tracking state machine in LOST regime — no trustworthy current
     pose to warm-start from.

  2. `tabu` escape phases (v2.7.2): when the main plan exhausts without
     reaching `TABU_RESTART_THRESHOLD`, run additional global Fibonacci
     sweeps that AVOID zones the search has already explored without
     breakthrough. Stops the gradient/pattern phases from re-drilling
     near-but-not-good-enough basins forever.

What changes from V2:

  - **Larger finite-difference epsilons.** Chamfer distance changes step-wise
    as edges align/misalign; gradients computed with v2's epsilons (0.08 rad)
    sometimes return zero because the rendered edges fell in the same chamfer
    "bin." Bigger epsilons (0.12 rad) reliably trigger a meaningful score
    delta.

  - **Lower local-phase threshold.** With contour scoring the warm-start
    rarely scores above 60 unless the alignment is genuinely good, so v3
    drops the threshold to 50 — meaning v3 is more eager to skip the global
    phase when it's already on a promising track.

  - **Lower early-stop threshold (95 vs 98).** Contour score hits a ceiling
    around 92-95 even for perfect alignment because the strict scoring curve
    is calibrated against pixel-similarity, and chamfer distance never quite
    reaches zero in practice (Sobel edges are 2 px wide, so DT min-distance
    is ~0.5 not 0). Stopping at 95 saves wasted budget polishing further.

  - **Smaller PID gain (0.06 vs 0.08).** Contour landscape has steeper
    cliffs near edge alignment, so smaller steps prevent overshoot.

  - **Tabu / escape phases (v2.7.2).** After the main plan, if we're stuck
    below 90% (high but not good enough), mark the explored "near-miss"
    zones tabu and do another global sweep avoiding them. Up to 2 escape
    rounds. Tackles the user-reported "stuck at 87% forever" case.

The operator picks the v3 scoring path (precomputed reference features +
contour-aware score per evaluation) and feeds those scores back via
`report_score`, exactly like v2.
"""

import math

from . import search_v2
from .search_v2 import (
    direction_to_spherical, spherical_to_direction,
    clamp_theta, wrap_phi, fibonacci_sphere,
)


class CameraSolveStateV3(search_v2.CameraSolveStateV2):
    """Camera-pose search tuned for contour-based scoring."""

    # Bigger finite-difference epsilons — contour landscape needs them
    FD_EPSILON_THETA = 0.12
    FD_EPSILON_PHI = 0.12
    FD_EPSILON_DIST_REL = 0.10

    # Smaller gradient gain — chamfer landscape has sharper local features,
    # bigger steps tend to overshoot the basin
    GRADIENT_GAIN = 0.06

    # Skip global sweep more eagerly — contour scores are honest about
    # warm-start quality, so 50 means "you're already in the basin"
    LOCAL_PHASE_THRESHOLD = 50.0

    # Lower early-stop — see module docstring on chamfer ceiling
    EARLY_STOP_SCORE = 95.0

    # ---- Tabu / restart config (v2.7.2 — item 1 in user feedback) ----
    # If best_score is below this after the main plan, run an escape phase.
    TABU_RESTART_THRESHOLD = 90.0
    # A zone with best_score in [BAND_LOW, RESTART_THRESHOLD) becomes tabu —
    # "we found something there but couldn't break through, move on".
    # Below BAND_LOW, the zone hasn't been explored well enough to mark
    # tabu — low scores might just mean under-sampling.
    TABU_BAND_LOW = 70.0
    # A zone needs this many evaluations before it's eligible for tabu.
    # Prevents one unlucky probe from blacklisting a whole region.
    TABU_MIN_EVALS = 2
    # Max escape rounds. Each round adds ~ESCAPE_GLOBAL + 4×7 evals.
    MAX_TABU_RESTARTS = 2
    # Escape-phase global candidates per round.
    ESCAPE_GLOBAL_SAMPLES = 24
    # Short follow-up gradient at the new best after each escape round.
    ESCAPE_GRADIENT_STEPS = 4
    # Spherical zone grid (4×8 = 32 zones; ~50° per side at the equator).
    # Coarse enough that "stuck pose + neighbors" hash to the same zone,
    # fine enough that a meaningfully different perspective lands elsewhere.
    ZONE_THETA_BINS = 4
    ZONE_PHI_BINS = 8

    def __init__(self, *args, cold_start=False, **kwargs):
        """
        Args:
            cold_start: when True, skip the warm-start phase entirely and go
                straight to a global Fibonacci sweep. Used by the live-tracking
                state machine when it's in LOST regime — there's no
                trustworthy current-pose to warm-start from. Default False
                preserves all existing call-sites' behaviour (warm-start is
                the defining feature of v2/v3).
        """
        # Per-zone tracking — needs to exist BEFORE super().__init__ because
        # super's __init__ calls _build_plan which our override references
        # these attributes from. Keep this block at the top.
        self._zone_best_score = {}   # zone_id → max score seen
        self._zone_eval_count = {}   # zone_id → count of evals in that zone
        self._tabu_zones = set()
        self._restart_count = 0

        super().__init__(*args, **kwargs)
        if cold_start:
            # Per-instance override — class-level LOCAL_SAMPLES stays 8 for
            # everyone else. Setting LOCAL_PHASE_THRESHOLD to a huge value is
            # also belt-and-braces: even if some local samples got through,
            # the "is local good enough?" check would always say no, forcing
            # the global phase to run.
            self.LOCAL_SAMPLES = 0
            self.LOCAL_PHASE_THRESHOLD = 1e9
            # Re-build the phase plan with the new params (the parent's
            # __init__ already created one using the original values).
            self._plan = self._build_plan()

    # ------------------------------------------------------------------
    # Zone bookkeeping
    # ------------------------------------------------------------------

    def _zone_id(self, direction):
        """Map a direction vector to an integer zone index.

        Lat/long binning. The grid wraps in phi (longitude) so phi=0 and
        phi=2pi land in the same bin. Theta clamped to [0, pi]."""
        try:
            theta, phi = direction_to_spherical(direction)
        except (TypeError, ValueError):
            return -1  # invalid input — bucket separately, never tabu'd
        theta_bin = max(0, min(self.ZONE_THETA_BINS - 1,
                               int(theta / math.pi * self.ZONE_THETA_BINS)))
        # phi mod 2pi to handle ±values cleanly
        phi_norm = phi % (2 * math.pi)
        phi_bin = int(phi_norm / (2 * math.pi) * self.ZONE_PHI_BINS) \
                  % self.ZONE_PHI_BINS
        return theta_bin * self.ZONE_PHI_BINS + phi_bin

    def report_score(self, direction, distance, score):
        """Same as parent, plus per-zone tracking for tabu detection."""
        super().report_score(direction, distance, score)
        zone = self._zone_id(direction)
        if zone < 0:
            return
        self._zone_eval_count[zone] = self._zone_eval_count.get(zone, 0) + 1
        prev = self._zone_best_score.get(zone, -1.0)
        if score > prev:
            self._zone_best_score[zone] = score

    # ------------------------------------------------------------------
    # Plan with escape phases
    # ------------------------------------------------------------------

    def _build_plan(self):
        """Yield from the parent's plan, then optionally yield one or more
        tabu-aware escape phases.

        The parent's plan is itself a generator; `yield from super()._build_plan()`
        delegates to it transparently. After it exhausts, we check whether
        we're stuck below the TABU_RESTART_THRESHOLD and, if so, run escape
        phases until either we cross the threshold or we hit MAX_TABU_RESTARTS.
        """
        yield from super()._build_plan()

        # Loop is bounded by MAX_TABU_RESTARTS regardless of best_score —
        # the inner while-condition keeps us from running pointless escape
        # rounds once we're already above threshold. If best_score > threshold
        # after one escape, we exit naturally.
        while (self._restart_count < self.MAX_TABU_RESTARTS
               and self.best_score < self.TABU_RESTART_THRESHOLD):
            self._refresh_tabu_zones()
            if not self._has_non_tabu_room():
                # Every zone is tabu — nothing left to explore. Bail rather
                # than spinning on an empty escape generator.
                break
            self._restart_count += 1
            yield from self._escape_phase()

    def _refresh_tabu_zones(self):
        """Add zones to tabu whose best score is in the [BAND_LOW, THRESHOLD)
        band AND have been evaluated TABU_MIN_EVALS+ times. The latter
        prevents one-shot low scores from condemning whole regions; only
        zones the search has *actually spent time on* count as tabu."""
        for zone, best in self._zone_best_score.items():
            if (self.TABU_BAND_LOW <= best < self.TABU_RESTART_THRESHOLD
                    and self._zone_eval_count.get(zone, 0)
                        >= self.TABU_MIN_EVALS):
                self._tabu_zones.add(zone)

    def _has_non_tabu_room(self):
        """Cheap upper bound: is there any zone we could yield candidates
        from? Returns False only if every zone in the upper-hemisphere grid
        is tabu, which essentially never happens with sane thresholds.
        """
        total_zones = self.ZONE_THETA_BINS * self.ZONE_PHI_BINS
        return len(self._tabu_zones) < total_zones

    def _escape_phase(self):
        """One round of: fresh global Fibonacci sweep avoiding tabu zones,
        then a short follow-up gradient at whatever new best emerged."""
        # --- Global candidates outside tabu zones ---
        # Over-sample the Fibonacci sphere because tabu skipping reduces the
        # effective count. With 24 escape samples and a 30%-tabu sphere
        # we'd otherwise yield ~17; the *2 buffer keeps us above target.
        n_yielded = 0
        for direction in fibonacci_sphere(
                self.ESCAPE_GLOBAL_SAMPLES * 2, self.upper_hemisphere):
            if self._zone_id(direction) in self._tabu_zones:
                continue
            yield 'escape_global', direction, self.best_distance
            n_yielded += 1
            if n_yielded >= self.ESCAPE_GLOBAL_SAMPLES:
                break

        # If the over-sample wasn't enough (very heavily tabu'd sphere),
        # we still yielded what we could — let the gradient phase pick up.

        # --- Follow-up gradient at new best ---
        # This mirrors the parent's gradient phase but with a smaller step
        # count. The PID controller carries integral state from the previous
        # gradient phase; that's intentional — we want it to remember that
        # the old basin was unproductive.
        for it in range(self.ESCAPE_GRADIENT_STEPS):
            probes = self._fd_probes(
                self.best_theta, self.best_phi, self.best_distance,
            )
            self._gradient_buffer = {
                'probes': probes, 'scores': {}, 'iter': it,
            }
            for _key, (theta, phi, dist) in probes.items():
                yield ('gradient_probe',
                       spherical_to_direction(theta, phi), dist)
            yield ('gradient_step', None, None)
