# Photo Match Game — v3.0

A Blender add-on that turns scene composition into a memory game.

## What's new in v3.0

- **Multi-Camera Search (10 cameras)** — the new default algorithm. Ten independent cameras race through the search space, each using a different optimization technique. When any camera scores above 80%, all others converge on that spot to refine with their own method.
- **Enhanced Scoring** — six visual metrics (pixel, strict pixel, histogram, SSIM, edge alignment, gradient) combined with adaptive weights that shift toward structural metrics at high scores for better discrimination near the optimum.
- **Progressive Difficulty** — the scoring formula gets stricter as scores climb, preventing easy plateaus in the 80-90% range.
- **Removed V3-360 sweep** — replaced by the superior multi-camera approach which covers the search space more thoroughly with better convergence.

## The 10 Camera Algorithms

| Camera | Algorithm | Strategy |
|--------|-----------|----------|
| 0 | **Fibonacci Sphere** | Even low-discrepancy coverage of the sphere surface |
| 1 | **Warm Gaussian** | Tight Gaussian shell around the starting pose |
| 2 | **PID Gradient** | Finite-difference gradient estimation with PID control |
| 3 | **Pattern Search** | Hooke-Jeeves axis-aligned pattern search |
| 4 | **Spiral Sweep** | Archimedes spiral from pole to equator |
| 5 | **Simulated Annealing** | Exponential cooling schedule, accepts worse moves early |
| 6 | **Lévy Walk** | Power-law random walk for long-range exploration |
| 7 | **Grid Sweep** | Systematic theta/phi grid coverage |
| 8 | **Golden Section** | Sequential 1D golden-section on each axis |
| 9 | **Differential Evolution** | Mini population-based optimizer with mutation/crossover |

### Hotspot Convergence

When any camera finds a score ≥ 80% (configurable), it broadcasts a "hotspot." All other cameras immediately teleport to that location and begin refining using their own technique. This combines the exploration strength of diverse algorithms with the exploitation power of focused refinement.

## Enhanced Scoring System

Six independent visual metrics, combined with adaptive weights:

1. **Pixel similarity** (lenient RGB diff) — strong gradient at low scores
2. **Strict pixel similarity** (power-compressed + gradient magnitude) — discriminates at mid-range
3. **Histogram similarity** (Bhattacharyya coefficient) — catches global color shifts
4. **Structural similarity** (SSIM-like local patches) — perceptually meaningful
5. **Edge alignment** (NCC of gradient maps) — penalizes silhouette misalignment
6. **Pose similarity** (exponential position + cosine rotation) — when reference camera is known

### Adaptive Weights

At low scores (exploration), pixel similarity dominates because it provides the strongest gradient signal. As scores climb:

| Score Range | Pixel | Strict | Histogram | SSIM | Edge |
|-------------|-------|--------|-----------|------|------|
| 0–40 | 45% | 25% | 10% | 10% | 10% |
| 40–70 | 30% | 25% | 10% | 15% | 20% |
| 70–85 | 20% | 25% | 10% | 20% | 25% |
| 85+ | 15% | 20% | 10% | 25% | 30% |

### Progressive Difficulty

Above 80%, a compression curve makes each additional percentage point harder to earn. This prevents "stuck at 87%" scenarios — the score honestly reflects how much work remains.

## Two ways to play

### 1. Random Challenge

1. Open the **Photo Match** sidebar tab (press `N`)
2. Highlight an object or pick one in the *Target* slot
3. Click **Generate Random Challenge**

### 2. Free reference image

Click **Load Image File** to use any image from disk.

## Algorithm choices

| Algorithm | Best for |
|-----------|----------|
| **v1** — Coarse + Refine | Cold starts on simple objects with strong color contrast |
| **v2** — Warm-start + PID | Hand-aligned starting points; pixel-similarity sufficient |
| **v3** — Contour-aware | Symmetric/repeating geometry, real photos, line-art renders |
| **Multi-Camera** (default) | Any scene. 10 algorithms race; best overall coverage and convergence |

## Live scoring

Position and rotation scores update live as you move the camera (~5×/second).

## Auto-Solve (Object) — 6-DOF object pose

Searches `(rotation_xyz, location_xyz)` with the camera held fixed. Uses phased coarse-to-fine with block-coordinate decomposition.

## Installation

1. `Edit → Preferences → Add-ons → Install...`
2. Pick `photo_match_game.zip`
3. Enable "Photo Match Game"
4. Press `N` in the 3D viewport — the **Photo Match** tab appears

## Code structure

| File | Purpose |
|------|---------|
| `__init__.py` | bl_info + register/unregister |
| `properties.py` | `PhotoMatchProperties` — including algorithm dropdown, scoring config |
| `geometry.py` | Bounding box / sphere math |
| `camera_utils.py` | Random direction, look-at, camera creation, viewport redraws |
| `rendering.py` | OpenGL render to PNG with overlay disabled |
| `image_features.py` | Sobel edges, chamfer DT, multi-scale pyramid, Chamfer score |
| `scoring.py` | Enhanced multi-metric scoring (pixel, strict, histogram, SSIM, edge, pose) |
| `search.py` | v1 — Fibonacci + adaptive Gaussian |
| `search_v2.py` | v2 — warm-start + PID gradient + pattern search |
| `search_v3.py` | v3 — same algorithm, retuned for contour score landscape |
| `multi_camera_search.py` | **NEW** — 10-camera multi-algorithm search with hotspot convergence |
| `object_search.py` | 6-DOF object search: LHS + block-coordinate descent |
| `live_scoring.py` | Background timer for live pose-score updates |
| `operators.py` | All `bpy.types.Operator` subclasses |
| `ui.py` | Sidebar panels |
