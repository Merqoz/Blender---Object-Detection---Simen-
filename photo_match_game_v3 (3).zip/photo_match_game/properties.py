"""Per-scene state stored on `scene.photo_match_props`."""

import bpy
from bpy.props import (
    StringProperty, FloatProperty, PointerProperty, BoolProperty,
    EnumProperty, IntProperty,
)
from bpy.types import PropertyGroup

from . import camera_intrinsics
from . import camera_utils


# ----------------------------------------------------------------------------
# Update callbacks
# ----------------------------------------------------------------------------

def _update_opacity(self, context):
    """Keep the camera background alpha in sync with the slider, and force a
    viewport redraw so the change is visible immediately."""
    cam = context.scene.camera
    if cam and cam.type == 'CAMERA' and cam.data.background_images:
        cam.data.background_images[0].alpha = self.opacity
    camera_utils.tag_redraw_3d_viewports(context)


def _target_object_poll(self, obj):
    """Only allow object types that have a meaningful position/extent."""
    return obj.type in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'EMPTY'}


def _fine_tune_update(self, context):
    """Lazy-imported wrapper so we can reference fine_tune.update_fine_tune_enabled
    without a circular import at module load time."""
    from . import fine_tune
    fine_tune.update_fine_tune_enabled(self, context)


def _tracking_auto_recover_update(self, context):
    """Forward auto-recover toggle into the running state machine, if any.
    No-op when not currently tracking."""
    from . import live_tracking
    live_tracking.on_auto_recover_changed(bool(self.tracking_auto_recover))


def _tracking_thresholds_update(self, context):
    """Forward the entire threshold quad into the running state machine.

    Bound to all four threshold sliders' update= callbacks so the user sees
    threshold changes take effect immediately, not at the next match-tick
    boundary. We push all four every edit (rather than tracking which field
    changed) — the SM API takes them as kwargs, the diff cost is negligible
    next to a match-tick render."""
    from . import live_tracking
    live_tracking.on_thresholds_changed(
        tracking_to_lost=self.threshold_tracking_to_lost,
        lost_to_tracking=self.threshold_lost_to_tracking,
        locked_to_tracking=self.threshold_locked_to_tracking,
        tracking_to_locked=self.threshold_tracking_to_locked,
    )


def _reference_source_update(self, context):
    """Switch between Random / File / Live-Feed reference sources.

    Edge case from handoff §405: switching to FILE while a live feed is
    running stops the feed first. The reverse (switching to LIVE_FEED while
    a file reference is loaded) doesn't auto-stop anything — the file image
    just becomes ignored until the user starts a feed."""
    if self.reference_source != 'LIVE_FEED':
        # Stop tracking + live feed if either is up
        from . import live_tracking, live_feed
        if live_tracking.is_tracking():
            live_tracking.stop_tracking(context.scene, self)
        if live_feed.is_running():
            live_feed.stop_server()
            # Mirror props (the operator path normally does this, but we're
            # bypassing it on a programmatic switch)
            self.live_feed_running = False
            self.live_feed_phone_connected = False
            self.live_feed_url = ""


# ----------------------------------------------------------------------------
# Enum items
# ----------------------------------------------------------------------------

ALGORITHM_VERSIONS = [
    ('V1', "v1 — Coarse + Refine",
     "Fibonacci sphere coarse sweep, then shrinking Gaussian perturbations. "
     "The original algorithm. Reliable cold-start, no warm-start advantage."),
    ('V2', "v2 — Warm-start + PID",
     "Tight Gaussian shell around current camera, escalating to global "
     "Fibonacci only if needed. Then PID-controlled gradient descent + "
     "Hooke-Jeeves pattern search polish. Good for hand-aligned starting points."),
    ('V3', "v3 — Contour-aware",
     "v2 algorithm with multi-scale Chamfer (contour) scoring driving the "
     "search. Best at distinguishing different rotations of symmetric objects "
     "(cubes, repeating panels) and silhouettes."),
    ('MULTI', "Multi-Camera (10 cameras)",
     "10 independent cameras searching with different algorithms: Fibonacci, "
     "Gaussian, PID gradient, pattern search, spiral, simulated annealing, "
     "Lévy walk, grid sweep, golden section, and differential evolution. "
     "When any camera scores above 80%, all others converge on that spot. "
     "Best overall coverage and convergence."),
    ('CV', "CV-Guided (COLMAP-style, default)",
     "COLMAP/Objectron-inspired search. Phase 1 evaluates ~2000 candidates "
     "using vertex reprojection + bbox IoU — NO renders, pure matrix math. "
     "Then refines the top 5 with actual renders. Uses geodesic rotation, "
     "FAST/BRIEF feature matching, and structural scoring for polish. "
     "Fastest and most thorough: covers the entire sphere in <2 seconds."),
]


# ----------------------------------------------------------------------------
# Property group
# ----------------------------------------------------------------------------

class PhotoMatchProperties(PropertyGroup):
    # --- Reference image (the screenshot the player is trying to match) ---
    reference_image_path: StringProperty(
        name="Reference Image Path",
        description="Path to the reference image on disk",
        default="",
        subtype='FILE_PATH',
    )
    reference_image: PointerProperty(
        name="Reference Image",
        type=bpy.types.Image,
    )

    # --- Random challenge config ---
    target_object: PointerProperty(
        name="Target Object",
        description="The object the random reference camera will frame",
        type=bpy.types.Object,
        poll=_target_object_poll,
    )
    distance_offset: FloatProperty(
        name="Distance from Surface",
        description="Extra distance beyond the object's bounding sphere when "
                    "placing the random reference camera",
        default=2.0,
        min=0.0,
        max=100.0,
        soft_max=20.0,
        unit='LENGTH',
    )
    upper_hemisphere_only: BoolProperty(
        name="Above Object Only",
        description="Constrain the random reference camera to the upper hemisphere",
        default=True,
    )

    # --- Render shading mode ---
    render_shading_mode: EnumProperty(
        name="Shading",
        description="Which viewport shading to use when capturing the "
                    "reference image AND when scoring. Both sides always "
                    "use the same mode so the comparison is fair.\n\n"
                    "• Viewport = whatever your 3D viewport is currently set to\n"
                    "• Solid = flat-shaded, no materials\n"
                    "• Material Preview = Eevee materials, textures, colors\n"
                    "• Rendered = full Eevee/Cycles preview",
        items=[
            ('VIEWPORT', "Use Current Viewport",
             "Don't change the viewport shading — capture exactly what you "
             "see. If you're in Material Preview, materials are included. "
             "If you're in Solid, they're not"),
            ('SOLID', "Solid",
             "Force Solid shading. Fast, but materials and textures are "
             "invisible — only geometry shape matters"),
            ('MATERIAL', "Material Preview",
             "Force Material Preview (Eevee). Materials, textures, colors, "
             "and roughness are all visible and scored. Good default for "
             "scenes with assigned materials"),
            ('RENDERED', "Rendered",
             "Force Rendered mode (full Eevee or Cycles preview). Most "
             "accurate but slowest — each auto-solve evaluation takes longer"),
        ],
        default='VIEWPORT',
    )

    # --- Free exploration mode ---
    search_free_explore: BoolProperty(
        name="Free Explore (don't orbit center)",
        description="Instead of orbiting the target on a sphere, explore "
                    "freely in 3D space starting from your current camera "
                    "position. Covers ground-level, side views, close-ups, "
                    "and far shots. The camera always points at the target "
                    "but its position is unconstrained.\n\n"
                    "Best for: large scenes, architectural shots, any case "
                    "where the reference photo wasn't taken from an orbit",
        default=False,
    )

    # --- Reference camera (hidden, set when a random challenge is generated) ---
    reference_camera: PointerProperty(
        name="Reference Camera",
        description="Hidden camera that captured the challenge — used for pose scoring",
        type=bpy.types.Object,
    )

    # --- Scores ---
    pixel_score: FloatProperty(default=0.0, min=0.0, max=100.0)
    position_score: FloatProperty(default=0.0, min=0.0, max=100.0)
    rotation_score: FloatProperty(default=0.0, min=0.0, max=100.0)
    score: FloatProperty(
        name="Score",
        description="Combined match score (0-100)",
        default=0.0, min=0.0, max=100.0,
    )
    best_score: FloatProperty(
        name="Best Score",
        description="Best combined score this session",
        default=0.0, min=0.0, max=100.0,
    )

    # --- Display ---
    opacity: FloatProperty(
        name="Reference Opacity",
        description="How visible the reference image is over your scene",
        default=0.5, min=0.0, max=1.0,
        update=_update_opacity,
    )

    # --- Live scoring ---
    live_scoring_enabled: BoolProperty(
        name="Live Scoring",
        description="Continuously update position + rotation scores as you move "
                    "the camera. Pixel score still requires the Calculate button "
                    "(rendering is too slow to do live). Only works with random "
                    "challenges (loaded images have no reference camera to compare against)",
        default=True,
    )

    # --- Auto-solve runtime state (set by the modal operator) ---
    auto_solve_running: BoolProperty(default=False)
    auto_solve_progress: StringProperty(default="")

    # --- Fine-tune mode ---
    # The user-facing toggle. Flipping this True kicks off a modal operator
    # that polishes the current pose with small Hooke-Jeeves steps until the
    # toggle goes back to False.
    fine_tune_enabled: BoolProperty(
        name="Fine-Tune Mode",
        description="Continuously polish the current pose with small steps. "
                    "When on, the camera (or object) is gently nudged toward "
                    "better matches without big jumps. Auto-Solve must be "
                    "stopped first",
        default=False,
        update=lambda self, ctx: _fine_tune_update(self, ctx),
    )
    fine_tune_running: BoolProperty(default=False)  # internal state
    fine_tune_status: StringProperty(default="")  # UI feedback string

    # Persistent mode (v2.7.1+): when ON, fine-tune doesn't auto-disable
    # when the reference image is swapped or when the user drags the
    # camera/object in the viewport. It just re-baselines and keeps polishing.
    # Default OFF preserves the original behavior — explicit opt-in keeps the
    # operator from running indefinitely for users who don't want it.
    fine_tune_persistent: BoolProperty(
        name="Persistent",
        description="Keep fine-tune running through reference-image changes "
                    "and manual pose moves. Without this, fine-tune turns "
                    "itself off whenever the reference is swapped or the "
                    "camera/object is dragged in the viewport, and you have "
                    "to flip the Polishing toggle back on each time. "
                    "With this on, fine-tune notices the change, re-scores "
                    "the new pose as a fresh baseline, and continues polishing",
        default=False,
    )

    fine_tune_target: EnumProperty(
        name="Polish",
        description="What fine-tune adjusts each tick",
        items=[
            ('CAMERA', "Camera",
             "Polish the camera pose around the target"),
            ('OBJECT', "Object",
             "Polish the target object's rotation and location"),
        ],
        default='CAMERA',
    )
    fine_tune_auto_enable: BoolProperty(
        name="Auto-Enable on Bullseye",
        description="Automatically turn on Fine-Tune when Auto-Solve finishes "
                    "with a high score",
        default=True,
    )
    fine_tune_threshold: FloatProperty(
        name="Bullseye Threshold",
        description="Auto-Solve scores at or above this trigger Fine-Tune",
        default=93.0, min=50.0, max=100.0,
    )

    # --- Algorithm choice ---
    camera_algorithm: EnumProperty(
        name="Algorithm",
        description="Which camera search algorithm to use for Auto-Solve",
        items=ALGORITHM_VERSIONS,
        default='CV',
    )

    # --- Scoring config (used by v3 contour scoring) ---
    edge_threshold: FloatProperty(
        name="Edge Sensitivity",
        description="Lower values detect more edges (good for soft images); "
                    "higher values reject noise (good for crisp renders)",
        default=0.15, min=0.05, max=0.5,
    )
    auto_invert_line_art: BoolProperty(
        name="Auto-Invert Line Art",
        description="Detect & invert images where the foreground is bright "
                    "(typical of wireframe renders against a dark background)",
        default=True,
    )

    # Reference feature cache key — operators.py uses this to invalidate the
    # ReferenceFeatures cache when the user changes the inputs to feature
    # extraction. Bumped automatically when relevant settings change.
    feature_cache_key: StringProperty(default="")

    # --- Camera intrinsics ---
    # Focal length / sensor dimensions for the player camera. Stored as a
    # nested group so the live-feed feature (v2.7) can reuse the same data
    # to interpret phone frames.
    intrinsics: PointerProperty(
        name="Camera Intrinsics",
        type=camera_intrinsics.PhotoMatchCameraIntrinsics,
    )

    # --- Live feed (handoff §5.2) ---
    # Read-only status flags + display strings + the QR/live image pointers.
    # The live_feed module is the source of truth; these properties are
    # mirrors that the UI can bind to. Mutated by operators and by the
    # 5 Hz display timer in live_feed.py — never by the user directly.
    live_feed_running: BoolProperty(
        name="Live Feed Running",
        description="True while the local HTTPS server is accepting "
                    "phone connections. Read-only — controlled by Start/Stop",
        default=False,
    )
    live_feed_phone_connected: BoolProperty(
        name="Phone Connected",
        description="True when a phone has an open WebSocket and frames are "
                    "arriving recently. Read-only",
        default=False,
    )
    live_feed_url: StringProperty(
        name="Live Feed URL",
        description="The HTTPS URL the phone should browse to. Shown beneath "
                    "the QR code so the user can also type it in if needed",
        default="",
    )
    live_feed_qr_image: PointerProperty(
        name="Live Feed QR Code",
        description="QR-code Blender image for the live feed URL — generated "
                    "when the server starts. Empty if the `qrcode` Python "
                    "package isn't installed",
        type=bpy.types.Image,
    )
    live_feed_last_frame_age_ms: IntProperty(
        name="Last Frame Age (ms)",
        description="Milliseconds since the most recent frame from the phone. "
                    "Useful for diagnosing dropouts — should sit around 200ms "
                    "while connected (5 Hz). Read-only",
        default=0,
        min=0,
    )
    live_feed_silhouette_only: BoolProperty(
        name="Silhouette Only",
        description="When matching against the live phone feed, keep only "
                    "the largest connected edge component. Reduces background "
                    "clutter interference. (Used by step 5+ matching — has "
                    "no effect on display alone.)",
        default=True,
    )

    # --- v2.8.1: Auto-camera + overlay (defaults updated in v2.8.4) ---
    # When the live feed starts, automatically ensure there's a camera to
    # look through and wire the feed as its background. The overlay render
    # was introduced in v2.8.1 with `live_feed_overlay_enabled=True` by
    # default; v2.8.4 flipped that to False because users with the default
    # Blender scene (containing a red cube) saw the cube render as the
    # overlay and got confused. The feature is still available as an
    # advanced opt-in for users with bespoke scenes who genuinely want
    # a transparent rendered overlay on top of the live feed.
    live_feed_auto_camera: BoolProperty(
        name="Auto-Create Camera",
        description="When the live feed starts: if no scene camera is set, "
                    "create one named 'PhotoMatch_LiveCam' and wire the live "
                    "feed as its background. If a camera already exists, "
                    "reuse it — just add the live feed to its backgrounds. "
                    "Off skips both behaviors entirely",
        default=True,
    )
    live_feed_overlay_enabled: BoolProperty(
        name="Render Scene Overlay (advanced)",
        description="Render the scene with a transparent background every "
                    "1 second, layered on top of the live feed in the camera "
                    "background. Useful for visualizing model-to-photo "
                    "alignment when your scene has the right object set up. "
                    "Disabled by default because the default Blender scene "
                    "(cube + light + camera) renders an opaque red cube on "
                    "top of the live feed, which surprises new users",
        default=False,
    )
    live_feed_overlay_alpha: FloatProperty(
        name="Overlay Opacity",
        description="Alpha for the rendered overlay. Lower = more of the "
                    "live feed shows through; 1.0 = opaque overlay",
        default=0.7, min=0.0, max=1.0,
        subtype='FACTOR',
    )

    # --- v2.8.4: Snapshot rate + freeze ---
    # The display timer used to fire at a fixed 5 Hz (DISPLAY_INTERVAL in
    # live_feed.py), which made the camera-background image flicker as it
    # updated 5×/sec. For photo-match workflows the user wants a stable
    # "polaroid" feel — one frame per second is plenty since the matcher
    # itself only ticks at 1 Hz by default. The interval is exposed as a
    # property so anyone needing more or less can dial it.
    live_feed_snapshot_interval: FloatProperty(
        name="Snapshot Every (s)",
        description="How often the live feed image is refreshed in the "
                    "camera background. 1 second feels like flipping "
                    "polaroids — stable, predictable. Smaller (0.1-0.5) "
                    "approaches real-time video; larger (3+) is good for "
                    "slow alignment work. The matcher reads frames "
                    "independently of this rate; this only affects what "
                    "you SEE in the viewport",
        default=1.0, min=0.1, max=10.0,
        subtype='TIME', unit='TIME',
    )
    live_feed_snapshot_freeze: BoolProperty(
        name="Freeze Snapshot",
        description="When ON, the camera-background image stops refreshing "
                    "and stays pinned to the current frame. Useful for "
                    "carefully aligning the Blender camera against a "
                    "specific reference moment without the image shifting "
                    "underneath you. Phone keeps streaming; only the "
                    "displayed snapshot is frozen",
        default=False,
    )

    # --- v2.8.2: Multi-camera search settings ---
    multi_cam_count: IntProperty(
        name="Number of Cameras",
        description="How many independent cameras search in parallel. "
                    "More cameras = broader coverage but more total evaluations. "
                    "Each camera uses the algorithm assigned by the mode below",
        default=10, min=1, max=50,
    )
    multi_cam_assignment: EnumProperty(
        name="Algorithm Assignment",
        description="How algorithms are distributed across cameras",
        items=[
            ('ROUND_ROBIN', "Round Robin (all different)",
             "Cycle through all 10 algorithm types. If more cameras than "
             "algorithms, the cycle repeats"),
            ('RANDOM', "Random Mix",
             "Each camera gets a randomly picked algorithm — may include "
             "duplicates. Good for shotgun exploration"),
            ('SINGLE', "All Same Algorithm",
             "Every camera uses the same algorithm (pick below). "
             "Good when you know which search technique suits your scene"),
        ],
        default='ROUND_ROBIN',
    )
    multi_cam_single_algo: EnumProperty(
        name="Algorithm",
        description="When 'All Same Algorithm' is selected, every camera "
                    "uses this technique",
        items=[
            ('FIBONACCI',  "Fibonacci Sphere",       "Even sphere coverage"),
            ('GAUSSIAN',   "Warm Gaussian",          "Tight samples near starting pose"),
            ('PID',        "PID Gradient",            "Finite-diff gradient + PID control"),
            ('PATTERN',    "Pattern Search",          "Hooke-Jeeves axis-aligned steps"),
            ('SPIRAL',     "Spiral Sweep",            "Archimedes spiral pole-to-equator"),
            ('ANNEALING',  "Simulated Annealing",     "Exponential cooling schedule"),
            ('LEVY',       "Lévy Walk",               "Power-law random walk"),
            ('GRID',       "Grid Sweep",              "Systematic theta/phi grid"),
            ('GOLDEN',     "Golden Section",           "1D golden-section per axis"),
            ('DE',         "Differential Evolution",   "Mini population optimizer"),
        ],
        default='FIBONACCI',
    )
    multi_cam_hotspot_threshold: FloatProperty(
        name="Hotspot Threshold",
        description="When any camera scores above this, all other cameras "
                    "converge on that spot to refine with their own algorithm. "
                    "Lower = earlier convergence (faster but may miss better spots). "
                    "Higher = more exploration before converging",
        default=80.0, min=50.0, max=95.0,
    )
    multi_cam_show_details: BoolProperty(
        name="Show Camera Details",
        description="Show per-camera score breakdown in the Auto-Solve progress",
        default=False,
    )

    # --- Live tracking / state machine state (handoff §5.3) ---
    # These mirror the state machine's runtime values into the property group
    # so the UI can bind to them. Mutated only by `live_tracking.py` (the
    # match timer + the Initial Lock / Re-Lock operators); the user toggles
    # only `tracking_auto_recover`.
    tracking_state: EnumProperty(
        name="Tracking State",
        description="Current regime of the live-tracking state machine. "
                    "Read-only — driven by score adaptiveness",
        items=[
            ('LOST',     "Lost",     "Searching for a pose"),
            ('TRACKING', "Tracking", "Have a rough pose, polishing"),
            ('LOCKED',   "Locked",   "Tight pose match, just polishing"),
        ],
        default='LOST',
    )
    tracking_locked: BoolProperty(
        name="Tracking Locked",
        description="True after Initial Lock has succeeded. Read-only — set "
                    "by the lock operators",
        default=False,
    )
    tracking_auto_recover: BoolProperty(
        name="Auto-Recover",
        description="When ON, dropping below 40% in TRACKING falls back to "
                    "LOST and runs a new full solve. When OFF (default), only "
                    "manual Re-Lock can demote to LOST. Useful when the phone "
                    "may briefly point away during normal use",
        default=False,
        update=_tracking_auto_recover_update,
    )
    tracking_last_score: FloatProperty(
        name="Tracking Last Score",
        description="Most recent score from the state machine. Used for UI "
                    "display only — transitions are driven by the SM itself",
        default=0.0, min=0.0, max=100.0,
    )
    tracking_stale_frame: BoolProperty(
        name="Stale Phone Frame",
        description="Set by the match-tick when no fresh phone frame has "
                    "arrived for ~2s. UI uses this to show a "
                    "'Phone disconnected, waiting…' banner. Read-only",
        default=False,
    )

    # --- Object Tracker ---
    obj_tracker_running: BoolProperty(
        name="Tracker Running",
        description="Whether the object tracker loop is currently active",
        default=False,
    )
    obj_tracker_status: StringProperty(
        name="Tracker Status",
        description="Current tracking status text",
        default="",
    )
    obj_tracker_confidence: FloatProperty(
        name="Confidence",
        description="Tracking confidence (0-100)",
        default=0.0, min=0.0, max=100.0,
    )
    obj_tracker_inliers: IntProperty(
        name="Inliers",
        description="Number of matched features this frame",
        default=0, min=0,
    )
    obj_tracker_total_features: IntProperty(
        name="Total Features",
        description="Total features in the reference map",
        default=0, min=0,
    )
    obj_tracker_reproj_error: FloatProperty(
        name="Reproj Error",
        description="Mean reprojection error in pixels",
        default=999.0,
    )
    obj_tracker_re_detect_interval: IntProperty(
        name="Re-detect Interval",
        description="Re-detect features every N frames to prevent drift. "
                    "Lower = less drift but more compute per cycle",
        default=15, min=3, max=60,
    )

    # --- Reference source dropdown (handoff §5.1) ---
    # Replaces the earlier "two buttons" pattern: instead of a random-config
    # box AND a separate "load image" button always visible side-by-side,
    # the user now picks ONE source from a dropdown and only that source's
    # configuration is shown. The Live Feed sub-panel auto-becomes visible
    # when LIVE_FEED is selected.
    reference_source: EnumProperty(
        name="Source",
        description="Where the reference image comes from",
        items=[
            ('RANDOM', "Random Challenge",
             "Place a hidden camera at a random angle around the target "
             "object, capture its view as the reference"),
            ('FILE', "Load Image File",
             "Load a reference image from disk (a photo, a screenshot, etc.)"),
            ('LIVE_FEED', "Live Phone Feed",
             "Stream frames from a phone camera over WebSocket and use the "
             "latest frame as the live reference"),
        ],
        default='RANDOM',
        update=_reference_source_update,
    )

    # --- State machine adaptive thresholds (handoff §5.4) ---
    # Defaults match the Thresholds dataclass in tracking_state.py. All four
    # bind to the same update callback which pushes the full quad into the
    # running SM (if any). Sliders are exposed in the Advanced sub-panel.
    threshold_lost_to_tracking: FloatProperty(
        name="LOST → TRACKING",
        description="Score at which a LOST regime promotes to TRACKING. "
                    "Lower = more eager to start polishing on weak matches",
        default=55.0, min=0.0, max=100.0,
        update=_tracking_thresholds_update,
    )
    threshold_tracking_to_locked: FloatProperty(
        name="TRACKING → LOCKED",
        description="Score at which TRACKING regime promotes to LOCKED. "
                    "Higher = stricter about declaring a clean lock",
        default=92.0, min=0.0, max=100.0,
        update=_tracking_thresholds_update,
    )
    threshold_locked_to_tracking: FloatProperty(
        name="LOCKED → TRACKING",
        description="Score below which LOCKED demotes to TRACKING. "
                    "The hysteresis gap (LOCKED→TRACKING vs TRACKING→LOCKED) "
                    "prevents flicker between the two regimes",
        default=80.0, min=0.0, max=100.0,
        update=_tracking_thresholds_update,
    )
    threshold_tracking_to_lost: FloatProperty(
        name="TRACKING → LOST",
        description="Score below which TRACKING falls back to LOST (only when "
                    "Auto-Recover is on). Lower = more tolerant of poor frames",
        default=40.0, min=0.0, max=100.0,
        update=_tracking_thresholds_update,
    )

    # --- Per-regime evaluation budgets (handoff §5.5) ---
    # The match-tick reads these directly each tick, so changes take effect
    # on the very next solve. No update callback needed.
    budget_full_solve: IntProperty(
        name="Full Solve Budget",
        description="Maximum V3 evaluations for the cold-start full solve "
                    "(Initial Lock + auto-recover). More evaluations = more "
                    "thorough search, but each tick takes longer",
        default=60, min=20, max=200,
    )
    budget_warm_solve: IntProperty(
        name="Warm Solve Budget",
        description="Maximum V3 evaluations for the warm solve in TRACKING "
                    "regime. Smaller = faster ticks, but fewer chances to "
                    "improve before the polish phase",
        default=15, min=5, max=60,
    )

    # --- Match-tick interval (handoff §7.5) ---
    # Decoupled from the 5 Hz display rate — even a slow match tick keeps
    # the viewport feeling smooth because the display timer keeps decoding
    # frames between matches.
    match_interval: FloatProperty(
        name="Match Interval (s)",
        description="How often the state machine ticks against the live "
                    "feed. Lower = more responsive, higher CPU. The display "
                    "rate is separate (always ~5 Hz)",
        default=1.0, min=0.2, max=5.0, step=10, precision=1,
    )


classes = (PhotoMatchProperties,)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.photo_match_props = PointerProperty(type=PhotoMatchProperties)


def unregister():
    if hasattr(bpy.types.Scene, "photo_match_props"):
        del bpy.types.Scene.photo_match_props
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
