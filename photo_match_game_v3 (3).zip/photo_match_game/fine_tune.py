"""Fine-tune mode — small continuous adjustments to keep the match polished.

Once Auto-Solve finds a near-match, the user often wants the system to *stay*
near that match while they iterate (e.g., loading a new reference and seeing
how much adjustment is needed). Restarting Auto-Solve every time is overkill —
it does a coarse sweep, big jumps, the whole thing.

Fine-tune mode is the opposite: a continuous low-energy polishing loop. Each
tick:
  1. Pick a small perturbation along one axis (rotation or position)
  2. Render and score
  3. If better: keep it, expand the step slightly
  4. If worse: revert, contract the step

This is **Hooke-Jeeves pattern search** with a hard cap on step size — the
"doesn't jump around" guarantee. No PID, no gradient probing, no global phases.
Just keeps the score gently climbing, or staying put if already converged.

Activation paths:
  - Manual: user clicks the Fine-Tune checkbox in the panel
  - Automatic: Auto-Solve finishes above the configured threshold (default 93%)

The modal yields to Auto-Solve so the two never fight over the camera, and
exits cleanly when the checkbox is unchecked or the reference is removed.
"""

import math
import os
import random
import tempfile

import bpy
import numpy as np
from bpy.types import Operator
from mathutils import Vector


# Tick interval — 0.4s is fast enough to feel "live", slow enough to not burn CPU
_TICK_INTERVAL = 0.4

# Hard caps on step magnitude — the "doesn't jump around" guarantee.
# These are absolute ceilings; even if pattern-search expansion would push
# the step bigger, we clamp here.
_MAX_ROTATION_STEP = 0.05    # ~3 degrees
_MAX_DISTANCE_FACTOR = 0.05  # 5% of current distance
_MAX_LOCATION_FACTOR = 0.03  # 3% of object's bounding-sphere radius

_INITIAL_ROTATION_STEP = 0.015  # ~0.85 degrees — gentle starting step
_INITIAL_DISTANCE_FACTOR = 0.02
_INITIAL_LOCATION_FACTOR = 0.01

# Render resolution for fine-tune scoring. Lower than auto-solve since we're
# already close to the optimum — fine differences matter, but we don't need
# global accuracy.
_QUICK_RES = 256


# ----------------------------------------------------------------------------
# Lazy imports — these reference modules in the same package, can't import at
# module load because of how Blender re-imports during reload. Pulled into
# functions instead.
# ----------------------------------------------------------------------------

def _imports():
    from . import camera_utils, geometry, image_features, rendering, scoring
    return camera_utils, geometry, image_features, rendering, scoring


def _get_or_build_features(props):
    """Wrapper to access the operators-module feature cache."""
    from . import operators
    return operators._get_or_build_reference_features(props)


# ----------------------------------------------------------------------------
# Scoring helper — used live in the tick loop
# ----------------------------------------------------------------------------

def _score_current_pose(scene, cam, props, contour_features=None):
    """Render and score from the current pose. Uses contour scoring when V3
    is the active algorithm; falls back to strict pixel scoring otherwise."""
    _, _, image_features, rendering, scoring = _imports()

    render_path = os.path.join(tempfile.gettempdir(), "photomatch_finetune.png")
    shading = getattr(props, 'render_shading_mode', 'VIEWPORT')
    shading_arg = None if shading == 'VIEWPORT' else shading
    rendering.render_camera_to_path(scene, cam, render_path,
                                    shading_mode=shading_arg)

    img = bpy.data.images.load(render_path, check_existing=False)
    try:
        if contour_features is not None:
            pixels = np.array(img.pixels[:], dtype=np.float32)
            pixels = pixels.reshape(img.size[1], img.size[0], 4)[..., :3]
            return image_features.contour_score(
                pixels, contour_features,
                edge_threshold=props.edge_threshold,
            )
        return scoring.pixel_similarity(props.reference_image, img, target_size=64)
    finally:
        bpy.data.images.remove(img)


# ----------------------------------------------------------------------------
# Standalone polish step — extracted for state-machine reuse (handoff §8.3)
# ----------------------------------------------------------------------------
#
# The modal operator below uses the same Hooke-Jeeves logic but ticks itself
# via Blender's window-manager timer system. The live-tracking state machine
# needs the SAME logic but invoked synchronously, one step at a time, from
# its 1 Hz match timer. Rather than duplicating the perturbation+evaluate+
# accept/revert dance, we extract it into a `CameraPolisher` class that
# carries Hooke-Jeeves step state across calls. The modal could be refactored
# to use this class too — for now they coexist since the operator's lifecycle
# (UI status updates, scene-resolution save/restore) is meaningfully different
# from the state-machine's "just give me the new score" contract.

class CameraPolisher:
    """One Hooke-Jeeves perturbation per call. Stateful — holds the per-axis
    step sizes that grow on success and shrink on miss.

    Used by `live_tracking.py` as the LOCKED-regime executor: each match-timer
    tick, call `polisher.step(scene, cam, props, contour_features)` and the
    polisher mutates the camera in-place and returns the resulting score.

    Same algorithm shape as the existing modal operator. Differences:
      - No render-resolution save/restore — caller manages that
      - No fine_tune_status mirroring — caller decides what to surface
      - Score read is the polisher's own; doesn't touch props.score directly
    """

    def __init__(self, initial_score=None):
        # Per-axis Hooke-Jeeves step sizes. Same defaults as the modal.
        self._step_rotation = _INITIAL_ROTATION_STEP
        self._step_distance = _INITIAL_DISTANCE_FACTOR
        self._step_location = _INITIAL_LOCATION_FACTOR
        # last_score is `None` on the first call, populated thereafter.
        # On the first call we score the current pose (no perturbation),
        # which gives the SM a baseline before perturbing happens.
        self._last_score = float(initial_score) if initial_score is not None else None

    @property
    def last_score(self):
        return self._last_score if self._last_score is not None else 0.0

    def step(self, scene, cam, props, contour_features=None):
        """Do one Hooke-Jeeves polish step. Returns the resulting score
        (the score of whichever pose ends up active — accepted-or-reverted)."""
        camera_utils, geometry, _, _, _ = _imports()

        target = props.target_object
        if target is None or cam is None:
            # No target / camera → can't polish. Return whatever we last knew.
            return self.last_score

        target_center, _r = geometry.target_center_and_radius(target)

        # On the very first call we have no baseline — score the current
        # pose without perturbing. This matches the modal's `invoke()` flow,
        # which scores once before entering the timer loop.
        if self._last_score is None:
            self._last_score = float(_score_current_pose(
                scene, cam, props, contour_features
            ))
            return self._last_score

        # --- Perturb one axis ---
        saved_matrix = cam.matrix_world.copy()
        axis = random.choice(('pitch', 'yaw', 'distance'))
        sign = random.choice((1.0, -1.0))

        offset = cam.matrix_world.translation - target_center
        distance = max(offset.length, 0.001)
        direction = offset / distance

        if axis == 'pitch':
            step = sign * self._step_rotation
            rotated = _rotate_around_axis(direction, Vector((1, 0, 0)), step)
            new_loc = target_center + rotated * distance
            camera_utils.position_camera(cam, new_loc, target_center)
            kind = 'rotation'
        elif axis == 'yaw':
            step = sign * self._step_rotation
            rotated = _rotate_around_axis(direction, Vector((0, 0, 1)), step)
            new_loc = target_center + rotated * distance
            camera_utils.position_camera(cam, new_loc, target_center)
            kind = 'rotation'
        else:  # distance
            step = sign * self._step_distance
            new_distance = max(distance * (1.0 + step), 0.1)
            new_loc = target_center + direction * new_distance
            camera_utils.position_camera(cam, new_loc, target_center)
            kind = 'distance'

        # --- Score and accept-or-revert ---
        try:
            new_score = float(_score_current_pose(
                scene, cam, props, contour_features
            ))
        except Exception as e:
            cam.matrix_world = saved_matrix
            print(f"[live_tracking] polish scoring failed, reverted: {e}")
            return self._last_score

        if new_score > self._last_score:
            # Accept: keep new pose, expand step (capped)
            self._last_score = new_score
            if kind == 'rotation':
                self._step_rotation = min(
                    self._step_rotation * 1.4, _MAX_ROTATION_STEP
                )
            else:  # distance
                self._step_distance = min(
                    self._step_distance * 1.4, _MAX_DISTANCE_FACTOR
                )
        else:
            # Revert: restore saved matrix, contract step
            cam.matrix_world = saved_matrix
            if kind == 'rotation':
                self._step_rotation = max(self._step_rotation * 0.6, 0.002)
            else:  # distance
                self._step_distance = max(self._step_distance * 0.6, 0.003)

        return self._last_score


def _rotate_around_axis(vec, axis, angle):
    """Rodrigues rotation formula. Module-level twin of the operator's
    static method, exposed so CameraPolisher can use it without
    importing the operator class."""
    axis = axis.normalized()
    cos_a = math.cos(angle)
    sin_a = math.sin(angle)
    return (
        vec * cos_a
        + axis.cross(vec) * sin_a
        + axis * (axis.dot(vec)) * (1.0 - cos_a)
    )


def _matrices_close(a, b, eps=1e-6):
    """Compare two `mathutils.Matrix` (or any iterable-of-iterables) values
    element-wise with a small tolerance.

    Used by the persistent-mode rebaseline detector to tell "I haven't moved"
    from "the user dragged the camera". Exact equality would be fine in
    principle (Blender doesn't perturb matrices on its own), but this is
    cheap insurance against float-roundtrip surprises in matrix copies."""
    try:
        for row_a, row_b in zip(a, b):
            for av, bv in zip(row_a, row_b):
                if abs(float(av) - float(bv)) > eps:
                    return False
        return True
    except (TypeError, ValueError):
        # Mismatched shapes or non-iterable inputs — treat as different
        return False


# ----------------------------------------------------------------------------
# Recovery decision logic (v2.7.3)
# ----------------------------------------------------------------------------
#
# Pulled out as a module-level function so it's testable without bpy. The
# operator's modal tick calls this once per tick (when persistent mode is on
# and no recovery is already running) and acts on the returned action.
#
# The three triggers correspond to user-visible failure modes:
#
#   1. CATASTROPHIC DROP — the score collapsed (current < 30). Always full V3.
#      Doesn't depend on peak or stagnation; if you're at 12% something major
#      changed (reference swap, big object move) and the polisher can't fix it.
#
#   2. MAJOR DROP FROM PEAK — we had a lock (peak ≥ 80) but lost it
#      (current < 60). Full V3 — we know roughly where to look, but the
#      polisher's tiny steps won't claw back from this far out.
#
#   3. STAGNATION — the polisher hasn't improved in a while AND the current
#      score is below "good enough":
#        * STAGNATION_WARM_TICKS at score < 70 → try a warm V3 first
#          (cheap, ~15 evals; might just need to find an adjacent basin)
#        * STAGNATION_FULL_TICKS at score < 60 → full V3
#          (we tried warm, it didn't help — go big)
#
# Why warm-first for stagnation: warm V3 starts from the current pose and
# does a tight Gaussian shell, taking ~3-4 ticks at 5 evals/chunk. If the
# user just moved the camera by 30°, warm finds the basin almost instantly.
# Full V3 takes ~12-15 ticks at the same chunk size — overkill for small
# drifts.

_STAGNATION_WARM_TICKS = 12   # ticks of no-improvement at score < 70 → try warm
_STAGNATION_FULL_TICKS = 25   # ticks of no-improvement at score < 60 → try full
_CATASTROPHIC_SCORE = 30.0    # below this, always go full immediately
_MAJOR_DROP_PEAK = 80.0       # peak threshold for major-drop trigger
_MAJOR_DROP_CURRENT = 60.0    # current threshold for major-drop trigger


def _decide_recovery_action(*, peak_score, last_score, ticks_since_improvement,
                            recovery_attempts, max_attempts):
    """Decide whether to start a recovery solve, and which kind.

    Returns 'WARM', 'FULL', or None. The modal tick uses the return value
    to either start a chunked V3 generator or just keep polishing.

    Args:
        peak_score: highest score seen during this polishing session
        last_score: most recent score (or None if not yet computed)
        ticks_since_improvement: ticks since `_last_score` last improved
            by more than the noise floor
        recovery_attempts: count of recoveries already started this session
        max_attempts: upper bound on recoveries per session

    Pure function — no side effects. The operator class state (cooldown,
    attempts, etc.) is checked at the call site.
    """
    if recovery_attempts >= max_attempts:
        return None
    if last_score is None:
        return None

    # Trigger 1: Catastrophic drop. Always full, regardless of history.
    if last_score < _CATASTROPHIC_SCORE:
        return 'FULL'

    # Trigger 2: Major drop from a known-good peak.
    if peak_score >= _MAJOR_DROP_PEAK and last_score < _MAJOR_DROP_CURRENT:
        return 'FULL'

    # Trigger 3a: Deep stagnation at a poor score. Full.
    if (ticks_since_improvement >= _STAGNATION_FULL_TICKS
            and last_score < _MAJOR_DROP_CURRENT):
        return 'FULL'

    # Trigger 3b: Stagnation at a moderate score. Try warm first.
    if (ticks_since_improvement >= _STAGNATION_WARM_TICKS
            and last_score < 70.0):
        return 'WARM'

    return None


# ----------------------------------------------------------------------------
# Modal operator — the polishing loop
# ----------------------------------------------------------------------------

class PHOTOMATCH_OT_FineTune(Operator):
    """Continuously polish the current pose with small Hooke-Jeeves steps.

    Started by setting `props.fine_tune_enabled = True`. Stops cleanly when
    the property goes False, when the reference is removed, or when Auto-Solve
    starts (so they don't fight over the camera).
    """
    bl_idname = "photomatch.fine_tune"
    bl_label = "Fine-Tune"
    bl_description = ("Continuously polish the current pose with small "
                      "Hooke-Jeeves steps. Stops when the Fine-Tune checkbox "
                      "is unchecked.")

    _timer = None
    _saved_resolution = None
    _contour_features = None
    _current_step = None  # one of the *_step values, depends on target axis
    _last_score = None

    # ---- Auto-aligner / recovery (v2.7.3 — user feedback follow-up) ----
    # When persistent mode is on, fine-tune behaves as an auto-aligner:
    # if it can't make progress with Hooke-Jeeves, it kicks off a CHUNKED
    # V3 solve (warm or full depending on how stuck we are) that runs
    # across multiple ticks so the UI doesn't freeze.
    #
    # Three trigger conditions (see `_decide_recovery_action`):
    #   1. Catastrophic drop (score < 30) → full V3
    #   2. Major drop from peak (peak ≥ 80, current < 60) → full V3
    #   3. Stagnation:
    #        12 ticks of no-improvement at score < 70 → warm V3 (cheap)
    #        25 ticks of no-improvement at score < 60 → full V3
    #
    # Recovery is gated on `fine_tune_persistent` so opt-in users get the
    # auto-aligner behavior; off-mode keeps pure Hooke-Jeeves.

    # Chunked recovery state: when not None, the modal tick advances this
    # generator instead of polishing. On StopIteration, the result is applied.
    _recovery_generator = None
    _recovery_kind = None         # 'WARM' or 'FULL' while generator active
    _recovery_evals_done = 0      # progress counter for status string
    _recovery_evals_target = 0    # max_evals for the active recovery

    # Recovery bookkeeping (preserved across recovery cycles within a session)
    _peak_score = 0.0
    _recovery_cooldown = 0        # ticks until next recovery is allowed
    _recovery_attempts = 0        # session-level cap

    # Stagnation tracking — fed by every successful polish step
    _ticks_since_improvement = 0
    _last_improvement_score = None

    # Cap on recoveries per modal session — prevents runaway loops if the
    # scene is fundamentally wrong (e.g. wrong target object selected).
    # Reset to 0 every time a recovery succeeds (lands above _MAJOR_DROP_PEAK),
    # so legitimate repeated-rescue cycles aren't penalized.
    _RECOVERY_MAX_ATTEMPTS = 5
    # Ticks to wait after a recovery completes before considering another.
    # Gives the polisher time to score the new pose and start fresh.
    _RECOVERY_COOLDOWN_TICKS = 6
    # Evals per chunked-generator yield. Smaller = smoother UI but more
    # per-chunk overhead. 5 × ~30ms/eval = ~150ms per chunk, which is
    # imperceptible at the modal's tick rate.
    _RECOVERY_CHUNK_SIZE = 5
    # Max evals for warm recovery — enough to find a nearby basin without
    # blowing the budget on a search that should be a quick hop.
    _RECOVERY_WARM_MAX_EVALS = 15
    # The full-recovery max-eval cap reads from props.budget_full_solve at
    # call time so the Advanced slider applies. Default fallback only:
    _RECOVERY_FULL_MAX_EVALS_DEFAULT = 60

    @classmethod
    def poll(cls, context):
        # Don't allow starting if reference is missing
        return getattr(context.scene, 'photo_match_props', None) is not None

    def invoke(self, context, event):
        scene = context.scene
        props = scene.photo_match_props

        if props.reference_image is None:
            self.report({'INFO'}, "Fine-tune needs a reference image first")
            props.fine_tune_enabled = False
            return {'CANCELLED'}

        if props.auto_solve_running:
            self.report({'INFO'}, "Fine-tune disabled while Auto-Solve is running")
            props.fine_tune_enabled = False
            return {'CANCELLED'}

        if props.fine_tune_running:
            # Already running — invoking again is a no-op
            return {'CANCELLED'}

        # Build contour features when V3 is the active algo
        self._contour_features = None
        if props.camera_algorithm == 'V3':
            try:
                self._contour_features = _get_or_build_features(props)
            except Exception as e:
                print(f"Photo Match fine-tune: contour features unavailable, "
                      f"falling back to pixel scoring: {e}")

        # Lower render resolution for fast scoring
        self._saved_resolution = (
            scene.render.resolution_x,
            scene.render.resolution_y,
        )
        ref = props.reference_image
        if ref.size[0] > 0 and ref.size[1] > 0:
            aspect = ref.size[0] / ref.size[1]
            if aspect >= 1:
                scene.render.resolution_x = _QUICK_RES
                scene.render.resolution_y = max(2, int(_QUICK_RES / aspect))
            else:
                scene.render.resolution_y = _QUICK_RES
                scene.render.resolution_x = max(2, int(_QUICK_RES * aspect))

        # Initial step size depends on which axis we'll perturb first; we set
        # per-axis step sizes inside _step() rather than tracking globally.
        self._step_rotation = _INITIAL_ROTATION_STEP
        self._step_distance = _INITIAL_DISTANCE_FACTOR
        self._step_location = _INITIAL_LOCATION_FACTOR

        # Persistent-mode state (v2.7.1+ — item 1 in user feedback): track
        # the reference image's identity and the most recent camera/object
        # matrices we set ourselves, so the modal can detect external
        # changes between ticks and re-baseline rather than dying.
        self._last_reference_name = (
            props.reference_image.name if props.reference_image else None
        )
        self._last_known_camera_matrix = None
        self._last_known_object_matrix = None
        self._iterations_done = 0

        # Recovery state (v2.7.3): chunked-generator handle + tracking for
        # stagnation detection and the per-session attempt cap.
        self._recovery_generator = None
        self._recovery_kind = None
        self._recovery_evals_done = 0
        self._recovery_evals_target = 0
        self._peak_score = 0.0
        self._recovery_cooldown = 0
        self._recovery_attempts = 0
        self._ticks_since_improvement = 0
        self._last_improvement_score = None

        # Score the starting pose so we have a baseline to compare perturbations
        cam = scene.camera
        if cam is None:
            self.report({'INFO'}, "Fine-tune needs an active camera")
            self._cleanup_render_settings(scene)
            props.fine_tune_enabled = False
            return {'CANCELLED'}
        try:
            self._last_score = _score_current_pose(
                scene, cam, props, self._contour_features
            )
        except Exception as e:
            print(f"Photo Match fine-tune: initial score failed: {e}")
            self._cleanup_render_settings(scene)
            props.fine_tune_enabled = False
            return {'CANCELLED'}

        # Record initial pose for "did someone move this?" detection
        self._last_known_camera_matrix = cam.matrix_world.copy()
        if props.target_object is not None:
            self._last_known_object_matrix = props.target_object.matrix_world.copy()

        props.fine_tune_running = True
        props.fine_tune_status = f"Polishing... ({self._last_score:.1f}%)"

        # Tick rate (item 4 in user feedback): tied to props.match_interval
        # so the Advanced "Match Tick Rate" slider controls fine-tune cadence
        # too. Falls back to the module default if the property is absent.
        wm = context.window_manager
        self._current_interval = float(getattr(props, 'match_interval', _TICK_INTERVAL))
        self._timer = wm.event_timer_add(self._current_interval, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        scene = context.scene
        props = scene.photo_match_props
        persistent = getattr(props, 'fine_tune_persistent', False)

        # User-explicit disable always wins, persistent or not.
        if not props.fine_tune_enabled:
            return self._finish(context)

        # Auto-Solve and fine-tune fight over the camera; pause cleanly.
        # Persistent mode doesn't override this — they really can't coexist.
        if props.auto_solve_running:
            props.fine_tune_enabled = False
            props.fine_tune_status = "Paused (Auto-Solve running)"
            return self._finish(context)

        # Reference-image presence:
        #   Default behavior  → bail
        #   Persistent mode   → idle until a reference reappears
        if props.reference_image is None:
            if persistent:
                props.fine_tune_status = "Persistent: waiting for reference…"
                return {'PASS_THROUGH'}
            props.fine_tune_enabled = False
            return self._finish(context)

        if event.type == 'TIMER':
            # Honor mid-modal changes to the match-interval slider (item 4
            # in user feedback). Re-register the timer at the new rate when
            # it changes; otherwise leave it alone. Tiny epsilon avoids
            # thrashing on float-comparison noise.
            new_interval = float(getattr(props, 'match_interval',
                                         self._current_interval))
            if abs(new_interval - self._current_interval) > 1e-3:
                wm = context.window_manager
                if self._timer is not None:
                    wm.event_timer_remove(self._timer)
                self._timer = wm.event_timer_add(new_interval, window=context.window)
                self._current_interval = new_interval

            # ----- Chunked recovery in progress: advance, don't polish -----
            # When a recovery generator is alive, this tick advances it by
            # one chunk (~5 evals). The generator pauses between chunks so
            # the modal can return PASS_THROUGH and let the UI breathe.
            # On StopIteration we wrap up and resume normal polishing next
            # tick.
            if self._recovery_generator is not None:
                self._advance_recovery_chunk(scene, props, context)
                return {'PASS_THROUGH'}

            # Persistent-mode rebaseline (item 1 in user feedback): if the
            # user changed the picture or moved the model, re-establish the
            # score baseline before perturbing this tick. Otherwise the
            # stale `_last_score` would reject every perturbation against
            # the new (likely worse) starting pose.
            if persistent:
                self._maybe_rebaseline(scene, props)

            # ----- Recovery decision (persistent mode only) -----
            # Pure decision based on peak/current/stagnation. If the function
            # says start a recovery, kick off the chunked generator and
            # return — recovery takes over from the next tick onward.
            if persistent:
                if self._recovery_cooldown > 0:
                    self._recovery_cooldown -= 1
                else:
                    action = _decide_recovery_action(
                        peak_score=self._peak_score,
                        last_score=self._last_score,
                        ticks_since_improvement=self._ticks_since_improvement,
                        recovery_attempts=self._recovery_attempts,
                        max_attempts=self._RECOVERY_MAX_ATTEMPTS,
                    )
                    if action is not None:
                        self._begin_recovery(action, scene, props)
                        return {'PASS_THROUGH'}

            # ----- Normal polish step -----
            try:
                prev_score = self._last_score
                self._step(scene, props)
                self._iterations_done += 1
                self._update_polish_tracking(prev_score)
                self._update_polishing_status(props)
            except Exception as e:
                print(f"Photo Match fine-tune step error: {e}")
                # Continue rather than dying — one bad render shouldn't kill
                # the whole loop

        return {'PASS_THROUGH'}

    # ----- v2.7.3 helpers: stagnation tracking, chunked recovery -----

    def _update_polish_tracking(self, prev_score):
        """Update peak score and stagnation counter after a polish step.

        "Improvement" is a half-point gain — small enough that genuine
        progress isn't dismissed as noise, large enough that score-floor
        chatter (where the polisher's accept-or-revert just reproduces the
        same baseline ±0.1%) doesn't reset the stagnation clock."""
        cur = self._last_score
        if cur is None:
            return
        # Peak tracker
        if cur > self._peak_score:
            self._peak_score = cur
        # Stagnation tracker
        if (self._last_improvement_score is None
                or cur > self._last_improvement_score + 0.5):
            self._last_improvement_score = cur
            self._ticks_since_improvement = 0
        else:
            self._ticks_since_improvement += 1

    def _update_polishing_status(self, props):
        """Format the status string for the polishing path. Keeps the user
        informed about iter count, current score, and (when relevant) peak
        and stagnation. Silent on the recovery state — the recovery code
        owns its own status strings."""
        if self._last_score is None:
            return
        cur = self._last_score
        bits = [f"Polishing… iter {self._iterations_done}, {cur:.1f}%"]
        if self._peak_score > cur + 5.0:
            bits.append(f"peak {self._peak_score:.1f}%")
        if self._ticks_since_improvement >= 6:
            bits.append(f"stagnant {self._ticks_since_improvement}t")
        props.fine_tune_status = ", ".join(bits)

    def _begin_recovery(self, kind, scene, props):
        """Start a chunked V3 generator. The next tick (and the following
        few, depending on chunk size and total budget) will advance the
        generator one chunk at a time.

        WARM = warm-start V3 with a tight budget — for "found a near-miss
        basin, look around" cases.
        FULL = cold-start V3 with the full budget — for "lost the lock,
        find me anywhere on the sphere" cases.
        """
        from . import live_tracking
        max_evals = (
            self._RECOVERY_WARM_MAX_EVALS if kind == 'WARM'
            else int(getattr(props, 'budget_full_solve',
                             self._RECOVERY_FULL_MAX_EVALS_DEFAULT))
        )
        try:
            self._recovery_generator = live_tracking._run_v3_search_chunked(
                scene, props,
                cold_start=(kind == 'FULL'),
                evals_per_yield=self._RECOVERY_CHUNK_SIZE,
                max_evals=max_evals,
            )
        except Exception as e:
            print(f"[fine_tune] Could not start {kind} recovery: {e}")
            self._recovery_generator = None
            self._recovery_kind = None
            self._recovery_cooldown = self._RECOVERY_COOLDOWN_TICKS
            self._recovery_attempts += 1
            return

        self._recovery_kind = kind
        self._recovery_evals_done = 0
        self._recovery_evals_target = max_evals
        self._recovery_attempts += 1
        # While the generator runs, the polisher's last_score becomes
        # meaningless — V3 will write a new pose. Clear it so the
        # post-recovery rebaseline path scores the new pose fresh.
        self._last_score = None
        props.fine_tune_status = (
            f"Recovering ({kind.lower()}) — {self._recovery_evals_done}"
            f"/{self._recovery_evals_target} evals"
        )

    def _advance_recovery_chunk(self, scene, props, context):
        """Run the active recovery generator for one chunk. Updates the
        status string, and on StopIteration finalizes the recovery and
        resets state so the next tick polishes normally."""
        try:
            next(self._recovery_generator)
            # Generator yielded — chunk done, more to go
            self._recovery_evals_done += self._RECOVERY_CHUNK_SIZE
            done = min(self._recovery_evals_done, self._recovery_evals_target)
            props.fine_tune_status = (
                f"Recovering ({self._recovery_kind.lower()}) — "
                f"{done}/{self._recovery_evals_target} evals"
            )
            # Tag viewport so the camera updates as V3 walks the sphere
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        except StopIteration as e:
            # Generator exhausted — V3 done. The final-best pose is already
            # applied by `_run_v3_search_chunked`; we just need to clean up.
            final_score = float(e.value if e.value is not None else 0.0)
            kind = self._recovery_kind
            # Reset Hooke-Jeeves step sizes — old shrunken steps were tuned
            # to the previous (lost) basin. Start the new basin fresh so
            # the polisher can actually move.
            self._step_rotation = _INITIAL_ROTATION_STEP
            self._step_distance = _INITIAL_DISTANCE_FACTOR
            self._step_location = _INITIAL_LOCATION_FACTOR
            # Force next tick to score the new pose as the fresh baseline
            self._last_score = None
            self._ticks_since_improvement = 0
            self._last_improvement_score = None
            # If recovery succeeded (above peak threshold), allow more
            # recoveries down the line; otherwise the cap stays.
            if final_score >= _MAJOR_DROP_PEAK:
                self._recovery_attempts = 0
                self._peak_score = max(self._peak_score, final_score)
            # Cooldown so a low-success recovery doesn't immediately retry
            self._recovery_cooldown = self._RECOVERY_COOLDOWN_TICKS
            # Update tracked matrices so the next-tick rebaseline doesn't
            # ALSO fire (V3 just moved the camera — that move was ours)
            cam = scene.camera
            if cam is not None:
                self._last_known_camera_matrix = cam.matrix_world.copy()
            target = props.target_object
            if target is not None:
                self._last_known_object_matrix = target.matrix_world.copy()
            # Status string
            verb = "Recovered" if final_score >= _MAJOR_DROP_CURRENT else "Recovery weak"
            props.fine_tune_status = f"{verb} ({kind.lower()}): {final_score:.1f}%"
            # Generator is dead — clear it
            self._recovery_generator = None
            self._recovery_kind = None
            # Final viewport tag
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        except Exception as e:
            # Generator blew up — log, drop it, cool down, continue
            print(f"[fine_tune] Recovery generator error: {e}")
            self._recovery_generator = None
            self._recovery_kind = None
            self._recovery_cooldown = self._RECOVERY_COOLDOWN_TICKS
            props.fine_tune_status = f"Recovery error (see console)"

    def _maybe_rebaseline(self, scene, props):
        """Persistent-mode change detection. Sets `_last_score = None` if
        the reference image was swapped or the camera/object was moved
        externally between ticks; the next `_step` will re-score the
        current pose as a fresh baseline before perturbing.

        Detection bounds: cheap. Compares one string and (per-mode) one
        Matrix per tick. Render time dwarfs this by 4-5 orders of magnitude.
        """
        # Reference change → also rebuild contour features so V3 scoring
        # uses the right feature set
        ref = props.reference_image
        if ref is not None and ref.name != self._last_reference_name:
            self._last_reference_name = ref.name
            self._last_score = None
            try:
                if props.camera_algorithm == 'V3':
                    self._contour_features = _get_or_build_features(props)
                else:
                    self._contour_features = None
            except Exception as e:
                print(f"Photo Match fine-tune: feature rebuild failed: {e}")
                self._contour_features = None

        # Camera matrix change (always relevant — even in OBJECT mode the
        # camera could have been dragged, which invalidates the score)
        cam = scene.camera
        if cam is not None and self._last_known_camera_matrix is not None:
            if not _matrices_close(cam.matrix_world,
                                   self._last_known_camera_matrix):
                self._last_score = None

        # Object matrix change (only relevant in OBJECT mode, but the user
        # can also move the target between modes — keep tracking it always)
        target = props.target_object
        if target is not None and self._last_known_object_matrix is not None:
            if not _matrices_close(target.matrix_world,
                                   self._last_known_object_matrix):
                self._last_score = None

    def _step(self, scene, props):
        """One Hooke-Jeeves perturbation. Pick an axis at random, try ±step,
        accept the better outcome, adjust step size."""
        cam = scene.camera
        if cam is None:
            return

        target_mode = props.fine_tune_target
        # If we're polishing the object, validate it
        if target_mode == 'OBJECT':
            obj = props.target_object
            if obj is None:
                # Quietly switch back to camera mode if no object set
                target_mode = 'CAMERA'

        # Pick what to perturb. For camera: rotation around the target, or
        # distance to it. For object: rotation_euler component, or location
        # component.
        if target_mode == 'CAMERA':
            self._step_camera(scene, cam, props)
        else:
            self._step_object(scene, cam, props)

    # --- Camera polishing -------------------------------------------------

    def _step_camera(self, scene, cam, props):
        """Perturb camera direction or distance and accept-or-revert."""
        camera_utils, geometry, _, _, _ = _imports()

        target = props.target_object
        if target is None:
            # Need a target so we know what to orbit around
            return
        target_center, _r = geometry.target_center_and_radius(target)

        # Persistent-mode rebaseline: if `_maybe_rebaseline` cleared
        # `_last_score`, score the current pose first to establish a fresh
        # baseline. Skip the perturbation this tick — we only get a useful
        # accept/revert decision once we have something to compare to.
        if self._last_score is None:
            try:
                self._last_score = float(_score_current_pose(
                    scene, cam, props, self._contour_features
                ))
            except Exception as e:
                print(f"[fine_tune] rebaseline score failed: {e}")
                return
            self._last_known_camera_matrix = cam.matrix_world.copy()
            return

        # Save state for revert
        saved_matrix = cam.matrix_world.copy()

        # Pick axis: 'pitch', 'yaw', or 'distance'
        axis = random.choice(('pitch', 'yaw', 'distance'))
        sign = random.choice((1.0, -1.0))

        # Compute current direction from target → camera, and distance
        offset = cam.matrix_world.translation - target_center
        distance = max(offset.length, 0.001)
        direction = offset / distance  # Vector

        if axis == 'pitch':
            # Rotate the direction around the world X axis (up-down)
            step = sign * self._step_rotation
            rotated = self._rotate_around_axis(direction, Vector((1, 0, 0)), step)
            new_loc = target_center + rotated * distance
            camera_utils.position_camera(cam, new_loc, target_center)
            step_was = ('rotation', step)
        elif axis == 'yaw':
            step = sign * self._step_rotation
            rotated = self._rotate_around_axis(direction, Vector((0, 0, 1)), step)
            new_loc = target_center + rotated * distance
            camera_utils.position_camera(cam, new_loc, target_center)
            step_was = ('rotation', step)
        else:  # distance
            step = sign * self._step_distance
            new_distance = max(distance * (1.0 + step), 0.1)
            new_loc = target_center + direction * new_distance
            camera_utils.position_camera(cam, new_loc, target_center)
            step_was = ('distance', step)

        # Score and accept-or-revert
        self._evaluate_and_resolve(scene, cam, props, saved_matrix, step_was)

        # Record the post-step matrix for next-tick external-change detection
        self._last_known_camera_matrix = cam.matrix_world.copy()

    @staticmethod
    def _rotate_around_axis(vec, axis, angle):
        """Rodrigues rotation formula. Rotates `vec` around `axis` by `angle`."""
        axis = axis.normalized()
        cos_a = math.cos(angle)
        sin_a = math.sin(angle)
        return (
            vec * cos_a
            + axis.cross(vec) * sin_a
            + axis * (axis.dot(vec)) * (1.0 - cos_a)
        )

    # --- Object polishing -------------------------------------------------

    def _step_object(self, scene, cam, props):
        """Perturb object rotation or location and accept-or-revert."""
        obj = props.target_object
        if obj is None:
            return

        # Persistent-mode rebaseline (mirror of the _step_camera path).
        if self._last_score is None:
            try:
                self._last_score = float(_score_current_pose(
                    scene, cam, props, self._contour_features
                ))
            except Exception as e:
                print(f"[fine_tune] rebaseline score failed: {e}")
                return
            self._last_known_object_matrix = obj.matrix_world.copy()
            self._last_known_camera_matrix = cam.matrix_world.copy()
            return

        # Save state for revert
        saved_rotation = obj.rotation_euler.copy()
        saved_location = obj.location.copy()
        if obj.rotation_mode != 'XYZ':
            obj.rotation_mode = 'XYZ'

        kind = random.choice(('rotation', 'location'))
        component = random.randint(0, 2)
        sign = random.choice((1.0, -1.0))

        if kind == 'rotation':
            step = sign * self._step_rotation
            obj.rotation_euler[component] = saved_rotation[component] + step
            step_was = ('rotation', step)
        else:
            # Use object's bounding sphere as the location-step scale
            from . import geometry as geom
            _, target_radius = geom.target_center_and_radius(obj)
            location_step = sign * self._step_location * max(target_radius, 0.5)
            obj.location[component] = saved_location[component] + location_step
            step_was = ('location', sign * self._step_location)

        # Score and accept-or-revert
        self._evaluate_and_resolve_object(
            scene, cam, props, obj, saved_rotation, saved_location, step_was,
        )

        # Record post-step object matrix for next-tick external-change detection
        self._last_known_object_matrix = obj.matrix_world.copy()

    # --- Common evaluate/resolve logic ------------------------------------

    def _evaluate_and_resolve(self, scene, cam, props, saved_matrix, step_was):
        """Score the perturbed camera; accept (update step sizes for success)
        or revert to `saved_matrix` (and contract step)."""
        try:
            new_score = _score_current_pose(
                scene, cam, props, self._contour_features
            )
        except Exception as e:
            cam.matrix_world = saved_matrix
            print(f"Fine-tune scoring failed, reverted: {e}")
            return
        self._handle_score_result(props, new_score, step_was,
                                  on_revert=lambda: setattr(cam, 'matrix_world', saved_matrix))

    def _evaluate_and_resolve_object(self, scene, cam, props, obj,
                                     saved_rotation, saved_location, step_was):
        try:
            new_score = _score_current_pose(
                scene, cam, props, self._contour_features
            )
        except Exception as e:
            obj.rotation_euler = saved_rotation
            obj.location = saved_location
            print(f"Fine-tune scoring failed, reverted: {e}")
            return

        def revert():
            obj.rotation_euler = saved_rotation
            obj.location = saved_location

        self._handle_score_result(props, new_score, step_was, on_revert=revert)

    def _handle_score_result(self, props, new_score, step_was, on_revert):
        """Common Hooke-Jeeves accept/revert + step-size adjustment."""
        kind, _step_value = step_was

        if new_score > self._last_score:
            # Improvement: keep the move, expand step (but capped)
            self._last_score = new_score
            if kind == 'rotation':
                self._step_rotation = min(
                    self._step_rotation * 1.4, _MAX_ROTATION_STEP
                )
            elif kind == 'distance':
                self._step_distance = min(
                    self._step_distance * 1.4, _MAX_DISTANCE_FACTOR
                )
            else:  # location
                self._step_location = min(
                    self._step_location * 1.4, _MAX_LOCATION_FACTOR
                )
            props.fine_tune_status = (
                f"Polishing... {self._last_score:.1f}% ↑"
            )
            # Mirror to the main score display so live UI reflects it
            if self._contour_features is None:
                props.pixel_score = new_score
                # Recompute combined if pose scoring is available
                from . import scoring
                # Live scoring already updates pose terms; just refresh pixel
                # and recombine
                props.score = (
                    scoring.PIXEL_WEIGHT * props.pixel_score
                    + scoring.POSITION_WEIGHT * props.position_score
                    + scoring.ROTATION_WEIGHT * props.rotation_score
                )
                if props.score > props.best_score:
                    props.best_score = props.score
        else:
            # No improvement: revert and contract step
            on_revert()
            if kind == 'rotation':
                self._step_rotation = max(self._step_rotation * 0.6, 0.002)
            elif kind == 'distance':
                self._step_distance = max(self._step_distance * 0.6, 0.003)
            else:
                self._step_location = max(self._step_location * 0.6, 0.002)
            # Don't change the status text on miss — keeps UI stable

    # --- Cleanup ----------------------------------------------------------

    def _finish(self, context):
        scene = context.scene
        props = scene.photo_match_props
        wm = context.window_manager

        if self._timer is not None:
            wm.event_timer_remove(self._timer)
            self._timer = None
        self._cleanup_render_settings(scene)

        props.fine_tune_running = False
        if props.fine_tune_status.startswith("Polishing"):
            props.fine_tune_status = f"Stopped at {self._last_score:.1f}%" \
                if self._last_score is not None else "Stopped"

        self._contour_features = None
        # Tag viewports so the panel updates immediately
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
        return {'CANCELLED'}

    def _cleanup_render_settings(self, scene):
        if self._saved_resolution is not None:
            scene.render.resolution_x = self._saved_resolution[0]
            scene.render.resolution_y = self._saved_resolution[1]
            self._saved_resolution = None


# ----------------------------------------------------------------------------
# Property update callback — kicks the modal off when the checkbox flips on
# ----------------------------------------------------------------------------

def update_fine_tune_enabled(self, context):
    """Called when `fine_tune_enabled` toggles. Starts the modal if turning
    on, lets the modal exit gracefully if turning off."""
    props = self
    if props.fine_tune_enabled and not props.fine_tune_running:
        # Defer the operator call slightly to let the property write commit
        try:
            bpy.ops.photomatch.fine_tune('INVOKE_DEFAULT')
        except Exception as e:
            print(f"Photo Match: failed to start fine-tune: {e}")
            props.fine_tune_enabled = False


# ----------------------------------------------------------------------------
# Auto-trigger from Auto-Solve completion
# ----------------------------------------------------------------------------

def maybe_auto_enable_after_solve(props, final_score):
    """Called by the Auto-Solve operators in their _finish path. If the final
    score crossed the configured threshold and auto-enable is on, flip the
    fine-tune checkbox so the modal kicks off.

    Persistent-mode override (v2.7.1+): when persistent is on, fine-tune
    auto-re-enables regardless of the threshold or the auto-enable
    checkbox. Auto-Solve disabled it on the way in (`auto_solve_running`
    branch in `modal()`); persistent mode means "keep it on no matter what",
    so we restore that intent here.
    """
    persistent = bool(getattr(props, 'fine_tune_persistent', False))

    if props.fine_tune_enabled:
        return  # already on

    if persistent:
        # Bypass threshold + auto-enable checkbox — persistent mode wants it
        # on regardless. The fine_tune_enabled write triggers
        # update_fine_tune_enabled which kicks the modal back off.
        props.fine_tune_enabled = True
        return

    if not props.fine_tune_auto_enable:
        return
    if final_score is None or final_score < props.fine_tune_threshold:
        return
    # Flipping the property triggers update_fine_tune_enabled, which starts
    # the modal
    props.fine_tune_enabled = True


# ----------------------------------------------------------------------------
# Registration
# ----------------------------------------------------------------------------

classes = (PHOTOMATCH_OT_FineTune,)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
