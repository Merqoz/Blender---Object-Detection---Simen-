"""Operators that drive the game.

- LoadImage: file picker → set as reference (no pose scoring)
- GenerateRandomChallenge: place a hidden ref cam at a random angle around the
  target, capture screenshot, drop the player at a different angle
- CalculateScore: render from the player cam, score pixels + pose
- ResetBestScore: zero the best-score tracker
- RevealReference: snap the player cam to the hidden reference cam (give-up)
"""

import os
import tempfile

import bpy
from bpy.props import StringProperty
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper
from mathutils import Vector

from . import camera_utils
from . import cv_scoring
from . import geometry
from . import image_features
from . import multi_camera_search
from . import object_search
from . import rendering
from . import scoring
from . import search
from . import search_cv
from . import search_freeform
from . import search_v2
from . import search_v3


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------

def _set_reference_image(scene, props, player_cam, filepath, force_reload=False):
    """Replace the current reference image with the contents of `filepath`.

    Three jobs:
      1. **Load** the file. With `force_reload=True` we remove any pre-existing
         data-block sharing the basename — used when a re-rendered challenge
         file has been overwritten on disk and `check_existing` would otherwise
         hand back a stale data-block.
      2. **Wire it up**: `props.reference_image_path`, `props.reference_image`,
         and the player camera's background image.
      3. **Clean up** the previous reference image data-block from
         `bpy.data.images` if nothing else is using it. We check `users == 0`
         before removing so images linked to materials or anywhere else the
         user cares about are left alone.
    """
    old_image = props.reference_image

    # --- Load ---
    if force_reload:
        # Pre-emptively remove any image already loaded under this basename.
        # If that data-block IS our old reference image, mark old_image None
        # so we don't try to free it again later.
        same_name = bpy.data.images.get(os.path.basename(filepath))
        if same_name is not None:
            if same_name == old_image:
                old_image = None
            try:
                bpy.data.images.remove(same_name)
            except Exception:
                pass
        new_image = bpy.data.images.load(filepath, check_existing=False)
    else:
        new_image = bpy.data.images.load(filepath, check_existing=True)

    # --- Wire up ---
    props.reference_image_path = filepath
    props.reference_image = new_image
    rendering.setup_camera_background(scene, player_cam, new_image, props.opacity)

    # --- Clean up displaced image ---
    if old_image is not None and old_image != new_image:
        try:
            if old_image.users == 0:
                bpy.data.images.remove(old_image)
        except Exception:
            # The data-block may already be gone in some edge cases — ignore
            pass

    # --- Invalidate cached ReferenceFeatures ---
    # The cache is keyed on image name and could otherwise serve stale entries
    # if the user reloads with the same filename.
    _invalidate_feature_cache()

    return new_image


def _set_reference_image_inmemory(scene, props, player_cam, image, *,
                                  remove_old_if_orphan=True):
    """Wire up an *already-in-memory* image as the reference (handoff §8.1).

    This is the live-feed path: the lock-frame data-block is being updated
    in place by the live-tracking match timer, so we don't go through
    `bpy.data.images.load()` and we don't replace the data-block on each
    refresh. Same UI wire-up as `_set_reference_image` (props, camera
    background, feature-cache invalidation) but no disk read.

    Args:
        image: an existing `bpy.types.Image` already in `bpy.data.images`.
        remove_old_if_orphan: if True (default), remove the previous reference
            image data-block when nothing else uses it, same as
            `_set_reference_image`. The live-tracking module sets this False
            on tick-by-tick refreshes since the same image is being used
            (only its pixel data changes), so removal would be wrong.
    """
    old_image = props.reference_image

    props.reference_image_path = ""
    props.reference_image = image
    rendering.setup_camera_background(scene, player_cam, image, props.opacity)

    if remove_old_if_orphan and old_image is not None and old_image != image:
        try:
            if old_image.users == 0:
                bpy.data.images.remove(old_image)
        except Exception:
            pass

    _invalidate_feature_cache()
    return image


def _switch_first_viewport_to_camera_view(context):
    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            for sp in area.spaces:
                if sp.type == 'VIEW_3D':
                    sp.region_3d.view_perspective = 'CAMERA'
            return


def _reset_scores(props):
    props.score = 0.0
    props.pixel_score = 0.0
    props.position_score = 0.0
    props.rotation_score = 0.0


# ----------------------------------------------------------------------------
# Reference feature cache (for v3 contour scoring)
# ----------------------------------------------------------------------------

# Module-level cache: ReferenceFeatures objects are expensive (~30ms to build)
# and are reused for every score call during a search. Keyed by a settings
# tuple so we transparently rebuild when the user changes edge_threshold etc.
_FEATURE_CACHE = {}


def _ref_image_to_array(image):
    """Convert a bpy.types.Image to an HxWx3 float32 array in [0,1]."""
    import numpy as np
    pixels = np.array(image.pixels[:], dtype=np.float32)
    pixels = pixels.reshape(image.size[1], image.size[0], 4)
    return pixels[..., :3]


def _get_or_build_reference_features(props):
    """Return the cached ReferenceFeatures for the current reference image,
    building it if absent or invalidated by a settings change."""
    img = props.reference_image
    if img is None:
        return None

    # Silhouette-only mode is meaningful only when the reference is from the
    # live phone feed — file-loaded references typically have a clean
    # background already, so silhouette filtering would just discard useful
    # detail. Gate by `live_feed_running` to avoid affecting normal use.
    silhouette_only = bool(
        getattr(props, 'live_feed_silhouette_only', False)
        and getattr(props, 'live_feed_running', False)
    )

    key = (
        img.name,
        tuple(img.size),
        round(props.edge_threshold, 3),
        bool(props.auto_invert_line_art),
        silhouette_only,
    )
    if key in _FEATURE_CACHE:
        return _FEATURE_CACHE[key]

    rgb = _ref_image_to_array(img)
    features = image_features.ReferenceFeatures(
        rgb,
        edge_threshold=props.edge_threshold,
        auto_invert=props.auto_invert_line_art,
        normalize=True,
        silhouette_only=silhouette_only,
    )

    # Bound cache size — only the latest few references stay live
    if len(_FEATURE_CACHE) > 4:
        _FEATURE_CACHE.pop(next(iter(_FEATURE_CACHE)))
    _FEATURE_CACHE[key] = features
    return features


def _invalidate_feature_cache():
    """Drop all cached ReferenceFeatures — call when a reference image is
    replaced (its data-block may have been removed from bpy.data)."""
    _FEATURE_CACHE.clear()


def _contour_score_render(scene, cam, props, contour_features):
    """Render from `cam` and score against precomputed contour features.

    Used by both the camera and object V3 solvers — the camera version
    moves the camera between calls, the object version moves the target,
    but both end up calling this with the same player camera.

    The reference's distance-transformed feature pyramid was built once when
    the reference loaded; per-step cost is just the rendered image's edge
    map plus the chamfer lookup. ~5-10ms per call.
    """
    import os
    import tempfile
    import numpy as np

    render_path = os.path.join(tempfile.gettempdir(), "photomatch_quick.png")
    shading = getattr(props, 'render_shading_mode', 'VIEWPORT')
    shading_arg = None if shading == 'VIEWPORT' else shading
    rendering.render_camera_to_path(scene, cam, render_path,
                                    shading_mode=shading_arg)

    img = bpy.data.images.load(render_path, check_existing=False)
    try:
        pixels = np.array(img.pixels[:], dtype=np.float32)
        pixels = pixels.reshape(img.size[1], img.size[0], 4)[..., :3]
        return image_features.contour_score(
            pixels, contour_features,
            edge_threshold=props.edge_threshold,
        )
    finally:
        bpy.data.images.remove(img)


# ----------------------------------------------------------------------------
# Load image from disk
# ----------------------------------------------------------------------------

class PHOTOMATCH_OT_LoadImage(Operator, ImportHelper):
    """Pick a reference image from disk"""
    bl_idname = "photomatch.load_image"
    bl_label = "Load Reference Image"

    filter_glob: StringProperty(
        default="*.png;*.jpg;*.jpeg;*.bmp;*.tif;*.tiff;*.exr",
        options={'HIDDEN'},
    )

    def execute(self, context):
        scene = context.scene
        props = scene.photo_match_props

        # Edge case (handoff §405): loading a file reference while the live
        # feed is running is contradictory — we'd have two competing reference
        # sources. Stop the feed first so its lifecycle is clean; tracking
        # gets torn down via stop_server's chained call to stop_tracking.
        from . import live_feed
        if live_feed.is_running():
            live_feed.stop_server()
            props.live_feed_running = False
            props.live_feed_phone_connected = False
            props.live_feed_url = ""
            self.report({'INFO'},
                        "Stopped live feed before loading file reference")

        # Sync the source dropdown to FILE so the panel re-renders cleanly.
        # The update callback for reference_source no-ops the live-feed-stop
        # path here since we already stopped it.
        if hasattr(props, 'reference_source'):
            props.reference_source = 'FILE'

        cam = camera_utils.ensure_player_camera(scene, context)

        try:
            _set_reference_image(scene, props, cam, self.filepath, force_reload=False)
        except Exception as e:
            self.report({'ERROR'}, f"Failed to load image: {e}")
            return {'CANCELLED'}

        # Loaded image has no associated reference camera → pose scoring off
        props.reference_camera = None
        _reset_scores(props)

        _switch_first_viewport_to_camera_view(context)
        camera_utils.tag_redraw_3d_viewports(context)

        self.report({'INFO'}, f"Loaded reference: {os.path.basename(self.filepath)}")
        return {'FINISHED'}


# ----------------------------------------------------------------------------
# Generate random challenge around the highlighted object
# ----------------------------------------------------------------------------

class PHOTOMATCH_OT_GenerateRandomChallenge(Operator):
    """Place a hidden camera at a random angle around the target object,
    capture its view, and let you try to find that angle"""
    bl_idname = "photomatch.generate_random_challenge"
    bl_label = "Generate Random Challenge"

    def execute(self, context):
        scene = context.scene
        props = scene.photo_match_props

        target = self._resolve_target(context, props)
        if target is None:
            self.report({'ERROR'},
                        "Highlight an object in the outliner (or set Target above)")
            return {'CANCELLED'}
        props.target_object = target  # surface the choice in the UI

        # Bounding sphere → camera distance
        center, radius = geometry.target_center_and_radius(target)
        camera_distance = radius + props.distance_offset

        # Pick the reference angle
        ref_direction = camera_utils.random_unit_vector(
            upper_hemisphere=props.upper_hemisphere_only
        )
        ref_location = center + ref_direction * camera_distance

        # Make sure there's a player cam *before* we touch the reference cam,
        # so we can copy its lens/sensor settings
        player_cam = camera_utils.ensure_player_camera(scene, context)
        ref_cam = camera_utils.create_reference_camera(
            scene, ref_location, center, mimic_camera=player_cam
        )
        props.reference_camera = ref_cam

        # Capture the challenge screenshot using the user's chosen shading mode
        challenge_path = os.path.join(tempfile.gettempdir(), "photomatch_challenge.png")
        shading = getattr(props, 'render_shading_mode', 'VIEWPORT')
        shading_arg = None if shading == 'VIEWPORT' else shading
        try:
            rendering.render_camera_to_path(scene, ref_cam, challenge_path,
                                            shading_mode=shading_arg)
        except Exception as e:
            self.report({'ERROR'}, f"Render failed: {e}")
            return {'CANCELLED'}

        try:
            _set_reference_image(
                scene, props, player_cam, challenge_path, force_reload=True
            )
        except Exception as e:
            self.report({'ERROR'}, f"Failed to load challenge image: {e}")
            return {'CANCELLED'}

        _reset_scores(props)
        props.best_score = 0.0  # new challenge → reset best

        # Drop the player at a *different* random angle so they have something
        # to do — we re-roll until it's at least ~45° away from the answer.
        player_direction = self._pick_player_start_direction(props, ref_direction)
        player_location = center + player_direction * camera_distance
        camera_utils.position_camera(player_cam, player_location, center)

        _switch_first_viewport_to_camera_view(context)
        camera_utils.tag_redraw_3d_viewports(context)

        self.report({'INFO'},
                    f"Challenge captured around '{target.name}' — find the angle!")
        return {'FINISHED'}

    @staticmethod
    def _resolve_target(context, props):
        if props.target_object is not None:
            return props.target_object
        active = context.view_layer.objects.active
        if active is None:
            return None
        if active.type not in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'EMPTY'}:
            return None
        return active

    @staticmethod
    def _pick_player_start_direction(props, ref_direction):
        for _ in range(10):
            d = camera_utils.random_unit_vector(
                upper_hemisphere=props.upper_hemisphere_only
            )
            if d.dot(ref_direction) < 0.7:  # ~45° away or more
                return d
        return -ref_direction  # fallback: opposite side


# ----------------------------------------------------------------------------
# Score the player's match
# ----------------------------------------------------------------------------

class PHOTOMATCH_OT_CalculateScore(Operator):
    """Render from your camera and score how closely it matches the reference"""
    bl_idname = "photomatch.calculate_score"
    bl_label = "Calculate Match Score"

    def execute(self, context):
        scene = context.scene
        props = scene.photo_match_props

        if props.reference_image is None:
            self.report({'ERROR'}, "Load or generate a reference first")
            return {'CANCELLED'}

        player_cam = scene.camera
        if player_cam is None or player_cam.type != 'CAMERA':
            self.report({'ERROR'}, "No active player camera")
            return {'CANCELLED'}
        if player_cam.name == camera_utils.REFERENCE_CAMERA_NAME:
            self.report({'ERROR'},
                        "The reference camera is active — switch to your player camera first")
            return {'CANCELLED'}

        # Render from the player camera
        render_path = os.path.join(tempfile.gettempdir(), "photomatch_player_render.png")
        shading = getattr(props, 'render_shading_mode', 'VIEWPORT')
        shading_arg = None if shading == 'VIEWPORT' else shading
        try:
            rendering.render_camera_to_path(scene, player_cam, render_path,
                                            shading_mode=shading_arg)
        except Exception as e:
            self.report({'ERROR'}, f"Render failed: {e}")
            return {'CANCELLED'}

        try:
            render_img = bpy.data.images.load(render_path, check_existing=False)
        except Exception as e:
            self.report({'ERROR'}, f"Failed to load render: {e}")
            return {'CANCELLED'}

        try:
            self._score(props, player_cam, render_img)
        finally:
            if render_img.name in bpy.data.images:
                bpy.data.images.remove(render_img)

        self.report({'INFO'}, f"Match score: {props.score:.1f}%")
        return {'FINISHED'}

    @staticmethod
    def _score(props, player_cam, render_img):
        import bpy

        # Enhanced multi-metric visual scoring
        result = scoring.enhanced_combined_score(
            props.reference_image, render_img,
            player_cam=player_cam,
            reference_cam=props.reference_camera,
            target_object=props.target_object,
        )

        visual_score = result['visual_combined']
        props.pixel_score = visual_score
        props.position_score = result['position']
        props.rotation_score = result['rotation']

        # Blend in CV geometric metrics when reference camera + target available
        if (props.reference_camera is not None and props.target_object is not None):
            try:
                scene = bpy.context.scene
                cv_result = cv_scoring.cv_combined_score(
                    scene, props.reference_camera, player_cam,
                    props.target_object,
                )
                # Blend: 60% visual + 30% CV geometric + 10% pose
                cv_geo = cv_result['cv_combined']
                final = (
                    0.55 * visual_score +
                    0.30 * cv_geo +
                    0.10 * result['position'] +
                    0.05 * result['rotation']
                )
            except Exception as e:
                print(f"Photo Match: CV scoring failed, using visual only: {e}")
                final = result['score']
        else:
            final = result['score']

        props.score = max(0.0, min(100.0, final))
        if props.score > props.best_score:
            props.best_score = props.score


# ----------------------------------------------------------------------------
# Misc operators
# ----------------------------------------------------------------------------

class PHOTOMATCH_OT_ResetBestScore(Operator):
    bl_idname = "photomatch.reset_best_score"
    bl_label = "Reset Best Score"
    bl_description = "Reset the best score for this session"

    def execute(self, context):
        context.scene.photo_match_props.best_score = 0.0
        return {'FINISHED'}


class PHOTOMATCH_OT_RevealReference(Operator):
    """Snap your active camera to the hidden reference camera (give-up)"""
    bl_idname = "photomatch.reveal_reference"
    bl_label = "Snap to Reference"

    def execute(self, context):
        scene = context.scene
        props = scene.photo_match_props

        if props.reference_camera is None:
            self.report({'ERROR'},
                        "No reference camera — generate a random challenge first")
            return {'CANCELLED'}

        player_cam = scene.camera
        if player_cam is None or player_cam.name == camera_utils.REFERENCE_CAMERA_NAME:
            player_cam = camera_utils.ensure_player_camera(scene, context)

        player_cam.matrix_world = props.reference_camera.matrix_world.copy()

        camera_utils.tag_redraw_3d_viewports(context)
        self.report({'INFO'}, "Snapped to reference pose")
        return {'FINISHED'}


# ----------------------------------------------------------------------------
# Auto-solve — coarse-to-fine camera search
# ----------------------------------------------------------------------------

# Render resolution used during the search. Each evaluation does a real render,
# so smaller = faster. 256 keeps it under ~150ms on a typical machine.
_AUTO_SOLVE_QUICK_RES = 256

# Modal timer interval. 50ms means the algorithm gets ~20 evaluation slots per
# second; the actual rate is render-bound (more like 5-10/s in practice).
_AUTO_SOLVE_TICK = 0.05


class PHOTOMATCH_OT_AutoSolve(Operator):
    """Search for the camera pose that best matches the reference image.

    Uses pixel similarity (not pose), because the goal is matching what's
    actually visible in the reference — using the hidden reference camera
    would be cheating and would fail entirely for loaded images.

    See `search_v2.CameraSolveStateV2` for algorithm details. ESC cancels.
    """
    bl_idname = "photomatch.auto_solve"
    bl_label = "Auto-Solve"
    bl_description = ("Automatically search for the camera position that best "
                      "matches the reference image. Warm-starts from your "
                      "current camera. Press ESC to cancel.")

    _state = None
    _timer = None
    _saved_resolution = None
    _contour_features = None  # set by invoke when V3 is selected
    _is_multi_camera = False  # set by invoke when MULTI is selected
    _is_cv_guided = False     # set by invoke when CV is selected
    _is_freeform = False      # set by invoke when Free Explore is checked

    def invoke(self, context, event):
        scene = context.scene
        props = scene.photo_match_props

        # Handoff §8.4: when the live feed is the active source, auto-grab
        # the latest phone frame as the frozen reference so the user doesn't
        # have to do Initial Lock first. The frame is captured ONCE at invoke
        # time; subsequent ticks score against it. This effectively gives
        # the user "Initial Lock with progress UI" via the existing modal.
        if (getattr(props, 'reference_source', None) == 'LIVE_FEED'
                and getattr(props, 'live_feed_running', False)):
            from . import live_tracking
            if not live_tracking._refresh_reference_from_live_feed(scene, props):
                self.report({'ERROR'},
                            "Auto-Solve in live mode needs a phone frame — "
                            "wait for the phone to connect, then retry")
                return {'CANCELLED'}

        # --- Validate ---
        if props.reference_image is None:
            self.report({'ERROR'}, "Load or generate a reference first")
            return {'CANCELLED'}

        target = props.target_object or context.view_layer.objects.active
        if target is None or target.type not in {
            'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'EMPTY',
        }:
            self.report({'ERROR'},
                        "Set a Target object (or highlight one in the outliner) "
                        "so the autosolver knows what to orbit around")
            return {'CANCELLED'}
        props.target_object = target

        # --- Initial guess from current camera ---
        player_cam = camera_utils.ensure_player_camera(scene, context)
        target_center, target_radius = geometry.target_center_and_radius(target)

        offset = player_cam.matrix_world.translation - target_center
        if offset.length < 0.01:
            # Camera is on top of the object — pick a sensible starting offset
            offset = Vector((0, -max(target_radius * 3, 5), max(target_radius, 1)))
        start_distance = offset.length
        start_direction = offset.normalized()

        # Pick the search algorithm based on the user's selection. v3 also
        # builds the reference's contour features upfront — this is the heavy
        # one-time cost (~30ms) that makes per-step scoring cheap.
        algo = props.camera_algorithm
        self._contour_features = None
        self._is_multi_camera = False
        self._is_cv_guided = False
        self._is_freeform = False

        # Free Explore mode overrides all algorithms — search in 3D space
        # from the current camera, not on a sphere around the target.
        if getattr(props, 'search_free_explore', False):
            self._is_freeform = True
            self._state = search_freeform.FreeformSearch(
                target_center=target_center,
                start_position=player_cam.matrix_world.translation.copy(),
                upper_hemisphere=props.upper_hemisphere_only,
                scene=scene,
                reference_cam=props.reference_camera,
                target_obj=props.target_object,
            )
            try:
                self._contour_features = _get_or_build_reference_features(props)
            except Exception as e:
                print(f"Photo Match: contour build failed for freeform: {e}")
                self._contour_features = None
        else:
            # CV-guided search requires both reference_camera and target_object
            if algo == 'CV' and props.reference_camera is None:
                self.report({'WARNING'},
                            "CV algorithm needs a reference camera — "
                            "falling back to Multi-Camera search. "
                            "Generate a Random Challenge to use CV mode.")
                algo = 'MULTI'

            if algo == 'V1':
                self._state = search.AutoSolveState(
                    target_center=target_center,
                    start_direction=start_direction,
                    start_distance=start_distance,
                    upper_hemisphere=props.upper_hemisphere_only,
                )
            elif algo == 'V2':
                self._state = search_v2.CameraSolveStateV2(
                    target_center=target_center,
                    start_direction=start_direction,
                    start_distance=start_distance,
                    upper_hemisphere=props.upper_hemisphere_only,
                )
            elif algo == 'V3':
                self._state = search_v3.CameraSolveStateV3(
                    target_center=target_center,
                    start_direction=start_direction,
                    start_distance=start_distance,
                    upper_hemisphere=props.upper_hemisphere_only,
                )
                try:
                    self._contour_features = _get_or_build_reference_features(props)
                except Exception as e:
                    print(f"Photo Match: contour feature build failed, falling "
                          f"back to pixel scoring: {e}")
                    self._contour_features = None
            elif algo == 'MULTI':
                self._state = multi_camera_search.MultiCameraSearch(
                    target_center=target_center,
                    start_direction=start_direction,
                    start_distance=start_distance,
                    upper_hemisphere=props.upper_hemisphere_only,
                    num_cameras=int(getattr(props, 'multi_cam_count', 10)),
                    assignment_mode=str(getattr(props, 'multi_cam_assignment',
                                                'ROUND_ROBIN')),
                    single_algo_key=str(getattr(props, 'multi_cam_single_algo',
                                                'FIBONACCI')),
                    hotspot_threshold=float(getattr(props,
                                                    'multi_cam_hotspot_threshold',
                                                    80.0)),
                )
                self._is_multi_camera = True
                try:
                    self._contour_features = _get_or_build_reference_features(props)
                except Exception as e:
                    print(f"Photo Match: contour feature build failed for multi-cam, "
                          f"falling back to pixel scoring: {e}")
                    self._contour_features = None
            else:  # CV (default)
                self._state = search_cv.CVGuidedSearch(
                    scene=scene,
                    target_center=target_center,
                    reference_cam=props.reference_camera,
                    target_obj=props.target_object,
                    start_direction=start_direction,
                    start_distance=start_distance,
                    upper_hemisphere=props.upper_hemisphere_only,
                )
                self._is_cv_guided = True
                try:
                    self._contour_features = _get_or_build_reference_features(props)
                except Exception as e:
                    print(f"Photo Match: contour feature build failed for CV, "
                          f"falling back to pixel scoring: {e}")
                    self._contour_features = None

        # --- Lower render resolution for fast searching ---
        # Restored in _finish. Aspect ratio matched to the reference image so
        # the comparison is fair.
        ref = props.reference_image
        ref_w, ref_h = ref.size
        if ref_w > 0 and ref_h > 0:
            aspect = ref_w / ref_h
            if aspect >= 1:
                quick_w = _AUTO_SOLVE_QUICK_RES
                quick_h = max(2, int(_AUTO_SOLVE_QUICK_RES / aspect))
            else:
                quick_h = _AUTO_SOLVE_QUICK_RES
                quick_w = max(2, int(_AUTO_SOLVE_QUICK_RES * aspect))
        else:
            quick_w = quick_h = _AUTO_SOLVE_QUICK_RES

        self._saved_resolution = (
            scene.render.resolution_x,
            scene.render.resolution_y,
        )
        scene.render.resolution_x = quick_w
        scene.render.resolution_y = quick_h

        # --- Mark running for live-scoring + UI ---
        props.auto_solve_running = True
        props.auto_solve_progress = "Starting search..."

        wm = context.window_manager
        self._timer = wm.event_timer_add(_AUTO_SOLVE_TICK, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'ESC' and event.value == 'PRESS':
            return self._finish(context, cancelled=True)

        if event.type == 'TIMER':
            scene = context.scene
            props = scene.photo_match_props
            try:
                done = self._step(scene, props)
            except Exception as e:
                print(f"Photo Match auto-solve error: {e}")
                self.report({'ERROR'}, f"Search failed: {e}")
                return self._finish(context, cancelled=True)
            self._tag_redraw(context)
            if done:
                return self._finish(context, cancelled=False)

        return {'RUNNING_MODAL'}

    def _step(self, scene, props):
        """Evaluate one candidate. Returns True if the search is complete."""
        candidate = self._state.next_candidate()
        if candidate is None:
            return True

        player_cam = scene.camera
        if player_cam is None:
            return True

        # Freeform returns (phase, position) — absolute 3D coordinates.
        # Multi-camera returns (cam_id, phase, direction, distance).
        # All others return (phase, direction, distance).
        if self._is_freeform:
            phase, position = candidate
            cam_id = None
            camera_utils.position_camera(
                player_cam, position, self._state.target_center)
        elif self._is_multi_camera:
            cam_id, phase, direction, distance = candidate
            position = self._state.target_center + direction * distance
            camera_utils.position_camera(
                player_cam, position, self._state.target_center)
        else:
            phase, direction, distance = candidate
            cam_id = None
            position = self._state.target_center + direction * distance
            camera_utils.position_camera(
                player_cam, position, self._state.target_center)

        # Score via contour or pixel path
        if self._contour_features is not None:
            score = _contour_score_render(scene, player_cam, props, self._contour_features)
        else:
            shading = getattr(props, 'render_shading_mode', 'VIEWPORT')
            shading_arg = None if shading == 'VIEWPORT' else shading
            score = scoring.quick_pixel_score(scene, player_cam,
                                              props.reference_image,
                                              shading_mode=shading_arg)

        # Report score back
        if self._is_freeform:
            self._state.report_score(position, score)
        elif self._is_multi_camera:
            self._state.report_score(cam_id, direction, distance, score)
        else:
            self._state.report_score(direction, distance, score)

        # Update progress text
        progress_pct = int(
            100 * self._state.evaluations_done /
            max(1, self._state.total_evaluations_planned)
        )
        if self._is_freeform:
            props.auto_solve_progress = (
                f"Free {phase}: {progress_pct}% — "
                f"best: {self._state.best_score:.1f}%"
            )
        elif self._is_multi_camera:
            best_id, best_name, best_s = self._state.get_best_camera()
            props.auto_solve_progress = (
                f"🎥 {phase} ({progress_pct}%) — "
                f"best: {self._state.best_score:.1f}% via {best_name}"
            )
        elif self._is_cv_guided:
            props.auto_solve_progress = (
                f"CV {phase}: {progress_pct}% — "
                f"best: {self._state.best_score:.1f}%"
            )
        else:
            props.auto_solve_progress = (
                f"{phase}: {progress_pct}% — best so far {self._state.best_score:.1f}%"
            )
        return False

    def _finish(self, context, cancelled):
        scene = context.scene
        props = scene.photo_match_props
        wm = context.window_manager

        if self._timer is not None:
            wm.event_timer_remove(self._timer)
            self._timer = None

        # Restore render resolution
        if self._saved_resolution is not None:
            scene.render.resolution_x = self._saved_resolution[0]
            scene.render.resolution_y = self._saved_resolution[1]
            self._saved_resolution = None

        # Apply the best position found
        if not cancelled and self._state is not None and self._state.best_score >= 0:
            player_cam = scene.camera
            if player_cam is not None and player_cam.type == 'CAMERA':
                if self._is_freeform:
                    camera_utils.position_camera(
                        player_cam, self._state.best_position,
                        self._state.target_center
                    )
                else:
                    position = (
                        self._state.target_center
                        + self._state.best_direction * self._state.best_distance
                    )
                    camera_utils.position_camera(
                        player_cam, position, self._state.target_center
                    )

        # Trigger a final full-resolution score so the displayed numbers are real
        if not cancelled:
            try:
                bpy.ops.photomatch.calculate_score()
            except Exception as e:
                print(f"Photo Match: final score after autosolve failed: {e}")

        props.auto_solve_running = False
        if cancelled:
            props.auto_solve_progress = "Cancelled"
        elif self._state is not None:
            if self._is_freeform:
                props.auto_solve_progress = (
                    f"Done — {self._state.best_score:.1f}% in "
                    f"{self._state.evaluations_done} renders "
                    f"(free explore from current camera)"
                )
            elif self._is_multi_camera:
                best_id, best_name, best_s = self._state.get_best_camera()
                props.auto_solve_progress = (
                    f"Done — {self._state.best_score:.1f}% in "
                    f"{self._state.evaluations_done} samples "
                    f"(winner: {best_name})"
                )
            elif self._is_cv_guided:
                props.auto_solve_progress = (
                    f"Done — {self._state.best_score:.1f}% in "
                    f"{self._state.evaluations_done} renders "
                    f"({self._state.phase1_stats})"
                )
            else:
                props.auto_solve_progress = (
                    f"Done — found {self._state.best_score:.1f}% in "
                    f"{self._state.evaluations_done} samples"
                )

        # Auto-enable fine-tune if the score crossed the bullseye threshold
        if not cancelled and self._state is not None:
            try:
                from . import fine_tune
                fine_tune.maybe_auto_enable_after_solve(props, self._state.best_score)
            except Exception as e:
                print(f"Photo Match: fine-tune auto-trigger failed: {e}")

        self._tag_redraw(context)
        self._state = None
        # Drop our reference to the cached features (they remain in the
        # module-level cache for the next solve)
        self._contour_features = None
        self._is_multi_camera = False
        self._is_cv_guided = False
        self._is_freeform = False
        # Clear reprojection cache
        try:
            cv_scoring.clear_reprojection_cache()
        except Exception:
            pass
        return {'CANCELLED'} if cancelled else {'FINISHED'}

    @staticmethod
    def _tag_redraw(context):
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


# ----------------------------------------------------------------------------
# Auto-solve (object) — 6-DOF object pose search
# ----------------------------------------------------------------------------

class PHOTOMATCH_OT_AutoSolveObject(Operator):
    """Search for the object pose (rotation + translation) that best matches the reference.

    The camera stays put; the target object is rotated and translated through
    candidate poses. Pixel similarity from the player camera drives the search.

    See `object_search.ObjectSolveState` for algorithm details. ESC cancels
    and restores the object's original transform.
    """
    bl_idname = "photomatch.auto_solve_object"
    bl_label = "Auto-Solve (Object)"
    bl_description = ("Automatically search for the object rotation + position "
                      "that best matches the reference image. The camera "
                      "stays put. Press ESC to cancel and revert.")

    _state = None
    _timer = None
    _saved_resolution = None
    _saved_rotation = None
    _saved_location = None
    _saved_rotation_mode = None
    _target_obj = None
    _contour_features = None  # set by invoke when V3 is selected

    def invoke(self, context, event):
        scene = context.scene
        props = scene.photo_match_props

        # --- Validate ---
        if props.reference_image is None:
            self.report({'ERROR'}, "Load or generate a reference first")
            return {'CANCELLED'}

        target = props.target_object or context.view_layer.objects.active
        if target is None or target.type not in {
            'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'EMPTY',
        }:
            self.report({'ERROR'},
                        "Set a Target object so the autosolver knows what to move")
            return {'CANCELLED'}
        props.target_object = target
        self._target_obj = target

        player_cam = camera_utils.ensure_player_camera(scene, context)
        if player_cam is None:
            self.report({'ERROR'}, "No player camera available")
            return {'CANCELLED'}

        # --- Save current transform — restored on cancel ---
        self._saved_rotation_mode = target.rotation_mode
        target.rotation_mode = 'XYZ'  # we set rotation_euler during search
        self._saved_rotation = target.rotation_euler.copy()
        self._saved_location = target.location.copy()

        # Bound translation by 3x the bounding-sphere radius. Beyond that the
        # object is generally outside the camera frustum and scoring is moot.
        _, target_radius = geometry.target_center_and_radius(target)
        translation_radius = max(target_radius * 3.0, 1.0)

        # V3: build contour features and lower the early-stop ceiling.
        # Chamfer scores cap around 92-95 (Sobel edges are 2-px wide so DT
        # min-distance never quite reaches zero), so 97 is unreachable.
        self._contour_features = None
        early_stop = None
        if props.camera_algorithm == 'V3':
            try:
                self._contour_features = _get_or_build_reference_features(props)
                early_stop = 95.0
            except Exception as e:
                # Fallback to pixel scoring on feature-build failure
                print(f"Photo Match: contour feature build failed for object "
                      f"solver, falling back to pixel scoring: {e}")
                self._contour_features = None

        self._state = object_search.ObjectSolveState(
            original_rotation=Vector(target.rotation_euler),
            original_location=Vector(target.location),
            translation_radius=translation_radius,
            early_stop_score=early_stop,
        )

        # --- Lower render resolution for fast searching ---
        ref = props.reference_image
        ref_w, ref_h = ref.size
        if ref_w > 0 and ref_h > 0:
            aspect = ref_w / ref_h
            if aspect >= 1:
                quick_w = _AUTO_SOLVE_QUICK_RES
                quick_h = max(2, int(_AUTO_SOLVE_QUICK_RES / aspect))
            else:
                quick_h = _AUTO_SOLVE_QUICK_RES
                quick_w = max(2, int(_AUTO_SOLVE_QUICK_RES * aspect))
        else:
            quick_w = quick_h = _AUTO_SOLVE_QUICK_RES

        self._saved_resolution = (
            scene.render.resolution_x,
            scene.render.resolution_y,
        )
        scene.render.resolution_x = quick_w
        scene.render.resolution_y = quick_h

        # --- Mark running for live-scoring + UI ---
        props.auto_solve_running = True
        props.auto_solve_progress = "Starting object search..."

        wm = context.window_manager
        self._timer = wm.event_timer_add(_AUTO_SOLVE_TICK, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'ESC' and event.value == 'PRESS':
            return self._finish(context, cancelled=True)

        if event.type == 'TIMER':
            scene = context.scene
            props = scene.photo_match_props
            try:
                done = self._step(scene, props)
            except Exception as e:
                print(f"Photo Match object autosolve error: {e}")
                self.report({'ERROR'}, f"Search failed: {e}")
                return self._finish(context, cancelled=True)
            self._tag_redraw(context)
            if done:
                return self._finish(context, cancelled=False)

        return {'RUNNING_MODAL'}

    def _step(self, scene, props):
        """Evaluate one candidate. Returns True if the search is complete."""
        candidate = self._state.next_candidate()
        if candidate is None:
            return True

        phase, rotation, location = candidate

        # Apply the candidate pose
        if self._target_obj is None:
            return True
        self._target_obj.rotation_euler = rotation
        self._target_obj.location = location

        # Render and score — contour scoring (V3) if features were built,
        # otherwise strict pixel scoring
        player_cam = scene.camera
        if player_cam is None:
            return True
        if self._contour_features is not None:
            score = _contour_score_render(scene, player_cam, props, self._contour_features)
        else:
            shading = getattr(props, 'render_shading_mode', 'VIEWPORT')
            shading_arg = None if shading == 'VIEWPORT' else shading
            score = scoring.quick_pixel_score(scene, player_cam,
                                              props.reference_image,
                                              shading_mode=shading_arg)
        self._state.report_score(rotation, location, score)

        progress_pct = int(
            100 * self._state.evaluations_done /
            max(1, self._state.total_evaluations_planned)
        )
        props.auto_solve_progress = (
            f"{phase}: {progress_pct}% — best so far {self._state.best_score:.1f}%"
        )
        return False

    def _finish(self, context, cancelled):
        scene = context.scene
        props = scene.photo_match_props
        wm = context.window_manager

        if self._timer is not None:
            wm.event_timer_remove(self._timer)
            self._timer = None

        # Restore render resolution
        if self._saved_resolution is not None:
            scene.render.resolution_x = self._saved_resolution[0]
            scene.render.resolution_y = self._saved_resolution[1]
            self._saved_resolution = None

        target = self._target_obj
        if cancelled:
            # Restore the user's original transform exactly
            if target is not None and self._saved_rotation is not None:
                target.rotation_euler = self._saved_rotation
                target.location = self._saved_location
                if self._saved_rotation_mode is not None:
                    target.rotation_mode = self._saved_rotation_mode
        else:
            # Apply the best pose we found
            if (target is not None
                    and self._state is not None
                    and self._state.best_score >= 0):
                target.rotation_euler = self._state.best_rotation
                target.location = self._state.best_location
                if self._saved_rotation_mode is not None:
                    target.rotation_mode = self._saved_rotation_mode

            # Trigger a final full-resolution score
            try:
                bpy.ops.photomatch.calculate_score()
            except Exception as e:
                print(f"Photo Match: final score after object autosolve failed: {e}")

        props.auto_solve_running = False
        if cancelled:
            props.auto_solve_progress = "Cancelled — object pose restored"
        elif self._state is not None:
            props.auto_solve_progress = (
                f"Done — found {self._state.best_score:.1f}% in "
                f"{self._state.evaluations_done} samples"
            )

        # Auto-enable fine-tune on bullseye (when not cancelled).
        # The Object solver leaves the object in the best-found pose, so
        # fine-tune will begin polishing from there.
        if not cancelled and self._state is not None:
            try:
                from . import fine_tune
                # Object solver's fine-tune target should default to OBJECT
                # so the polish continues on the same DOF set
                if not props.fine_tune_enabled:
                    props.fine_tune_target = 'OBJECT'
                fine_tune.maybe_auto_enable_after_solve(props, self._state.best_score)
            except Exception as e:
                print(f"Photo Match: fine-tune auto-trigger failed: {e}")

        self._tag_redraw(context)
        self._state = None
        self._target_obj = None
        self._saved_rotation = None
        self._saved_location = None
        self._saved_rotation_mode = None
        # Drop our reference to cached features (they remain in the
        # module-level cache for the next solve)
        self._contour_features = None
        return {'CANCELLED'} if cancelled else {'FINISHED'}

    @staticmethod
    def _tag_redraw(context):
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


# ----------------------------------------------------------------------------
# Registration
# ----------------------------------------------------------------------------

# ----------------------------------------------------------------------------
# Object Tracker operators (reactive — no timer, depsgraph-driven)
# ----------------------------------------------------------------------------


class PHOTOMATCH_OT_TrackerInit(Operator):
    """Initialize tracking from the current reference image."""
    bl_idname = "photomatch.tracker_init"
    bl_label = "Object Found — Track Object"
    bl_description = ("Build a feature map from the reference image and the "
                      "target object's 3D geometry. The tracker will then "
                      "match these features against the live camera view.")

    def execute(self, context):
        from . import object_tracker

        scene = context.scene
        props = scene.photo_match_props
        ref_cam = props.reference_camera
        ref_img = props.reference_image
        target = props.target_object or context.view_layer.objects.active

        if target is None:
            self.report({'ERROR'},
                        "Select a target object or set one in Photo Match")
            return {'CANCELLED'}
        if ref_img is None:
            self.report({'ERROR'},
                        "No reference image — generate a challenge or load one first")
            return {'CANCELLED'}
        if ref_cam is None:
            self.report({'WARNING'},
                        "No reference camera — tracking will have limited "
                        "3D-2D linking. Generate a Random Challenge for best results.")

        # Stop any running tracker first
        object_tracker.stop_tracking()
        props.obj_tracker_running = False

        tracker = object_tracker.get_tracker()
        success = tracker.initialize(scene, ref_cam, target, ref_img)

        props.obj_tracker_status = tracker.status_text
        props.obj_tracker_total_features = tracker.total_features

        if success:
            self.report({'INFO'},
                        f"Tracking initialized: {tracker.total_features} "
                        f"features from '{ref_img.name}'")
        else:
            self.report({'WARNING'},
                        "Not enough features in the reference image. "
                        "Try a different angle or a more textured object.")
        return {'FINISHED'}


class PHOTOMATCH_OT_TrackerStart(Operator):
    """Start reactive tracking — updates when the camera moves."""
    bl_idname = "photomatch.tracker_start"
    bl_label = "Start Tracking"
    bl_description = ("Begin tracking. The tracker watches for camera "
                      "movement and updates automatically — no fixed timer.")

    def execute(self, context):
        from . import object_tracker

        tracker = object_tracker.get_tracker()
        if not tracker.is_initialized:
            self.report({'ERROR'},
                        "Initialize tracking first (Object Found button)")
            return {'CANCELLED'}

        props = context.scene.photo_match_props
        tracker.RE_DETECT_INTERVAL = props.obj_tracker_re_detect_interval

        object_tracker.start_tracking()
        props.obj_tracker_running = True
        props.obj_tracker_status = "Tracking active — move the camera"

        self.report({'INFO'}, "Tracking started (reactive — updates on camera move)")
        return {'FINISHED'}


class PHOTOMATCH_OT_TrackerStop(Operator):
    """Stop the tracker."""
    bl_idname = "photomatch.tracker_stop"
    bl_label = "Stop Tracking"
    bl_description = "Stop tracking and unregister the camera watcher"

    def execute(self, context):
        from . import object_tracker
        props = context.scene.photo_match_props
        object_tracker.stop_tracking()
        props.obj_tracker_running = False
        props.obj_tracker_status = "Stopped"
        return {'FINISHED'}


class PHOTOMATCH_OT_TrackerReset(Operator):
    """Reset tracker to idle."""
    bl_idname = "photomatch.tracker_reset"
    bl_label = "Reset Tracker"
    bl_description = "Clear all tracking data and reset to idle"

    def execute(self, context):
        from . import object_tracker
        props = context.scene.photo_match_props
        object_tracker.reset_tracker()
        props.obj_tracker_running = False
        props.obj_tracker_status = ""
        props.obj_tracker_confidence = 0.0
        props.obj_tracker_inliers = 0
        props.obj_tracker_total_features = 0
        props.obj_tracker_reproj_error = 999.0
        return {'FINISHED'}


classes = (
    PHOTOMATCH_OT_LoadImage,
    PHOTOMATCH_OT_GenerateRandomChallenge,
    PHOTOMATCH_OT_CalculateScore,
    PHOTOMATCH_OT_ResetBestScore,
    PHOTOMATCH_OT_RevealReference,
    PHOTOMATCH_OT_AutoSolve,
    PHOTOMATCH_OT_AutoSolveObject,
    PHOTOMATCH_OT_TrackerInit,
    PHOTOMATCH_OT_TrackerStart,
    PHOTOMATCH_OT_TrackerStop,
    PHOTOMATCH_OT_TrackerReset,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
