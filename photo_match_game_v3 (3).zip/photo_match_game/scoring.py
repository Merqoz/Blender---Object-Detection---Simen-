"""Enhanced match scoring with multi-metric analysis.

Six visual metrics combined with adaptive weights:

  1. Pixel similarity          (RGB diff, lenient)
  2. Strict pixel similarity   (power-compressed RGB + gradient)
  3. Histogram similarity      (color distribution via Bhattacharyya)
  4. Structural similarity     (local SSIM-like patches)
  5. Edge alignment            (NCC of gradient maps)
  6. Pose similarity           (position + rotation, when available)

Progressive difficulty: as scores climb the formula gets stricter,
preventing easy plateaus. Adaptive weights shift toward structural
metrics at high scores for better discrimination near the optimum.

Score bands:
  0-30  = wrong area entirely
  30-60 = right general direction
  60-80 = close but clearly off
  80-90 = very close, details matter
  90-95 = excellent, minor tweaks needed
  95+   = near-perfect match
"""

import math

import numpy as np
from mathutils import Vector


# ----------------------------------------------------------------------------
# Resize utility
# ----------------------------------------------------------------------------

def _resize_nearest(arr, new_h, new_w):
    """Nearest-neighbor resize for an HxWxC or HxW array."""
    h, w = arr.shape[:2]
    ys = np.linspace(0, h - 1, new_h).astype(np.int64)
    xs = np.linspace(0, w - 1, new_w).astype(np.int64)
    return arr[ys][:, xs]


def _image_to_array(img):
    """Convert a bpy Image to an HxWx4 float32 numpy array."""
    pixels = np.array(img.pixels[:], dtype=np.float32)
    return pixels.reshape(img.size[1], img.size[0], 4)


def _to_gray(rgb):
    """RGB float32 HxWx3 → HxW grayscale."""
    return 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]


# ----------------------------------------------------------------------------
# Individual metrics
# ----------------------------------------------------------------------------

def pixel_similarity(reference_image, render_image, target_size=128):
    """Return 0..100 from lenient RGB pixel difference."""
    ref = _resize_nearest(_image_to_array(reference_image), target_size, target_size)
    rendered = _resize_nearest(_image_to_array(render_image), target_size, target_size)
    diff = np.abs(ref[..., :3] - rendered[..., :3])
    mean_diff = float(np.mean(diff))
    return max(0.0, min(100.0, (1.0 - mean_diff) * 100.0))


def _gradient_magnitude(rgb):
    """Per-pixel gradient magnitude for structural comparison."""
    gray = np.mean(rgb, axis=2)
    gx = np.zeros_like(gray)
    gy = np.zeros_like(gray)
    gx[:, :-1] = gray[:, 1:] - gray[:, :-1]
    gy[:-1, :] = gray[1:, :] - gray[:-1, :]
    return np.sqrt(gx * gx + gy * gy)


def strict_pixel_similarity(reference_image, render_image, target_size=128):
    """Strict pixel similarity with power-curve compression + gradient term."""
    ref = _resize_nearest(_image_to_array(reference_image), target_size, target_size)
    rendered = _resize_nearest(_image_to_array(render_image), target_size, target_size)

    ref_rgb = ref[..., :3]
    rendered_rgb = rendered[..., :3]

    color_diff = float(np.mean(np.abs(ref_rgb - rendered_rgb)))
    color_match = max(0.0, 1.0 - color_diff)
    color_compressed = color_match ** 2.5

    ref_grad = _gradient_magnitude(ref_rgb)
    rendered_grad = _gradient_magnitude(rendered_rgb)
    ref_norm = ref_grad / (np.max(ref_grad) + 1e-6)
    rendered_norm = rendered_grad / (np.max(rendered_grad) + 1e-6)
    grad_diff = float(np.mean(np.abs(ref_norm - rendered_norm)))
    grad_match = max(0.0, 1.0 - grad_diff)
    grad_compressed = grad_match ** 2.0

    combined = 0.7 * color_compressed + 0.3 * grad_compressed
    return max(0.0, min(100.0, combined * 100.0))


def histogram_similarity(reference_image, render_image, target_size=64, bins=32):
    """Compare color histograms via Bhattacharyya coefficient. Returns 0..100."""
    ref = _resize_nearest(_image_to_array(reference_image), target_size, target_size)
    rendered = _resize_nearest(_image_to_array(render_image), target_size, target_size)

    score = 0.0
    for ch in range(3):
        ref_hist, _ = np.histogram(ref[..., ch].ravel(), bins=bins, range=(0, 1))
        ren_hist, _ = np.histogram(rendered[..., ch].ravel(), bins=bins, range=(0, 1))
        ref_p = ref_hist.astype(np.float64) / max(1, ref_hist.sum())
        ren_p = ren_hist.astype(np.float64) / max(1, ren_hist.sum())
        bc = float(np.sum(np.sqrt(ref_p * ren_p)))
        score += bc / 3.0

    return max(0.0, min(100.0, score * 100.0))


def structural_similarity(reference_image, render_image, target_size=64,
                          patch_size=8):
    """SSIM-like structural comparison. Returns 0..100."""
    ref = _resize_nearest(_image_to_array(reference_image), target_size, target_size)
    rendered = _resize_nearest(_image_to_array(render_image), target_size, target_size)

    ref_gray = _to_gray(ref[..., :3])
    ren_gray = _to_gray(rendered[..., :3])

    C1 = 0.01 ** 2
    C2 = 0.03 ** 2

    h, w = ref_gray.shape
    n_py = h // patch_size
    n_px = w // patch_size

    if n_py == 0 or n_px == 0:
        return pixel_similarity(reference_image, render_image, target_size)

    ssim_sum = 0.0
    count = 0
    for py in range(n_py):
        for px in range(n_px):
            y0 = py * patch_size
            x0 = px * patch_size
            rp = ref_gray[y0:y0 + patch_size, x0:x0 + patch_size]
            np_ = ren_gray[y0:y0 + patch_size, x0:x0 + patch_size]

            mu_r = float(np.mean(rp))
            mu_n = float(np.mean(np_))
            var_r = float(np.var(rp))
            var_n = float(np.var(np_))
            cov = float(np.mean((rp - mu_r) * (np_ - mu_n)))

            lum = (2 * mu_r * mu_n + C1) / (mu_r ** 2 + mu_n ** 2 + C1)
            con = (2 * math.sqrt(max(0, var_r)) * math.sqrt(max(0, var_n)) + C2) / (var_r + var_n + C2)
            stru = (cov + C2 / 2) / (math.sqrt(max(0, var_r)) * math.sqrt(max(0, var_n)) + C2 / 2)

            ssim_sum += max(0, lum * con * stru)
            count += 1

    mean_ssim = ssim_sum / max(1, count)
    return max(0.0, min(100.0, (mean_ssim ** 1.5) * 100.0))


def edge_alignment_score(reference_image, render_image, target_size=64):
    """NCC of gradient magnitude maps. Returns 0..100."""
    ref = _resize_nearest(_image_to_array(reference_image), target_size, target_size)
    rendered = _resize_nearest(_image_to_array(render_image), target_size, target_size)

    ref_grad = _gradient_magnitude(ref[..., :3])
    ren_grad = _gradient_magnitude(rendered[..., :3])

    ref_norm = ref_grad / (np.max(ref_grad) + 1e-6)
    ren_norm = ren_grad / (np.max(ren_grad) + 1e-6)

    ref_flat = ref_norm.ravel()
    ren_flat = ren_norm.ravel()

    ref_c = ref_flat - np.mean(ref_flat)
    ren_c = ren_flat - np.mean(ren_flat)

    num = float(np.sum(ref_c * ren_c))
    den = math.sqrt(float(np.sum(ref_c ** 2)) * float(np.sum(ren_c ** 2)))

    ncc = num / den if den > 1e-8 else 0.0
    match = max(0.0, (ncc + 1.0) / 2.0)
    return max(0.0, min(100.0, (match ** 2.0) * 100.0))


# ----------------------------------------------------------------------------
# Quick score for auto-solver (one render → one number)
# ----------------------------------------------------------------------------

def quick_pixel_score(scene, cam, reference_image, output_path=None, strict=True,
                      shading_mode=None):
    """Render-and-score in one call — enhanced blend of strict + edge.

    Args:
        shading_mode: 'SOLID', 'MATERIAL', 'RENDERED', or None (use current).
    """
    import os
    import tempfile
    import bpy
    from . import rendering

    if output_path is None:
        output_path = os.path.join(tempfile.gettempdir(), "photomatch_quick.png")

    rendering.render_camera_to_path(scene, cam, output_path,
                                    shading_mode=shading_mode)

    img = bpy.data.images.load(output_path, check_existing=False)
    try:
        if strict:
            sp = strict_pixel_similarity(reference_image, img, target_size=64)
            ea = edge_alignment_score(reference_image, img, target_size=64)
            return 0.75 * sp + 0.25 * ea
        return pixel_similarity(reference_image, img, target_size=64)
    finally:
        bpy.data.images.remove(img)


# ----------------------------------------------------------------------------
# Pose similarity
# ----------------------------------------------------------------------------

def position_similarity(player_loc, reference_loc, characteristic_distance):
    """0..100 based on exponential distance falloff."""
    if characteristic_distance <= 0:
        characteristic_distance = 1.0
    distance = (player_loc - reference_loc).length
    normalized = distance / characteristic_distance
    score = math.exp(-1.8 * normalized) * 100.0
    return max(0.0, min(100.0, score))


def rotation_similarity(player_quat, reference_quat):
    """0..100 based on forward-vector cosine similarity."""
    forward = Vector((0, 0, -1))
    p_fwd = (player_quat @ forward).normalized()
    r_fwd = (reference_quat @ forward).normalized()
    dot = max(-1.0, min(1.0, p_fwd.dot(r_fwd)))
    alignment = (dot + 1.0) / 2.0
    return max(0.0, min(100.0, (alignment ** 1.5) * 100.0))


# ----------------------------------------------------------------------------
# Adaptive weights + enhanced combined
# ----------------------------------------------------------------------------

def _adaptive_weights(raw_pixel_score):
    """Shift weight from pixel toward structural metrics as score climbs."""
    if raw_pixel_score < 40:
        return (0.45, 0.25, 0.10, 0.10, 0.10)
    elif raw_pixel_score < 70:
        return (0.30, 0.25, 0.10, 0.15, 0.20)
    elif raw_pixel_score < 85:
        return (0.20, 0.25, 0.10, 0.20, 0.25)
    else:
        return (0.15, 0.20, 0.10, 0.25, 0.30)


def enhanced_combined_score(reference_image, render_image,
                            player_cam=None, reference_cam=None,
                            target_object=None):
    """Full multi-metric scoring with adaptive weights.

    Returns a dict with individual scores + combined score.
    """
    from . import geometry

    px = pixel_similarity(reference_image, render_image)
    sp = strict_pixel_similarity(reference_image, render_image)
    hist = histogram_similarity(reference_image, render_image)
    ssim = structural_similarity(reference_image, render_image)
    edge = edge_alignment_score(reference_image, render_image)

    w_px, w_sp, w_hist, w_ssim, w_edge = _adaptive_weights(px)
    visual_score = (
        w_px * px + w_sp * sp + w_hist * hist + w_ssim * ssim + w_edge * edge
    )

    # Progressive difficulty in the 80-100 range
    if visual_score > 80:
        excess = visual_score - 80
        visual_score = 80 + excess * (excess / 20.0) ** 0.3
    visual_score = max(0.0, min(100.0, visual_score))

    result = {
        'pixel': px,
        'strict_pixel': sp,
        'histogram': hist,
        'structural': ssim,
        'edge_alignment': edge,
        'visual_combined': visual_score,
        'position': 0.0,
        'rotation': 0.0,
    }

    if (reference_cam is not None and player_cam is not None
            and target_object is not None):
        ref_loc = reference_cam.matrix_world.translation
        ref_quat = reference_cam.matrix_world.to_quaternion()
        player_loc = player_cam.matrix_world.translation
        player_quat = player_cam.matrix_world.to_quaternion()

        tc, _ = geometry.target_center_and_radius(target_object)
        char_dist = (ref_loc - tc).length

        pos = position_similarity(player_loc, ref_loc, char_dist)
        rot = rotation_similarity(player_quat, ref_quat)
        result['position'] = pos
        result['rotation'] = rot

        final = 0.70 * visual_score + 0.20 * pos + 0.10 * rot
    else:
        final = visual_score

    result['score'] = max(0.0, min(100.0, final))
    return result


# Legacy combined_score for backward compatibility
PIXEL_WEIGHT = 0.60
POSITION_WEIGHT = 0.25
ROTATION_WEIGHT = 0.15


def combined_score(pixel, position, rotation):
    return (
        PIXEL_WEIGHT * pixel
        + POSITION_WEIGHT * position
        + ROTATION_WEIGHT * rotation
    )
