"""Reactive model-based object tracking.

Instead of a fixed-rate timer, this tracker is EVENT-DRIVEN:

  - When the REFERENCE IMAGE changes (new phone frame, new challenge,
    user loads a file) → rebuild the feature map from that image.
  - When the CAMERA MOVES (detected via depsgraph_update_post) →
    render the current view, match features against the reference map,
    update tracking state and confidence.

This means zero wasted renders when nothing changes, and instant
response when something does.

Components:
  - FeatureMap: FAST/BRIEF features extracted from the reference image,
    each linked to a 3D vertex on the target object
  - MotionModel: constant-velocity smoother for prediction
  - ObjectTracker: the main tracking class
  - Depsgraph handler: watches for camera matrix changes

State machine: IDLE → ACQUIRING → TRACKING → RE_ACQUIRING → LOST
"""

import math
import time

import numpy as np
import bpy

from mathutils import Vector, Matrix


# ============================================================================
# State machine
# ============================================================================

class TrackingState:
    IDLE = 'IDLE'
    ACQUIRING = 'ACQUIRING'
    TRACKING = 'TRACKING'
    RE_ACQUIRING = 'RE_ACQUIRING'
    LOST = 'LOST'


# ============================================================================
# Motion model — constant-velocity with exponential smoothing
# ============================================================================

class MotionModel:
    """Predicts the next camera pose from recent motion history."""

    def __init__(self, smoothing=0.7):
        self.smoothing = smoothing
        self._prev_position = None
        self._velocity = np.zeros(3, dtype=np.float64)

    def update(self, position):
        pos = np.array([position.x, position.y, position.z], dtype=np.float64)
        if self._prev_position is not None:
            raw_vel = pos - self._prev_position
            self._velocity = (self.smoothing * self._velocity
                              + (1.0 - self.smoothing) * raw_vel)
        self._prev_position = pos.copy()

    def predict_position(self):
        if self._prev_position is None:
            return None
        predicted = self._prev_position + self._velocity
        return Vector((predicted[0], predicted[1], predicted[2]))

    def reset(self):
        self._prev_position = None
        self._velocity = np.zeros(3, dtype=np.float64)


# ============================================================================
# Feature map — reference features tied to 3D positions
# ============================================================================

class FeatureMap:
    """FAST/BRIEF features from the reference image, each linked to a 3D
    position on the target object.

    Built from the reference image (not a render), so it automatically
    tracks whatever image the user is trying to match.
    """

    def __init__(self):
        self.keypoints_2d = None   # Nx2 (row, col)
        self.descriptors = None    # Nx32 uint8
        self.points_3d = None      # Nx3 world-space
        self.image_size = (0, 0)
        self.num_features = 0
        self._ref_image_name = ""  # track which image was used

    def build_from_reference(self, scene, reference_cam, target_obj,
                             reference_image):
        """Build features from a bpy.types.Image (the reference).

        The reference camera's pose is used to back-project 2D features
        to 3D positions on the object.
        """
        from . import cv_scoring

        if reference_image is None or reference_cam is None:
            self.num_features = 0
            return

        self._ref_image_name = reference_image.name

        # Convert reference image to grayscale numpy array
        pixels = np.array(reference_image.pixels[:], dtype=np.float32)
        w, h = reference_image.size
        if w == 0 or h == 0:
            self.num_features = 0
            return

        rgb = pixels.reshape(h, w, 4)[..., :3]
        gray = 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]
        self.image_size = (h, w)

        # Detect features in the reference image
        kp = cv_scoring.fast_corners(gray, threshold=0.08)
        if len(kp) == 0:
            self.num_features = 0
            return

        desc = cv_scoring.brief_descriptors(gray, kp)

        # Get object vertices in world space
        verts_world = cv_scoring._get_object_vertices_world(target_obj)
        if len(verts_world) == 0:
            self.num_features = 0
            return

        # Project vertices through the REFERENCE camera
        verts_2d, depths = cv_scoring._project_points(
            scene, reference_cam, verts_world)
        visible = depths > 0

        if np.sum(visible) < 3:
            self.num_features = 0
            return

        vis_verts_2d = verts_2d[visible]
        vis_verts_3d = verts_world[visible]

        # Link each keypoint to the nearest projected vertex
        matched_3d = []
        matched_kp = []
        matched_desc = []

        for i in range(len(kp)):
            ky, kx = kp[i]
            kp_px = np.array([kx, h - ky], dtype=np.float64)

            dists = np.sqrt(np.sum((vis_verts_2d - kp_px) ** 2, axis=1))
            nearest_idx = int(np.argmin(dists))

            max_dist = max(h, w) * 0.15
            if dists[nearest_idx] < max_dist:
                matched_3d.append(vis_verts_3d[nearest_idx])
                matched_kp.append(kp[i])
                matched_desc.append(desc[i])

        if len(matched_3d) < 4:
            self.num_features = 0
            return

        self.keypoints_2d = np.array(matched_kp, dtype=np.int32)
        self.descriptors = np.array(matched_desc, dtype=np.uint8)
        self.points_3d = np.array(matched_3d, dtype=np.float64)
        self.num_features = len(matched_3d)

    @property
    def reference_image_name(self):
        return self._ref_image_name


# ============================================================================
# Pose refiner — lightweight iterative least-squares
# ============================================================================

def refine_pose_least_squares(scene, camera, points_3d, points_2d_observed,
                              iterations=5, step=0.01):
    """Nudge camera position to minimize reprojection error."""
    from . import cv_scoring

    n = len(points_3d)
    if n < 4:
        return None, float('inf')

    saved_mat = camera.matrix_world.copy()
    best_pos = camera.matrix_world.translation.copy()
    best_error = float('inf')

    try:
        proj, depths = cv_scoring._project_points(scene, camera, points_3d)
        visible = depths > 0
        if np.sum(visible) < 3:
            return None, float('inf')
        errors = np.sqrt(np.sum(
            (proj[visible] - points_2d_observed[visible]) ** 2, axis=1))
        best_error = float(np.mean(errors))

        for iteration in range(iterations):
            current_step = step * (0.7 ** iteration)
            for axis in range(3):
                for sign in [1, -1]:
                    test_pos = best_pos.copy()
                    test_pos[axis] += sign * current_step
                    camera.matrix_world = saved_mat.copy()
                    camera.matrix_world.translation = test_pos

                    proj, depths = cv_scoring._project_points(
                        scene, camera, points_3d)
                    visible = depths > 0
                    if np.sum(visible) < 3:
                        continue
                    errors = np.sqrt(np.sum(
                        (proj[visible] - points_2d_observed[visible]) ** 2,
                        axis=1))
                    err = float(np.mean(errors))
                    if err < best_error:
                        best_error = err
                        best_pos = test_pos.copy()
    finally:
        camera.matrix_world = saved_mat

    return best_pos, best_error


# ============================================================================
# Object Tracker — reactive, reference-image-driven
# ============================================================================

class ObjectTracker:
    """Event-driven model-based tracker.

    Does NOT run on a fixed timer. Instead:
      - Call on_reference_changed() when the reference image changes
      - Call on_camera_moved() when the camera moves
    Both are triggered by the depsgraph handler or operator callbacks.
    """

    MIN_INLIERS_TRACKING = 6
    MIN_INLIERS_ACQUIRING = 4
    MATCH_DISTANCE_THRESHOLD = 64
    RE_DETECT_INTERVAL = 15
    LOST_TIMEOUT_FRAMES = 30
    MATCH_RADIUS_PX = 50

    def __init__(self):
        self.state = TrackingState.IDLE
        self.feature_map = FeatureMap()
        self.motion_model = MotionModel()

        self.confidence = 0.0
        self.inlier_count = 0
        self.total_features = 0
        self.reproj_error = 999.0
        self.frames_tracked = 0
        self.frames_since_good = 0

        self._target_obj = None
        self._reference_cam = None
        self._frame_count = 0
        self._is_running = False
        self._last_cam_matrix = None

    @property
    def is_initialized(self):
        return self.feature_map.num_features > 0

    @property
    def status_text(self):
        if self.state == TrackingState.IDLE:
            return "Idle — initialize tracking first"
        elif self.state == TrackingState.ACQUIRING:
            return f"Acquiring... ({self.feature_map.num_features} ref features)"
        elif self.state == TrackingState.TRACKING:
            return (f"Tracking — {self.inlier_count}/{self.total_features} "
                    f"features, {self.confidence:.0f}%, "
                    f"reproj: {self.reproj_error:.1f}px")
        elif self.state == TrackingState.RE_ACQUIRING:
            return f"Re-acquiring... lost {self.frames_since_good} frames ago"
        elif self.state == TrackingState.LOST:
            return "Lost — point camera at the object and re-initialize"
        return "Unknown"

    def initialize(self, scene, reference_cam, target_obj, reference_image):
        """Build feature map from the reference image.

        Called when user clicks "Object Found — Track Object".
        Uses the reference image directly, not a render.
        """
        self._target_obj = target_obj
        self._reference_cam = reference_cam
        self.motion_model.reset()
        self.frames_tracked = 0
        self.frames_since_good = 0
        self._frame_count = 0

        self.feature_map.build_from_reference(
            scene, reference_cam, target_obj, reference_image)
        self.total_features = self.feature_map.num_features

        if self.feature_map.num_features >= self.MIN_INLIERS_ACQUIRING:
            self.state = TrackingState.ACQUIRING
            return True
        else:
            self.state = TrackingState.LOST
            return False

    def start(self):
        self._is_running = True
        self._last_cam_matrix = None

    def stop(self):
        self._is_running = False
        if self.state != TrackingState.IDLE:
            self.state = TrackingState.IDLE

    def on_reference_changed(self, scene, reference_cam, target_obj,
                              reference_image):
        """Called when the reference image is updated (new phone frame,
        new challenge, etc.). Rebuilds the feature map.
        """
        if not self._is_running:
            return
        self._reference_cam = reference_cam
        self._target_obj = target_obj
        self.feature_map.build_from_reference(
            scene, reference_cam, target_obj, reference_image)
        self.total_features = self.feature_map.num_features
        if self.total_features >= self.MIN_INLIERS_ACQUIRING:
            if self.state == TrackingState.LOST:
                self.state = TrackingState.ACQUIRING
        else:
            self.state = TrackingState.LOST

    def has_camera_moved(self, camera):
        """Check if the camera matrix changed since last update."""
        if camera is None:
            return False
        current = camera.matrix_world.copy()
        if self._last_cam_matrix is None:
            self._last_cam_matrix = current
            return True
        # Compare translation + rotation (cheap)
        diff = 0.0
        for i in range(4):
            for j in range(4):
                diff += abs(current[i][j] - self._last_cam_matrix[i][j])
        if diff > 1e-5:
            self._last_cam_matrix = current
            return True
        return False

    def on_camera_moved(self, scene, camera):
        """Called when the camera has moved. Renders current view and
        matches against the reference feature map.

        This is the main tracking update — called reactively, not on
        a fixed timer.
        """
        if not self._is_running:
            return self._make_result()
        if self.state in (TrackingState.IDLE, TrackingState.LOST):
            return self._make_result()
        if self.feature_map.num_features == 0:
            return self._make_result()

        self._frame_count += 1
        self.motion_model.update(camera.matrix_world.translation)

        # Render the current camera view as grayscale
        gray = self._render_gray(scene, camera)
        if gray is None:
            return self._make_result()

        # Detect features in current frame
        from . import cv_scoring
        current_kp = cv_scoring.fast_corners(gray, threshold=0.08)
        if len(current_kp) < 3:
            self._handle_no_features()
            return self._make_result()

        current_desc = cv_scoring.brief_descriptors(gray, current_kp)

        # Match against reference map
        ref_idx, cur_idx, dists = self._match_features(
            scene, camera, current_kp, current_desc, gray.shape)

        self.inlier_count = len(ref_idx)

        if self.inlier_count >= self.MIN_INLIERS_TRACKING:
            self.state = TrackingState.TRACKING
            self.frames_tracked += 1
            self.frames_since_good = 0

            # Compute reprojection error
            ref_3d = self.feature_map.points_3d[ref_idx]
            h, w = gray.shape
            cur_2d = np.array([
                [current_kp[i, 1], h - current_kp[i, 0]]
                for i in cur_idx
            ], dtype=np.float64)

            _, self.reproj_error = refine_pose_least_squares(
                scene, camera, ref_3d, cur_2d, iterations=3, step=0.05)

            inlier_ratio = self.inlier_count / max(1, self.total_features)
            reproj_quality = max(0, 1.0 - self.reproj_error / 50.0)
            self.confidence = min(100.0,
                                  (0.6 * inlier_ratio + 0.4 * reproj_quality) * 100)

        elif self.inlier_count >= self.MIN_INLIERS_ACQUIRING:
            self.state = TrackingState.RE_ACQUIRING
            self.frames_since_good += 1
            self.confidence = max(0, self.confidence - 5)
        else:
            self._handle_no_features()

        return self._make_result()

    def _match_features(self, scene, camera, current_kp, current_desc,
                        image_shape):
        """Guided matching: project reference 3D points, match nearby."""
        from . import cv_scoring

        h, w = image_shape
        ref_3d = self.feature_map.points_3d
        ref_desc = self.feature_map.descriptors

        proj_2d, depths = cv_scoring._project_points(scene, camera, ref_3d)
        visible = depths > 0

        ref_indices = []
        cur_indices = []
        match_distances = []

        for ri in range(len(ref_3d)):
            if not visible[ri]:
                continue
            px, py = proj_2d[ri]
            best_dist = self.MATCH_DISTANCE_THRESHOLD + 1
            best_ci = -1

            for ci in range(len(current_kp)):
                ky, kx = current_kp[ci]
                kpx, kpy = float(kx), float(h - ky)
                spatial_dist = math.sqrt((kpx - px) ** 2 + (kpy - py) ** 2)
                if spatial_dist > self.MATCH_RADIUS_PX:
                    continue
                hdist = cv_scoring._hamming_distance(ref_desc[ri],
                                                     current_desc[ci])
                if hdist < best_dist:
                    best_dist = hdist
                    best_ci = ci

            if best_ci >= 0 and best_dist <= self.MATCH_DISTANCE_THRESHOLD:
                ref_indices.append(ri)
                cur_indices.append(best_ci)
                match_distances.append(best_dist)

        return (np.array(ref_indices, dtype=np.int32),
                np.array(cur_indices, dtype=np.int32),
                np.array(match_distances, dtype=np.float64))

    def _handle_no_features(self):
        self.frames_since_good += 1
        self.confidence = max(0, self.confidence - 10)
        if self.frames_since_good > self.LOST_TIMEOUT_FRAMES:
            self.state = TrackingState.LOST
            self.confidence = 0
        elif self.state == TrackingState.TRACKING:
            self.state = TrackingState.RE_ACQUIRING

    def _render_gray(self, scene, camera):
        """Render current camera view as grayscale HxW float32."""
        import os
        import tempfile
        from . import rendering

        try:
            path = os.path.join(tempfile.gettempdir(),
                                "photomatch_tracker_frame.png")
            rendering.render_camera_to_path(scene, camera, path)
            img = bpy.data.images.load(path, check_existing=False)
            try:
                pixels = np.array(img.pixels[:], dtype=np.float32)
                h, w = img.size[1], img.size[0]
                rgb = pixels.reshape(h, w, 4)[..., :3]
                return (0.299 * rgb[..., 0] + 0.587 * rgb[..., 1]
                        + 0.114 * rgb[..., 2])
            finally:
                bpy.data.images.remove(img)
        except Exception:
            return None

    def _make_result(self):
        return {
            'state': self.state,
            'confidence': self.confidence,
            'inliers': self.inlier_count,
            'total_features': self.total_features,
            'reproj_error': self.reproj_error,
            'frames_tracked': self.frames_tracked,
            'status': self.status_text,
            'is_tracking': self.state == TrackingState.TRACKING,
        }


# ============================================================================
# Singleton + depsgraph handler
# ============================================================================

_tracker = None
_handler_registered = False


def get_tracker():
    global _tracker
    if _tracker is None:
        _tracker = ObjectTracker()
    return _tracker


def reset_tracker():
    global _tracker
    if _tracker is not None:
        _tracker.stop()
    _tracker = None
    _unregister_handler()


def _depsgraph_handler(scene, depsgraph):
    """Called after every depsgraph update. Checks if the camera moved
    and triggers a tracking update if so.

    This is the reactive core: no timer, just event-driven updates.
    """
    tracker = get_tracker()
    if not tracker._is_running:
        return

    camera = scene.camera
    if camera is None:
        return

    # Only update if the camera actually moved
    if not tracker.has_camera_moved(camera):
        return

    # Throttle: don't update more than ~10 times per second
    now = time.time()
    if hasattr(tracker, '_last_update_time'):
        if now - tracker._last_update_time < 0.1:
            return
    tracker._last_update_time = now

    try:
        props = scene.photo_match_props
        result = tracker.on_camera_moved(scene, camera)

        # Push results to properties for UI display
        props.obj_tracker_status = result['status']
        props.obj_tracker_confidence = result['confidence']
        props.obj_tracker_inliers = result['inliers']
        props.obj_tracker_total_features = result['total_features']
        props.obj_tracker_reproj_error = result['reproj_error']

        # Tag viewport for redraw
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception as e:
        print(f"Photo Match tracker handler error: {e}")


def _register_handler():
    """Register the depsgraph update handler."""
    global _handler_registered
    if not _handler_registered:
        bpy.app.handlers.depsgraph_update_post.append(_depsgraph_handler)
        _handler_registered = True


def _unregister_handler():
    """Unregister the depsgraph update handler."""
    global _handler_registered
    if _handler_registered:
        try:
            bpy.app.handlers.depsgraph_update_post.remove(_depsgraph_handler)
        except ValueError:
            pass
        _handler_registered = False


def start_tracking():
    """Register the handler and start the tracker."""
    tracker = get_tracker()
    tracker.start()
    _register_handler()


def stop_tracking():
    """Stop the tracker and unregister the handler."""
    tracker = get_tracker()
    tracker.stop()
    _unregister_handler()
