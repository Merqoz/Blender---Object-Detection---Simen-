"""Live tracking — wires the state machine to the live feed (Step 5).

Once the user has pressed Initial Lock and we have a confirmed pose, this
module's match timer takes over: each tick it pulls the latest phone
frame, refreshes the reference image, and runs the state machine to polish
the Blender camera against the new view. The tick interval defaults to
1 Hz but is configurable via `props.match_interval` (Advanced sub-panel).

Module layout:

  Frame-capture helper:
    _refresh_reference_from_live_feed() — pull latest JPEG from live_feed,
        decode into LOCK_FRAME_IMAGE_NAME, set as props.reference_image,
        invalidate feature cache.

  Executor builders (closures over scene + props):
    _build_full_solve_gen() — generator-style cold-start V3 search,
        ~60 evals chunked across 3-4 ticks
    _build_warm_solve()    — synchronous warm-start V3 search, ~15 evals
    _build_locked_polish() — single Hooke-Jeeves step via fine_tune.CameraPolisher

  State machine lifecycle:
    start_tracking(scene, props, initial_score) — called by Initial Lock
    stop_tracking(scene, props) — called by Stop, addon unregister, etc.

  Match timer (configurable, default 1 Hz):
    _match_timer_callback() — registered via bpy.app.timers when tracking starts

  Operators:
    PHOTOMATCH_OT_InitialLock — captures frame, runs full V3 once,
        calls start_tracking on success
    PHOTOMATCH_OT_ReLock      — captures frame, warm V3, escalates to
        full V3 if score < 60, drops result into the SM

Threading: all callbacks here run on the main thread. The frame slot in
live_feed.py is the only cross-thread interface, and we read it under its
own lock.
"""

import bpy
import numpy as np
import time
from bpy.types import Operator
from mathutils import Vector

from . import camera_utils
from . import fine_tune
from . import geometry
from . import live_feed
from . import search_v3
from . import tracking_state


# ============================================================================
# Constants
# ============================================================================

# How many V3 evaluations the full-solve generator does between yields.
# Balance: too few = many tiny ticks, weird timing; too many = UI judder.
# At ~30 ms/eval and 1 s tick budget, 20 evals/yield = ~600 ms of work and
# ~400 ms of slack for everything else (frame decode, etc).
_FULL_SOLVE_EVALS_PER_YIELD = 20

# Default match-tick interval if for any reason the property can't be read
# (e.g. teardown races where context.scene's photo_match_props is gone).
# Match interval is normally driven by `props.match_interval`.
_DEFAULT_MATCH_INTERVAL = 1.0

# Default per-regime budgets — fallbacks only. The match-tick normally reads
# `props.budget_full_solve` and `props.budget_warm_solve` instead. These
# constants exist for the rare path where props aren't reachable (timer
# firing during teardown, headless tests).
_DEFAULT_FULL_SOLVE_BUDGET = 60
_DEFAULT_WARM_SOLVE_BUDGET = 15

# Re-Lock escalation threshold (handoff §3 line 167). If the warm V3 search
# came back below this score, escalate to a full cold-start V3.
_RELOCK_ESCALATION_SCORE = 60.0

# Render resolution for executor scoring. The live-feed match timer has
# tighter time budget than the modal AutoSolve, so we go smaller.
_QUICK_RES = 192

# How long without a fresh phone frame before the match-tick gives up
# trying to score and the UI starts showing a "phone disconnected" banner
# (handoff edge case §404).
_STALE_FRAME_GRACE_SECONDS = 2.0

# Image data-block holding the current "reference" frame (latest from phone).
# Created on first frame capture, reused thereafter; populated in-place by
# _refresh_reference_from_live_feed.
LOCK_FRAME_IMAGE_NAME = "photomatch_lock_frame"


# ============================================================================
# Module-level state
# ============================================================================

# The active state machine, or None when not tracking.
_state_machine = None

# Saved render resolution to restore on stop_tracking. Tuple (x, y) or None.
_saved_resolution = None


def is_tracking():
    """Public — used by the UI panel and by operators to gate behavior."""
    return _state_machine is not None


# ============================================================================
# Frame capture: pull JPEG from live_feed slot → bpy.data.images
# ============================================================================

def _refresh_reference_from_live_feed(scene, props):
    """Pull the latest live phone frame and wire it up as the reference image.

    Caller is responsible for handling the False return — typically that means
    "phone disconnected, skip this tick" rather than "fail loudly".

    Returns:
        True if a frame was successfully captured and wired up.
        False if no frame is available (phone hasn't sent one yet, or has
        disconnected) or decoding failed.
    """
    # Read the latest frame under the live_feed module's frame lock
    with live_feed._frame_lock:
        frame_bytes = live_feed._latest_frame
        frame_seq = live_feed._latest_frame_seq

    if frame_bytes is None:
        return False

    # Decode JPEG → numpy RGB
    decoded = live_feed._decode_jpeg_to_rgb(frame_bytes)
    if decoded is None:
        return False
    width, height, rgb = decoded

    # Get-or-create the lock-frame image data-block. Resize-on-mismatch is
    # the same pattern live_feed uses for its display image, but we keep
    # them separate so the user can leave the live_feed image as a viewport
    # background overlay independent of what the matching is doing.
    img = bpy.data.images.get(LOCK_FRAME_IMAGE_NAME)
    if img is not None and (img.size[0] != width or img.size[1] != height):
        bpy.data.images.remove(img)
        img = None
    if img is None:
        img = bpy.data.images.new(LOCK_FRAME_IMAGE_NAME, width, height, alpha=True)

    # PIL → Blender pixel layout: float32 RGBA in [0,1], rows reversed
    rgba = np.empty((height, width, 4), dtype=np.float32)
    rgba[..., :3] = rgb[::-1].astype(np.float32) / 255.0
    rgba[..., 3] = 1.0
    img.pixels.foreach_set(rgba.ravel())
    img.update_tag()

    # Wire up as reference (skipping disk path — handoff §8.1)
    from . import operators
    player_cam = scene.camera
    operators._set_reference_image_inmemory(
        scene, props, player_cam, img,
        remove_old_if_orphan=False,  # we're updating in-place every tick
    )
    return True


# ============================================================================
# Executor builders — closures over the scene/props
# ============================================================================
#
# Each executor is a no-arg callable per the tracking_state API contract.
# They close over `scene` and `props` so the state machine can stay
# Blender-agnostic.

def _start_pose_for_search(scene, props):
    """Compute the (target_center, start_direction, start_distance) tuple
    used to seed a new V3 search from the current camera + target."""
    target = props.target_object
    if target is None:
        # No target → can't search. Caller should never invoke an executor
        # in this state (Initial Lock validates upfront).
        raise RuntimeError("Live tracking requires a target object")
    target_center, target_radius = geometry.target_center_and_radius(target)

    cam = scene.camera
    if cam is None:
        raise RuntimeError("Live tracking requires an active camera")

    offset = cam.matrix_world.translation - target_center
    if offset.length < 0.01:
        # Degenerate: camera ON the object. Pick a sensible default offset.
        offset = Vector((0, -max(target_radius * 3, 5), max(target_radius, 1)))
    return target_center, offset.normalized(), offset.length


def _run_v3_search_chunked(scene, props, *, cold_start, evals_per_yield,
                           max_evals):
    """Generator that drives a CameraSolveStateV3 to completion, yielding
    None periodically so the state machine's tick can return to the timer.

    Used by the full_solve_gen executor (cold_start=True). Single-tick
    callers should use `_run_v3_search_full` instead.

    Yields: None (between chunks of evaluations).
    Returns (via StopIteration.value): the final best score (float 0..100).
    """
    from . import operators

    target_center, start_dir, start_dist = _start_pose_for_search(scene, props)
    state = search_v3.CameraSolveStateV3(
        target_center=target_center,
        start_direction=start_dir,
        start_distance=start_dist,
        upper_hemisphere=props.upper_hemisphere_only,
        cold_start=cold_start,
    )

    # Snapshot contour features for the duration of THIS solve. The match
    # timer refreshes the reference between SM ticks; our generator builds
    # features once at start, holding them stable across the search.
    contour_features = operators._get_or_build_reference_features(props)
    if contour_features is None:
        # Reference disappeared between Initial Lock and now — bail with
        # zero score. SM will treat this as a failed solve and stay in
        # whatever regime it was; auto_recover (if on) might escalate.
        return 0.0

    cam = scene.camera
    evals_this_chunk = 0

    while True:
        candidate = state.next_candidate()
        if candidate is None:
            break  # search plan exhausted
        if state.evaluations_done >= max_evals:
            break  # budget cap

        _phase, direction, distance = candidate
        position = target_center + direction * distance
        camera_utils.position_camera(cam, position, target_center)

        score = operators._contour_score_render(
            scene, cam, props, contour_features
        )
        state.report_score(direction, distance, score)

        evals_this_chunk += 1
        if evals_this_chunk >= evals_per_yield:
            yield None  # let the timer breathe
            evals_this_chunk = 0

    # Apply the best pose found
    if state.best_score >= 0:
        best_pos = (
            target_center + state.best_direction * state.best_distance
        )
        camera_utils.position_camera(cam, best_pos, target_center)

    return float(max(state.best_score, 0.0))


def _run_v3_search_full(scene, props, *, cold_start, max_evals):
    """Synchronous V3 search that runs to completion in one call. Used by
    the warm_solve executor (cold_start=False, small budget) and by the
    Initial Lock / Re-Lock operators (cold_start variable, full budget).

    Returns the final best score."""
    # Reuse the chunked generator; pump it to completion and grab the
    # StopIteration value. Chunking is no-op when the caller doesn't want
    # cooperative multitasking — we just iterate through every yield.
    gen = _run_v3_search_chunked(
        scene, props,
        cold_start=cold_start,
        evals_per_yield=max(1, max_evals + 1),  # never actually yield
        max_evals=max_evals,
    )
    while True:
        try:
            next(gen)
        except StopIteration as e:
            return float(e.value if e.value is not None else 0.0)


def _build_executors(scene, props):
    """Construct the three regime-specific executor callables. Closes over
    `scene` + `props` so the state machine stays Blender-agnostic.

    The polisher is shared across calls: the LOCKED-regime executor reuses
    the same instance so its Hooke-Jeeves step sizes accumulate correctly
    across ticks (success grows the step, miss shrinks it)."""
    polisher = fine_tune.CameraPolisher()

    # Budgets are read from props at call time, not closure time, so the
    # advanced-settings sliders take effect on the very next solve.
    def full_solve():
        """Lost regime — runs as a multi-tick generator."""
        return _run_v3_search_chunked(
            scene, props,
            cold_start=True,
            evals_per_yield=_FULL_SOLVE_EVALS_PER_YIELD,
            max_evals=int(getattr(props, 'budget_full_solve',
                                  _DEFAULT_FULL_SOLVE_BUDGET)),
        )

    def warm_solve():
        """Tracking regime — synchronous, single tick."""
        return _run_v3_search_full(
            scene, props,
            cold_start=False,
            max_evals=int(getattr(props, 'budget_warm_solve',
                                  _DEFAULT_WARM_SOLVE_BUDGET)),
        )

    def locked_polish():
        """Locked regime — one Hooke-Jeeves perturbation."""
        from . import operators
        cam = scene.camera
        if cam is None:
            return polisher.last_score
        contour_features = operators._get_or_build_reference_features(props)
        return polisher.step(scene, cam, props, contour_features)

    return tracking_state.Executors(
        full_solve=full_solve,
        warm_solve=warm_solve,
        locked_polish=locked_polish,
    )


def _read_match_interval(props):
    """Read the match-interval property safely. Falls back to the default
    if props isn't reachable or the value is unsanitised."""
    try:
        v = float(getattr(props, 'match_interval', _DEFAULT_MATCH_INTERVAL))
        # Tighter clamp than the property's own min — an interval below 0.1s
        # would make Blender unresponsive.
        return max(0.1, min(v, 10.0))
    except (AttributeError, TypeError, ValueError):
        return _DEFAULT_MATCH_INTERVAL


# ============================================================================
# Match timer
# ============================================================================

def _match_timer_callback():
    """Match-tick callback. Returns the next-call interval (or None to
    unregister this timer). Interval is read from `props.match_interval`
    on every tick so the slider takes effect immediately.

    Each tick:
      1. Refresh the reference image from the latest phone frame
      2. Sync auto-recover prop into the SM (in case user toggled it)
      3. Run the SM tick
      4. Mirror result into properties for the UI

    If no frame is available (phone hasn't sent one yet, or just
    disconnected), we skip the tick — better to keep the timer alive in
    case the phone reconnects than to thrash the SM with a 0-score result.

    Stale-frame banner (handoff §404): if the live feed module reports the
    last frame's age > _STALE_FRAME_GRACE_SECONDS, we mirror that into
    `props.tracking_stale_frame` so the UI sub-panel can show "Phone
    disconnected, waiting…" without doing its own timing.
    """
    if _state_machine is None:
        return None  # tracking stopped — unregister this timer

    try:
        scene = bpy.context.scene
        props = scene.photo_match_props
    except (AttributeError, RuntimeError):
        return None

    interval = _read_match_interval(props)

    # Sanity: the user might have stopped the live feed without going through
    # Stop Tracking. In that case, just unregister and let stop_tracking
    # clean up properly the next time something looks at it.
    if not props.live_feed_running or not props.tracking_locked:
        return None

    # Compute stale-frame state. Read live_feed's frame timestamp under its
    # own lock; staleness is a property mirror so the UI can show a banner
    # without polling the live_feed module directly.
    with live_feed._frame_lock:
        last_frame_at = live_feed._latest_frame_at
    age = (time.monotonic() - last_frame_at) if last_frame_at > 0 else 999.0
    stale = age >= _STALE_FRAME_GRACE_SECONDS
    if hasattr(props, 'tracking_stale_frame') and props.tracking_stale_frame != stale:
        props.tracking_stale_frame = stale

    # 1. Refresh reference from latest live frame
    refreshed = _refresh_reference_from_live_feed(scene, props)
    if not refreshed:
        # Phone disconnected or no frame yet. Keep the timer alive but skip
        # this tick — scoring against stale data would be worse than waiting.
        return interval

    # 2. Sync auto-recover preference (user can toggle it any time)
    _state_machine.set_auto_recover(props.tracking_auto_recover)

    # 3. Tick the SM
    try:
        result = _state_machine.tick()
    except Exception as e:
        import traceback
        traceback.print_exc()
        print(f"[live_tracking] SM tick failed: {e}")
        return interval

    # 4. Mirror result into props for UI display
    props.tracking_state = result.regime
    props.tracking_last_score = float(result.score)

    # Tag viewport so the camera-pose change becomes visible
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            area.tag_redraw()

    return interval


# ============================================================================
# Lifecycle
# ============================================================================

def start_tracking(scene, props, initial_score):
    """Start live tracking after a successful Initial Lock.

    Creates the state machine, drops `initial_score` into it (skipping the
    LOST→TRACKING climb, since we already verified a good pose), saves the
    current render resolution for restoration on stop, and registers the
    match timer.
    """
    global _state_machine, _saved_resolution

    if _state_machine is not None:
        # Re-Lock will call stop_tracking first; this is a defensive guard
        stop_tracking(scene, props)

    executors = _build_executors(scene, props)
    _state_machine = tracking_state.TrackingStateMachine(
        executors,
        auto_recover=props.tracking_auto_recover,
    )
    _state_machine.set_locked(initial_score)

    # Mirror initial state into props
    props.tracking_locked = True
    props.tracking_state = tracking_state.LOCKED
    props.tracking_last_score = float(initial_score)

    # Save render resolution + drop to quick res for executor scoring
    _saved_resolution = (
        scene.render.resolution_x,
        scene.render.resolution_y,
    )
    ref = props.reference_image
    if ref is not None and ref.size[0] > 0 and ref.size[1] > 0:
        aspect = ref.size[0] / ref.size[1]
        if aspect >= 1:
            scene.render.resolution_x = _QUICK_RES
            scene.render.resolution_y = max(2, int(_QUICK_RES / aspect))
        else:
            scene.render.resolution_y = _QUICK_RES
            scene.render.resolution_x = max(2, int(_QUICK_RES * aspect))

    # Register the timer (idempotent guard). First-call interval comes from
    # props so the slider takes effect on a fresh start_tracking too, not
    # only on subsequent ticks.
    if not bpy.app.timers.is_registered(_match_timer_callback):
        bpy.app.timers.register(
            _match_timer_callback, first_interval=_read_match_interval(props),
        )


def stop_tracking(scene, props):
    """Tear down live tracking. Idempotent — safe to call when not tracking.

    Per handoff edge case §403: leaves the lock-frame image and the
    reference data-block alone. The user might want to keep matching against
    the last frame statically after stopping the feed."""
    global _state_machine, _saved_resolution

    _state_machine = None

    # Unregister timer
    if bpy.app.timers.is_registered(_match_timer_callback):
        try:
            bpy.app.timers.unregister(_match_timer_callback)
        except Exception:
            pass

    # Restore render resolution
    if _saved_resolution is not None and scene is not None:
        try:
            scene.render.resolution_x = _saved_resolution[0]
            scene.render.resolution_y = _saved_resolution[1]
        except Exception:
            pass
        _saved_resolution = None

    # Reset tracking props (UI signal that we're done)
    if props is not None:
        try:
            props.tracking_locked = False
            props.tracking_state = tracking_state.LOST
            # Don't clear tracking_last_score — leaves a "you scored 87% before
            # stopping" trace in the UI. Cleared on the next start_tracking.
        except (AttributeError, ReferenceError):
            pass


def relock_with_score(score):
    """Called by the Re-Lock operator to drop a fresh score into the SM
    without going through the full Stop+Start cycle. Preserves the SM
    instance so the LOCKED-regime polisher's step state survives."""
    if _state_machine is not None:
        _state_machine.set_locked(score)


# ============================================================================
# Property update bridges
# ============================================================================
#
# `properties.py` registers these as the `update=` callbacks on the
# `tracking_auto_recover` and `threshold_*` properties. They forward the new
# value into the running state machine, if any. When no SM is active they
# silently no-op — the next start_tracking() will pick up the current property
# values when it constructs the SM.
#
# Why per-edit callbacks AND a per-tick re-sync (the match-timer also pushes
# auto_recover via `set_auto_recover` every tick)? Latency. Without the
# update callbacks, threshold changes would only take effect on the next
# match-tick boundary — up to a full second of stale behaviour. For the
# threshold sliders that's a UX problem (drag the slider, watch the regime
# fail to react). The match-timer re-sync exists as a safety net for any
# program-driven mutations that bypass the property update system.

def on_auto_recover_changed(value):
    """Push a new auto-recover toggle value into the running SM."""
    if _state_machine is not None:
        _state_machine.set_auto_recover(bool(value))


def on_thresholds_changed(*, tracking_to_lost, lost_to_tracking,
                           locked_to_tracking, tracking_to_locked):
    """Push a fresh set of hysteresis thresholds into the running SM.

    All four kwargs are required — the caller (`properties._tracking_thresholds_update`)
    sends the complete set on every edit rather than tracking which field
    changed. Simpler and more robust than figuring out per-field deltas."""
    if _state_machine is not None:
        _state_machine.set_thresholds(
            tracking_to_lost=tracking_to_lost,
            lost_to_tracking=lost_to_tracking,
            locked_to_tracking=locked_to_tracking,
            tracking_to_locked=tracking_to_locked,
        )


# ============================================================================
# Initial Lock operator
# ============================================================================

class PHOTOMATCH_OT_InitialLock(Operator):
    """Capture the current phone frame, run a full V3 solve, start live tracking.

    Synchronous — blocks the UI for ~1-3 seconds while V3 runs. The
    alternative (modal with progress UI) is reserved for Step 6's UX polish.
    """
    bl_idname = "photomatch.initial_lock"
    bl_label = "Initial Lock"
    bl_description = ("Freeze the current phone frame, find the best Blender "
                      "camera pose to match it, and start live tracking")
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        try:
            props = context.scene.photo_match_props
        except AttributeError:
            return False
        # Need a connected phone (otherwise no frame to lock onto), a target
        # object, and not already locked
        return (
            props.live_feed_running
            and props.live_feed_phone_connected
            and props.target_object is not None
            and not props.tracking_locked
        )

    def execute(self, context):
        scene = context.scene
        props = scene.photo_match_props

        # Capture latest frame as reference
        if not _refresh_reference_from_live_feed(scene, props):
            self.report({'ERROR'}, "No phone frame available — wait for a "
                                   "frame to arrive before locking")
            return {'CANCELLED'}

        # Run a full V3 cold-start solve. Blocks UI but gives a definitive
        # answer. Budget comes from props so the advanced slider applies.
        try:
            score = _run_v3_search_full(
                scene, props,
                cold_start=True,
                max_evals=int(getattr(props, 'budget_full_solve',
                                      _DEFAULT_FULL_SOLVE_BUDGET)),
            )
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.report({'ERROR'}, f"Initial Lock search failed: {e}")
            return {'CANCELLED'}

        # Set up tracking
        start_tracking(scene, props, score)

        self.report({'INFO'},
                    f"Initial Lock acquired at {score:.1f}% — tracking started")
        return {'FINISHED'}


# ============================================================================
# Re-Lock operator
# ============================================================================

class PHOTOMATCH_OT_ReLock(Operator):
    """Recover a lost lock by re-running V3 against the current phone frame.

    Workflow per handoff §6.2:
      1. Capture current live frame
      2. Try a warm V3 search first (cheap, ~15 evals)
      3. If warm result < 60%, escalate to a full cold-start solve
      4. Drop the final score into the state machine via set_locked
    """
    bl_idname = "photomatch.relock"
    bl_label = "Re-Lock"
    bl_description = ("Reacquire the lock by re-running V3 against the current "
                      "phone frame. Tries a quick warm search first, falls back "
                      "to a full cold-start solve if the warm result is poor")
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        try:
            props = context.scene.photo_match_props
        except AttributeError:
            return False
        return (
            props.live_feed_running
            and props.live_feed_phone_connected
            and props.tracking_locked  # only meaningful when already tracking
        )

    def execute(self, context):
        scene = context.scene
        props = scene.photo_match_props

        if not _refresh_reference_from_live_feed(scene, props):
            self.report({'ERROR'}, "No phone frame available")
            return {'CANCELLED'}

        # Stage 1: warm solve
        try:
            warm_score = _run_v3_search_full(
                scene, props,
                cold_start=False,
                max_evals=int(getattr(props, 'budget_warm_solve',
                                      _DEFAULT_WARM_SOLVE_BUDGET)),
            )
        except Exception as e:
            self.report({'ERROR'}, f"Warm Re-Lock failed: {e}")
            return {'CANCELLED'}

        # Stage 2: escalate if warm result is poor
        if warm_score < _RELOCK_ESCALATION_SCORE:
            try:
                final_score = _run_v3_search_full(
                    scene, props,
                    cold_start=True,
                    max_evals=int(getattr(props, 'budget_full_solve',
                                          _DEFAULT_FULL_SOLVE_BUDGET)),
                )
            except Exception as e:
                # Warm score is still our best result if full solve crashed
                final_score = warm_score
                self.report({'WARNING'},
                            f"Full Re-Lock failed ({e}); using warm result")
            self.report({'INFO'},
                        f"Re-Lock: warm {warm_score:.1f}% → full {final_score:.1f}%")
        else:
            final_score = warm_score
            self.report({'INFO'},
                        f"Re-Lock: warm solve sufficient at {final_score:.1f}%")

        # Drop into SM
        relock_with_score(final_score)
        props.tracking_last_score = final_score
        props.tracking_state = tracking_state.LOCKED
        return {'FINISHED'}


# ============================================================================
# Stop Tracking operator
# ============================================================================

class PHOTOMATCH_OT_StopTracking(Operator):
    """Stop live tracking. Live feed continues running; only the matching
    state machine is torn down. The reference image stays in place so any
    static scoring against the last frame still works."""
    bl_idname = "photomatch.stop_tracking"
    bl_label = "Stop Tracking"
    bl_description = "Stop the live-tracking state machine. Live feed " \
                     "continues; reference image stays as the last phone frame"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        try:
            return context.scene.photo_match_props.tracking_locked
        except AttributeError:
            return False

    def execute(self, context):
        stop_tracking(context.scene, context.scene.photo_match_props)
        self.report({'INFO'}, "Tracking stopped — last frame remains as reference")
        return {'FINISHED'}


# ============================================================================
# Registration
# ============================================================================

classes = (
    PHOTOMATCH_OT_InitialLock,
    PHOTOMATCH_OT_ReLock,
    PHOTOMATCH_OT_StopTracking,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    # Make sure we don't outlive the addon — kill the timer before
    # operators get unregistered. Otherwise a tick fired during reload
    # would crash trying to find a no-longer-existing operator.
    stop_tracking(None, None)
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
