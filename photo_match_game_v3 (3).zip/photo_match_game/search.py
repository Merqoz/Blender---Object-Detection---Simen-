"""Search algorithms for the auto-solve feature.

The auto-solver is searching a 3-DOF parameter space:

    (direction_on_sphere, distance_along_ray)

with the camera always aimed at the target's center. Each evaluation requires
a full OpenGL render (~50–150ms), so the algorithm is designed to converge in
as few samples as possible.

The strategy is **coarse-to-fine with adaptive local refinement**:

  1. **Coarse** — Sample directions evenly on the sphere using a Fibonacci
     spiral (low-discrepancy: better coverage than uniform random for the
     same N). This finds the basin of attraction.

  2. **Refine** — Gaussian perturbations around the current best direction,
     with `sigma` shrinking each iteration. This is essentially simulated
     annealing without temperature acceptance — always move to the best so far.

  3. **Distance** — Try a handful of distance multipliers around the current
     best. Pure 1D search.

  4. **Final** — Smaller mixed perturbations of both direction and distance
     to polish the result.

Total budget is ~65 evaluations, which finishes in well under 30 seconds at
typical render speeds.
"""

import math
import random

from mathutils import Vector


# ----------------------------------------------------------------------------
# Sampling primitives
# ----------------------------------------------------------------------------

_GOLDEN_ANGLE = math.pi * (3.0 - math.sqrt(5.0))


def fibonacci_sphere(n, upper_hemisphere=False):
    """Return `n` points evenly distributed on the unit sphere.

    Uses the golden-angle Fibonacci spiral, which gives much better coverage
    than uniformly random sampling for small `n`. Z-up convention; with
    `upper_hemisphere=True` only positive-Z hemisphere is sampled.
    """
    points = []
    if n <= 0:
        return points
    for i in range(n):
        if upper_hemisphere:
            # z mapped from 0.05 (just above equator) to 1.0 (north pole)
            z = 0.05 + (i / max(1, n - 1)) * 0.95
        else:
            z = 1.0 - (i / max(1, n - 1)) * 2.0
        radius = math.sqrt(max(0.0, 1.0 - z * z))
        theta = _GOLDEN_ANGLE * i
        x = math.cos(theta) * radius
        y = math.sin(theta) * radius
        points.append(Vector((x, y, z)))
    return points


def perturb_direction(direction, sigma, count, upper_hemisphere=False):
    """Generate `count` direction unit vectors near `direction`.

    Adds isotropic 3D Gaussian noise with stddev `sigma`, then renormalizes
    onto the sphere. Effective angular spread is roughly `sigma` radians for
    small sigma. With `upper_hemisphere=True`, results are clamped above the
    equator.
    """
    results = []
    direction = Vector(direction).normalized()
    for _ in range(count):
        offset = Vector((
            random.gauss(0, sigma),
            random.gauss(0, sigma),
            random.gauss(0, sigma),
        ))
        new_dir = direction + offset
        if new_dir.length < 1e-3:
            new_dir = direction.copy()
        new_dir.normalize()
        if upper_hemisphere and new_dir.z < 0.05:
            new_dir.z = 0.05
            new_dir.normalize()
        results.append(new_dir)
    return results


# ----------------------------------------------------------------------------
# Search state machine
# ----------------------------------------------------------------------------

class AutoSolveState:
    """Multi-phase camera search.

    Usage:
        state = AutoSolveState(target_center, dir, dist, upper_hemisphere=True)
        while True:
            cand = state.next_candidate()
            if cand is None:
                break
            phase, direction, distance = cand
            # ... position camera, render, score ...
            state.report_score(direction, distance, score)
        # state.best_direction / best_distance hold the answer

    Each call to `next_candidate()` returns the next thing to try. Subsequent
    candidates are generated lazily based on whatever the best score is at
    that moment, so the refinement phases adapt to the coarse-phase winner.
    """

    # Tuned for ~65 total evaluations — about 7-15 seconds of search at typical
    # render rates. Fewer is faster but less reliable; more diminishes returns.
    COARSE_SAMPLES = 18
    REFINE_ITERATIONS = 6
    REFINE_SAMPLES_PER_ITER = 4
    DISTANCE_FACTORS = (0.6, 0.8, 1.2, 1.5, 2.0)
    FINAL_ITERATIONS = 3
    FINAL_DIR_SAMPLES_PER_ITER = 4
    FINAL_DIST_SAMPLES_PER_ITER = 2

    EARLY_STOP_SCORE = 97.0  # if we hit this, we're done

    def __init__(self, target_center, start_direction, start_distance,
                 upper_hemisphere=True):
        self.target_center = Vector(target_center)
        self.upper_hemisphere = upper_hemisphere
        self.best_direction = Vector(start_direction).normalized()
        self.best_distance = float(start_distance)
        self.best_score = -1.0
        self.evaluations_done = 0
        self._plan = self._build_plan()

    @property
    def total_evaluations_planned(self):
        """Approximate count for progress display."""
        refine = self.REFINE_ITERATIONS * self.REFINE_SAMPLES_PER_ITER
        final = self.FINAL_ITERATIONS * (
            self.FINAL_DIR_SAMPLES_PER_ITER + self.FINAL_DIST_SAMPLES_PER_ITER
        )
        return self.COARSE_SAMPLES + refine + len(self.DISTANCE_FACTORS) + final

    def _build_plan(self):
        """Generator yielding (phase, direction, distance) tuples.

        Refinement phases use `self.best_direction` / `self.best_distance`
        *at the moment of yield*, which is updated by `report_score()` between
        yields. This is what makes the search adaptive.
        """
        # Phase 1: Coarse global sampling
        for direction in fibonacci_sphere(self.COARSE_SAMPLES, self.upper_hemisphere):
            yield 'coarse', direction, self.best_distance

        # Phase 2: Local refinement of direction
        for it in range(self.REFINE_ITERATIONS):
            sigma = 0.6 * (0.65 ** it)  # 0.60 → 0.05 over 6 iterations
            for direction in perturb_direction(
                self.best_direction, sigma,
                self.REFINE_SAMPLES_PER_ITER, self.upper_hemisphere,
            ):
                yield 'refine', direction, self.best_distance

        # Phase 3: Distance sweep at best direction
        for factor in self.DISTANCE_FACTORS:
            yield 'distance', self.best_direction, self.best_distance * factor

        # Phase 4: Mixed final tune
        for it in range(self.FINAL_ITERATIONS):
            sigma = 0.2 * (0.7 ** it)
            jitter = 0.12 * (0.7 ** it)
            for direction in perturb_direction(
                self.best_direction, sigma,
                self.FINAL_DIR_SAMPLES_PER_ITER, self.upper_hemisphere,
            ):
                yield 'final', direction, self.best_distance
            for factor in (1.0 - jitter, 1.0 + jitter):
                yield 'final', self.best_direction, self.best_distance * factor

    def next_candidate(self):
        """Return the next (phase, direction, distance), or None if done."""
        if self.best_score >= self.EARLY_STOP_SCORE:
            return None
        try:
            return next(self._plan)
        except StopIteration:
            return None

    def report_score(self, direction, distance, score):
        """Update the running best from a freshly-evaluated candidate."""
        self.evaluations_done += 1
        if score > self.best_score:
            self.best_score = score
            self.best_direction = Vector(direction)
            self.best_distance = float(distance)
