"""Bounding-volume math.

The reference camera is placed at `bounding_sphere_radius + offset` distance
from the target's center. Using a bounding sphere (not just a bbox) means the
distance is rotation-invariant — wherever we put the camera, it never ends up
inside the object.
"""

from mathutils import Vector


def get_world_bbox_corners(obj):
    """Return the 8 world-space corners of an object's local bounding box."""
    return [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]


def axis_aligned_bbox(corners):
    """Min and max corners of the axis-aligned bbox enclosing all input points."""
    if not corners:
        zero = Vector((0, 0, 0))
        return zero, zero
    xs = [c.x for c in corners]
    ys = [c.y for c in corners]
    zs = [c.z for c in corners]
    return (
        Vector((min(xs), min(ys), min(zs))),
        Vector((max(xs), max(ys), max(zs))),
    )


def bounding_sphere(corners):
    """Return (center, radius) of a bounding sphere through `corners`.

    Cheap implementation: center the sphere at the AABB midpoint and stretch
    the radius to reach the farthest corner. Not minimal, but always valid and
    plenty good enough for camera placement.
    """
    if not corners:
        return Vector((0, 0, 0)), 1.0

    aabb_min, aabb_max = axis_aligned_bbox(corners)
    center = (aabb_min + aabb_max) * 0.5
    radius = max((c - center).length for c in corners)
    # Avoid degenerate zero-radius spheres for things like single-vertex meshes
    return center, max(radius, 0.001)


def target_center_and_radius(obj):
    """Get a sensible (center, radius) pair for any object the user might pick."""
    if obj.type == 'EMPTY':
        # Empties have no bounding box — use display size as the radius
        return obj.matrix_world.translation.copy(), max(obj.empty_display_size, 0.5)
    corners = get_world_bbox_corners(obj)
    return bounding_sphere(corners)
