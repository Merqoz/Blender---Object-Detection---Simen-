"""Score-adaptive state machine for live-feed tracking.

This module is intentionally Blender-free. The state machine itself is a pure
Python object: callers wire up the per-regime worker callables (which DO touch
Blender — render, score, run V3, fine-tune) and pump `tick()` from a Blender
timer. Keeping the state logic isolated lets us unit-test transitions and
hysteresis with synthetic score sequences instead of needing a real scene.

The big idea: once we've locked onto a pose, a 1-second tick will rarely see
a 180° pose flip but will routinely see small angular drift. The search
radius and evaluation budget should scale to that prior. Three regimes:

    LOST     — no idea where we are; run a full V3 cold-start solve
    TRACKING — we have a recent pose but quality is mediocre; warm V3 solve
               with narrow radius
    LOCKED   — pose is solid; one Hooke-Jeeves polish step per tick

Hysteresis prevents thrash. The dual-threshold pairs (40/55 between
LOST↔TRACKING, 80/92 between TRACKING↔LOCKED) create stable bands where the
current regime persists across small score wobbles. Without them, a score
hovering at 53 would oscillate Lost↔Tracking and restart full solves
constantly.

Auto-recover is OFF by default: dropping below 40 from TRACKING does NOT
auto-fall to LOST. The user has to press Re-Lock explicitly. This is a
defensive choice — full solves take ~3 seconds and we don't want them
firing on a temporarily occluded frame. Users who like aggressive recovery
can flip the checkbox.

Multi-tick full solves: the LOST→full-solve executor can return a generator
that yields `None` while still working, finally yielding a float score. The
state machine pumps the generator one step per tick, so the UI stays
responsive during the ~60-eval cold-start search.
"""

from dataclasses import dataclass, field, replace
import types
from typing import Callable, Optional, Union


# ----------------------------------------------------------------------------
# Regime constants
# ----------------------------------------------------------------------------
#
# Strings rather than IntEnum so they round-trip cleanly through Blender's
# EnumProperty (which uses string identifiers). Display labels are rendered in
# ui.py; this module only deals with the identifier values.

LOST = 'LOST'
TRACKING = 'TRACKING'
LOCKED = 'LOCKED'

ALL_REGIMES = (LOST, TRACKING, LOCKED)


# ----------------------------------------------------------------------------
# Configuration dataclasses
# ----------------------------------------------------------------------------

@dataclass(frozen=True)
class Thresholds:
    """Hysteresis transition thresholds.

    Naming: each field name is "current_to_target" — i.e. "score level at which
    the machine transitions FROM <current> TO <target>". Defaults match the
    handoff spec (40/55/80/92).

    Sane invariants (not enforced — Blender properties give the user free rein,
    but values outside these will produce undefined behavior):
      - tracking_to_lost < lost_to_tracking         (40 < 55)
      - locked_to_tracking < tracking_to_locked     (80 < 92)
      - lost_to_tracking < locked_to_tracking       (55 < 80) [keeps the LOST
        zone strictly below the TRACKING zone, which is otherwise weird]
    """
    tracking_to_lost: float = 40.0
    lost_to_tracking: float = 55.0
    locked_to_tracking: float = 80.0
    tracking_to_locked: float = 92.0


# Type alias for the executor return shape: either a float score (single-tick
# completion) OR a generator yielding None for "in progress" and finally
# yielding a float for the completed score.
ExecutorResult = Union[float, types.GeneratorType]


@dataclass(frozen=True)
class Executors:
    """Per-regime worker callables, injected by the caller.

    Each is a zero-arg callable. The caller wires them up as closures over the
    Blender scene / properties / cached features, so the state machine itself
    stays Blender-agnostic.

    Returns of each callable:
      - `float` in [0, 100]: completed in this tick. The state machine treats
        the value as the new "last accepted score" and runs the regime
        transition rules against it.
      - `generator yielding None ... eventually yielding float`: multi-tick
        work. The state machine advances the generator one step per tick.
        Each yielded `None` means "still working, don't transition yet".
        The yielded float (or value via StopIteration) is the final score.
        ALWAYS yield exactly one float at the end — don't yield multiple.

    Important contract for executors:
      - Only return / yield the FINAL accepted score. Probe scores from
        Hooke-Jeeves or anything else internal to the executor must NOT be
        emitted; the state machine treats every emitted float as a
        regime-decision input, and emitting probe scores would produce wild
        oscillation.
      - If the executor needs to bail out early (e.g. reference image vanished),
        return the previous score unchanged or 0.0. Don't raise — exceptions
        will propagate out of tick() and need a try/except in the timer.
    """
    full_solve: Callable[[], ExecutorResult]
    warm_solve: Callable[[], ExecutorResult]
    locked_polish: Callable[[], ExecutorResult]


@dataclass
class TickResult:
    """What `tick()` returns. Useful for the UI poll: regime + score for
    display, busy flag for "show a spinner instead of a number"."""
    regime: str
    score: float
    busy: bool  # True if a multi-tick generator is still in flight
    transitioned: bool  # True if regime changed during this tick


# ----------------------------------------------------------------------------
# State machine
# ----------------------------------------------------------------------------

class TrackingStateMachine:
    """Score-adaptive tracking state machine.

    Lifecycle:
      1. Construct with executors. Initial state is LOST.
      2. Caller's "Initial Lock" operator runs a full solve OUTSIDE this
         machine, then calls `set_locked(final_score)` on success — that puts
         us straight into LOCKED skipping the gradual climb.
      3. Caller's 1 Hz timer calls `tick()`. The machine dispatches to the
         appropriate executor and updates its regime based on the result.
      4. If user presses Re-Lock, caller invokes `force_lost()`.

    Thread-safety: not. Run from the Blender main thread only.
    """

    def __init__(
        self,
        executors: Executors,
        *,
        thresholds: Thresholds = None,
        auto_recover: bool = False,
    ):
        self._executors = executors
        self._thresholds = thresholds if thresholds is not None else Thresholds()
        self._auto_recover = bool(auto_recover)

        # State
        self._regime = LOST
        self._last_accepted_score = 0.0
        # In-flight multi-tick generator from a previous tick(). When set, the
        # next tick() advances it instead of starting a new executor run.
        self._pending: Optional[types.GeneratorType] = None
        # The regime that was active when the pending generator was started.
        # If the user manually transitions while a generator is pumping, we
        # discard it (force_lost handles this); otherwise we trust it through
        # to completion.
        self._pending_regime: Optional[str] = None

    # --- Read-only state ---------------------------------------------------

    @property
    def regime(self) -> str:
        return self._regime

    @property
    def last_accepted_score(self) -> float:
        return self._last_accepted_score

    @property
    def is_busy(self) -> bool:
        """True if a multi-tick generator is still in flight."""
        return self._pending is not None

    @property
    def thresholds(self) -> Thresholds:
        return self._thresholds

    @property
    def auto_recover(self) -> bool:
        return self._auto_recover

    # --- Configuration setters --------------------------------------------

    def set_auto_recover(self, value: bool) -> None:
        self._auto_recover = bool(value)

    def set_thresholds(self, **fields) -> None:
        """Replace one or more threshold fields. Other fields keep their
        current values. Useful for the advanced-settings sliders that bind
        directly to threshold fields."""
        self._thresholds = replace(self._thresholds, **fields)

    # --- External transition triggers -------------------------------------

    def force_lost(self) -> None:
        """Manual Re-Lock: reset to LOST regardless of current state, abandon
        any in-flight generator. Last-accepted score is reset to 0 so any
        UI showing it doesn't flash a stale high value during recovery."""
        self._regime = LOST
        self._last_accepted_score = 0.0
        self._pending = None
        self._pending_regime = None

    def set_locked(self, score: float) -> None:
        """Manually push the machine into LOCKED with a given score.

        Used by the Initial Lock operator: it runs a full V3 solve OUTSIDE the
        state machine (since the user-initiated lock has its own modal UI),
        and on success calls this method to drop the result into the machine.

        Skips the gradual LOST→TRACKING→LOCKED climb. Caller is responsible
        for verifying the score actually justifies LOCKED — if you pass in a
        score below `locked_to_tracking`, the next tick will immediately
        bounce us back to TRACKING via the LOCKED→TRACKING rule.
        """
        self._regime = LOCKED
        self._last_accepted_score = float(score)
        # Cancel anything in flight — the manual lock supersedes whatever
        # the previous regime was working on.
        self._pending = None
        self._pending_regime = None

    # --- Per-tick driver --------------------------------------------------

    def tick(self) -> TickResult:
        """Run one tick of work and return the resulting state.

        Behavior:
          - If a multi-tick generator from a previous tick is in flight,
            advance it. If it produces a final score, accept it and
            re-evaluate regime. If it yields None, return busy=True.
          - Otherwise dispatch to the current regime's executor. Same
            float-or-generator handling.
          - At most one regime transition per tick. If we move from e.g.
            LOST→TRACKING this tick, the TRACKING executor doesn't run until
            NEXT tick. Keeps timing predictable and prevents transitions
            from chaining inside a single timer callback.
        """
        prev_regime = self._regime

        if self._pending is not None:
            score = self._advance_pending()
            if score is None:
                # Generator still working
                return TickResult(self._regime, self._last_accepted_score,
                                  busy=True, transitioned=False)
            # Generator finished this tick — fall through to handle the score
        else:
            executor = self._executor_for_current_regime()
            result = executor()
            if isinstance(result, types.GeneratorType):
                # Multi-tick path: stash and pump once now, in case the
                # generator finishes immediately on first next().
                self._pending = result
                self._pending_regime = self._regime
                score = self._advance_pending()
                if score is None:
                    return TickResult(self._regime, self._last_accepted_score,
                                      busy=True, transitioned=False)
            else:
                score = float(result)

        # Single-tick path — apply transition rules to the new score
        self._last_accepted_score = float(score)
        self._regime = self._decide_next_regime(self._regime, score)
        return TickResult(
            self._regime,
            self._last_accepted_score,
            busy=False,
            transitioned=(self._regime != prev_regime),
        )

    # --- Internals --------------------------------------------------------

    def _executor_for_current_regime(self) -> Callable[[], ExecutorResult]:
        if self._regime == LOST:
            return self._executors.full_solve
        if self._regime == TRACKING:
            return self._executors.warm_solve
        if self._regime == LOCKED:
            return self._executors.locked_polish
        # Should be unreachable given ALL_REGIMES is closed
        raise ValueError(f"Unknown regime: {self._regime!r}")

    def _advance_pending(self) -> Optional[float]:
        """Pump the in-flight generator one step.

        Returns:
            float — the generator yielded a final score; clear pending state
            None  — generator yielded None (still working)
        """
        gen = self._pending
        try:
            value = next(gen)
        except StopIteration as stop:
            # Generator returned. Python 3 carries the return value on
            # StopIteration.value; handle both "generator returned a float"
            # and "generator simply exhausted" gracefully.
            self._pending = None
            self._pending_regime = None
            ret = stop.value
            if isinstance(ret, (int, float)):
                return float(ret)
            # Exhausted with no value — treat as "no new score this tick";
            # caller stays in current regime, pending cleared. Score
            # unchanged.
            return self._last_accepted_score
        if value is None:
            return None
        # Treat any yielded numeric value as the final score and end pumping
        # here. (Executors are contracted to yield None for in-progress and
        # one float for done, but be lenient if they emit the float.)
        if isinstance(value, (int, float)):
            self._pending = None
            self._pending_regime = None
            return float(value)
        # Unexpected yield type — be defensive: stop pumping, treat as no-op
        self._pending = None
        self._pending_regime = None
        return self._last_accepted_score

    def _decide_next_regime(self, current: str, score: float) -> str:
        """Apply hysteresis transition rules. Pure function; no side effects.

        At most one regime step per call. The diagram only allows adjacent
        transitions: LOST↔TRACKING and TRACKING↔LOCKED. There's no direct
        LOCKED→LOST step (a LOCKED with score 20 first becomes TRACKING this
        tick; next tick TRACKING evaluates whether to go to LOST).
        """
        t = self._thresholds
        if current == LOST:
            if score >= t.lost_to_tracking:
                return TRACKING
            return LOST
        if current == TRACKING:
            if score >= t.tracking_to_locked:
                return LOCKED
            if score < t.tracking_to_lost and self._auto_recover:
                return LOST
            return TRACKING
        if current == LOCKED:
            if score < t.locked_to_tracking:
                return TRACKING
            return LOCKED
        raise ValueError(f"Unknown regime: {current!r}")
