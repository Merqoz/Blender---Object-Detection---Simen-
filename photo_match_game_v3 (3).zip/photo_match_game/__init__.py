"""Photo Match Game — turn scene composition into a memory game.

A challenge camera is placed at a random angle around a chosen object, its view
is captured as a screenshot, and the player tries to align their own camera to
match it. Pixel similarity + camera pose similarity are both scored.
"""

bl_info = {
    "name": "Photo Match Game",
    "author": "Claude",
    "version": (3, 0, 0),
    "blender": (3, 2, 0),
    "location": "View3D > Sidebar (N) > Photo Match",
    "description": "Generate a randomized camera challenge or load a reference image, then align your camera to match. Features 10-camera multi-algorithm search (Fibonacci, Gaussian, PID gradient, pattern search, spiral, simulated annealing, Lévy walk, grid sweep, golden section, differential evolution) with hotspot convergence, enhanced multi-metric scoring (pixel, structural, histogram, edge alignment, SSIM), live pose scoring, contour matching, 6-DOF object search, fine-tune polishing, phone camera live feed with tracking.",
    "category": "3D View",
}

# Reload-safe submodule imports — Blender often reloads add-ons during dev,
# and a plain `from . import x` won't pick up edits without this dance.
if "bpy" in locals():
    import importlib
    for _name in (
        "geometry", "camera_utils", "rendering", "scoring", "image_features",
        "cv_scoring", "search", "search_v2", "search_v3",
        "search_cv", "search_freeform", "multi_camera_search",
        "object_search", "object_tracker",
        "camera_intrinsics", "tracking_state",
        "properties", "live_scoring", "fine_tune", "live_feed",
        "live_tracking",
        "operators", "ui",
    ):
        if _name in locals():
            importlib.reload(locals()[_name])

import bpy

from . import camera_intrinsics
from . import properties
from . import operators
from . import ui
from . import live_scoring
from . import fine_tune
from . import live_feed
from . import live_tracking


# Order matters: camera_intrinsics registers PhotoMatchCameraIntrinsics, which
# properties.py references in a PointerProperty — so it must register first.
# properties must register before operators/ui that reference
# scene.photo_match_props. live_scoring and live_feed are timer-based and
# need properties registered. live_tracking needs live_feed (frame slot
# import) and properties (PropertyGroup access) so it goes last.
_modules = (camera_intrinsics, properties, operators, fine_tune, ui,
            live_scoring, live_feed, live_tracking)


def register():
    for module in _modules:
        try:
            module.register()
        except RuntimeError as e:
            if "already registered" in str(e).lower():
                # Addon re-installed without restart — skip already-registered
                print(f"Photo Match: skipping already registered: {e}")
            else:
                raise


def unregister():
    # Clean up the object tracker's depsgraph handler
    try:
        from . import object_tracker
        object_tracker.reset_tracker()
    except Exception:
        pass
    for module in reversed(_modules):
        try:
            module.unregister()
        except Exception as e:
            print(f"Photo Match: unregister warning: {e}")


if __name__ == "__main__":
    register()
