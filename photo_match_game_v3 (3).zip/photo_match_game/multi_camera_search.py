"""Multi-camera search — 10 independent cameras with different algorithms.

Each camera explores the search space using a distinct technique. When any
camera finds a score above the HOTSPOT_THRESHOLD (80%), it broadcasts its
position and ALL other cameras teleport there to refine using their own method.

The 10 search techniques:

  Cam 0 — Fibonacci Sphere         Even sphere coverage (from v1)
  Cam 1 — Warm-start Gaussian      Tight samples near starting pose (from v2)
  Cam 2 — PID Gradient Descent     Finite-diff gradient + PID (from v2)
  Cam 3 — Hooke-Jeeves Pattern     Axis-aligned pattern search (from v2)
  Cam 4 — Contour Chamfer Spiral   Archimedes spiral with contour scoring
  Cam 5 — Simulated Annealing      Accept worse moves with cooling schedule
  Cam 6 — Random Walk Explorer     Lévy-flight random walk for coverage
  Cam 7 — Grid Sweep               Systematic theta/phi grid
  Cam 8 — Golden Section 1D        Sequential 1D golden-section on each axis
  Cam 9 — Differential Evolution   Mini population-based optimizer

Scoring: each camera uses whatever scorer the operator provides (pixel or
contour). The multi-camera coordinator manages the round-robin, hotspot
broadcast, and final result selection.

Usage (from the operator):
    mc = MultiCameraSearch(target_center, start_dir, start_dist, upper_hemi)
    while True:
        cand = mc.next_candidate()
        if cand is None:
            break
        cam_id, phase, direction, distance = cand
        # ... position camera, render, score ...
        mc.report_score(cam_id, direction, distance, score)
    # mc.best_direction / mc.best_distance / mc.best_score
"""

import math
import random

from mathutils import Vector

from .search_v2 import (
    direction_to_spherical, spherical_to_direction,
    clamp_theta, wrap_phi, fibonacci_sphere,
    PIDController3D,
)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

HOTSPOT_THRESHOLD = 80.0   # score that triggers all-camera convergence
EARLY_STOP_SCORE = 96.0    # global early-stop
NUM_CAMERAS = 10
GOLDEN_RATIO = (1.0 + math.sqrt(5.0)) / 2.0
_GOLDEN_ANGLE = math.pi * (3.0 - math.sqrt(5.0))


# ---------------------------------------------------------------------------
# Individual camera search strategies
# ---------------------------------------------------------------------------

class _CameraBase:
    """Base class for a single camera's search strategy."""

    def __init__(self, cam_id, theta, phi, distance, upper_hemisphere):
        self.cam_id = cam_id
        self.theta = theta
        self.phi = phi
        self.distance = distance
        self.upper_hemisphere = upper_hemisphere
        self.best_theta = theta
        self.best_phi = phi
        self.best_distance = distance
        self.best_score = -1.0
        self.evals = 0
        self._converged_to_hotspot = False

    def teleport_to(self, theta, phi, distance):
        """Hotspot convergence — jump to a promising location."""
        self.theta = theta
        self.phi = phi
        self.distance = distance
        self._converged_to_hotspot = True
        # Rebuild plan from new position
        self._plan = self._build_refine_plan()

    def report_score(self, direction, distance, score):
        self.evals += 1
        if score > self.best_score:
            self.best_score = score
            t, p = direction_to_spherical(direction)
            self.best_theta = clamp_theta(t, self.upper_hemisphere)
            self.best_phi = wrap_phi(p)
            self.best_distance = float(distance)

    def _build_refine_plan(self):
        """Override: build a refinement plan from current best position."""
        return iter([])

    def _clamp(self, theta):
        return clamp_theta(theta, self.upper_hemisphere)


class FibonacciCamera(_CameraBase):
    """Cam 0: Even Fibonacci sphere sampling then local refine."""

    COARSE = 20
    REFINE = 15

    def build_plan(self):
        # Coarse sweep
        for d in fibonacci_sphere(self.COARSE, self.upper_hemisphere):
            yield d, self.distance
        # Refine around best
        for i in range(self.REFINE):
            sigma = 0.5 * (0.7 ** i)
            t = self._clamp(self.best_theta + random.gauss(0, sigma))
            p = wrap_phi(self.best_phi + random.gauss(0, sigma))
            yield spherical_to_direction(t, p), self.best_distance

    def _build_refine_plan(self):
        for i in range(12):
            sigma = 0.3 * (0.7 ** i)
            t = self._clamp(self.best_theta + random.gauss(0, sigma))
            p = wrap_phi(self.best_phi + random.gauss(0, sigma))
            yield spherical_to_direction(t, p), self.best_distance


class WarmGaussianCamera(_CameraBase):
    """Cam 1: Tight Gaussian shell around starting pose."""

    SAMPLES = 30

    def build_plan(self):
        for i in range(self.SAMPLES):
            sigma = 0.4 * (0.85 ** i)
            dist_jitter = 1.0 + random.gauss(0, 0.15)
            t = self._clamp(self.theta + random.gauss(0, sigma))
            p = wrap_phi(self.phi + random.gauss(0, sigma))
            yield spherical_to_direction(t, p), self.distance * max(0.3, dist_jitter)

    def _build_refine_plan(self):
        for i in range(12):
            sigma = 0.2 * (0.75 ** i)
            t = self._clamp(self.best_theta + random.gauss(0, sigma))
            p = wrap_phi(self.best_phi + random.gauss(0, sigma))
            d_j = 1.0 + random.gauss(0, 0.08)
            yield spherical_to_direction(t, p), self.best_distance * max(0.5, d_j)


class PIDGradientCamera(_CameraBase):
    """Cam 2: PID-controlled gradient descent via finite differences."""

    STEPS = 10
    FD_EPS = 0.10
    GAIN = 0.07

    def build_plan(self):
        pid = PIDController3D(kp=0.6, ki=0.05, kd=0.25)
        # Start with a few random samples to seed the best
        for _ in range(4):
            t = self._clamp(self.theta + random.gauss(0, 0.4))
            p = wrap_phi(self.phi + random.gauss(0, 0.4))
            yield spherical_to_direction(t, p), self.distance
        # Gradient steps
        for step in range(self.STEPS):
            bt, bp, bd = self.best_theta, self.best_phi, self.best_distance
            # We yield 6 probes + 1 step per iteration, but the coordinator
            # expects simple (direction, distance) pairs. The gradient is
            # estimated externally by the coordinator watching score changes.
            # Here we just yield perturbations along each axis.
            eps = self.FD_EPS * (0.9 ** step)
            # +/- theta
            yield spherical_to_direction(self._clamp(bt + eps), bp), bd
            yield spherical_to_direction(self._clamp(bt - eps), bp), bd
            # +/- phi
            yield spherical_to_direction(bt, wrap_phi(bp + eps)), bd
            yield spherical_to_direction(bt, wrap_phi(bp - eps)), bd

    def _build_refine_plan(self):
        for step in range(8):
            eps = 0.06 * (0.85 ** step)
            bt, bp, bd = self.best_theta, self.best_phi, self.best_distance
            yield spherical_to_direction(self._clamp(bt + eps), bp), bd
            yield spherical_to_direction(self._clamp(bt - eps), bp), bd
            yield spherical_to_direction(bt, wrap_phi(bp + eps)), bd
            yield spherical_to_direction(bt, wrap_phi(bp - eps)), bd


class PatternSearchCamera(_CameraBase):
    """Cam 3: Hooke-Jeeves pattern search."""

    MAX_STEPS = 30

    def build_plan(self):
        step = 0.15
        for _ in range(self.MAX_STEPS):
            axis = random.choice(('theta', 'phi', 'dist'))
            sign = random.choice((1, -1))
            bt, bp, bd = self.best_theta, self.best_phi, self.best_distance
            if axis == 'theta':
                yield spherical_to_direction(self._clamp(bt + sign * step), bp), bd
            elif axis == 'phi':
                yield spherical_to_direction(bt, wrap_phi(bp + sign * step)), bd
            else:
                yield spherical_to_direction(bt, bp), max(0.1, bd * (1 + sign * step))
            # Adaptive: we can't check improvement here, but the coordinator
            # tracks best_score. We shrink step gradually.
            step *= 0.95

    def _build_refine_plan(self):
        step = 0.05
        for _ in range(15):
            axis = random.choice(('theta', 'phi', 'dist'))
            sign = random.choice((1, -1))
            bt, bp, bd = self.best_theta, self.best_phi, self.best_distance
            if axis == 'theta':
                yield spherical_to_direction(self._clamp(bt + sign * step), bp), bd
            elif axis == 'phi':
                yield spherical_to_direction(bt, wrap_phi(bp + sign * step)), bd
            else:
                yield spherical_to_direction(bt, bp), max(0.1, bd * (1 + sign * step))
            step *= 0.92


class SpiralCamera(_CameraBase):
    """Cam 4: Archimedes spiral from top of sphere downward."""

    TURNS = 6
    SAMPLES_PER_TURN = 8

    def build_plan(self):
        total = self.TURNS * self.SAMPLES_PER_TURN
        for i in range(total):
            frac = i / max(1, total - 1)
            if self.upper_hemisphere:
                theta = 0.05 + frac * (math.pi / 2 - 0.1)
            else:
                theta = 0.05 + frac * (math.pi - 0.1)
            phi = frac * self.TURNS * 2 * math.pi
            yield spherical_to_direction(theta, phi), self.distance
        # Refine around best
        for i in range(8):
            sigma = 0.2 * (0.7 ** i)
            t = self._clamp(self.best_theta + random.gauss(0, sigma))
            p = wrap_phi(self.best_phi + random.gauss(0, sigma))
            yield spherical_to_direction(t, p), self.best_distance

    def _build_refine_plan(self):
        for i in range(10):
            sigma = 0.15 * (0.7 ** i)
            t = self._clamp(self.best_theta + random.gauss(0, sigma))
            p = wrap_phi(self.best_phi + random.gauss(0, sigma))
            yield spherical_to_direction(t, p), self.best_distance


class SimulatedAnnealingCamera(_CameraBase):
    """Cam 5: Simulated annealing with exponential cooling."""

    MAX_ITERS = 35
    T_START = 1.0
    T_END = 0.01

    def build_plan(self):
        cur_theta, cur_phi, cur_dist = self.theta, self.phi, self.distance
        cur_score = -1.0
        for i in range(self.MAX_ITERS):
            frac = i / max(1, self.MAX_ITERS - 1)
            temp = self.T_START * (self.T_END / self.T_START) ** frac
            sigma = 0.5 * temp + 0.02
            t = self._clamp(cur_theta + random.gauss(0, sigma))
            p = wrap_phi(cur_phi + random.gauss(0, sigma))
            d = max(0.1, cur_dist * (1 + random.gauss(0, 0.1 * temp)))
            yield spherical_to_direction(t, p), d
            # SA acceptance: update cur if best improved (simplified — the
            # real acceptance is done via report_score checking best)
            if self.best_score > cur_score:
                cur_theta = self.best_theta
                cur_phi = self.best_phi
                cur_dist = self.best_distance
                cur_score = self.best_score
            elif random.random() < math.exp(-2.0 / max(temp, 0.001)):
                # Accept a random move with SA probability
                cur_theta, cur_phi, cur_dist = t, p, d

    def _build_refine_plan(self):
        for i in range(12):
            sigma = 0.1 * (0.8 ** i)
            t = self._clamp(self.best_theta + random.gauss(0, sigma))
            p = wrap_phi(self.best_phi + random.gauss(0, sigma))
            yield spherical_to_direction(t, p), self.best_distance


class LevyWalkCamera(_CameraBase):
    """Cam 6: Lévy-flight random walk for long-range exploration."""

    MAX_STEPS = 30

    def _levy_step(self):
        """Lévy-distributed step size (power-law tail for long jumps)."""
        u = random.gauss(0, 1)
        v = abs(random.gauss(0, 1))
        return u / (v ** (1.0 / 3.0))  # Cauchy-ish tail

    def build_plan(self):
        cur_t, cur_p = self.theta, self.phi
        for _ in range(self.MAX_STEPS):
            step = self._levy_step() * 0.15
            cur_t = self._clamp(cur_t + step)
            cur_p = wrap_phi(cur_p + self._levy_step() * 0.15)
            yield spherical_to_direction(cur_t, cur_p), self.distance
            # Occasionally jump back to best
            if random.random() < 0.2:
                cur_t, cur_p = self.best_theta, self.best_phi

    def _build_refine_plan(self):
        for i in range(10):
            step = self._levy_step() * 0.05 * (0.8 ** i)
            t = self._clamp(self.best_theta + step)
            p = wrap_phi(self.best_phi + self._levy_step() * 0.05)
            yield spherical_to_direction(t, p), self.best_distance


class GridSweepCamera(_CameraBase):
    """Cam 7: Systematic grid over theta/phi."""

    THETA_STEPS = 6
    PHI_STEPS = 8

    def build_plan(self):
        if self.upper_hemisphere:
            theta_range = (0.1, math.pi / 2 - 0.05)
        else:
            theta_range = (0.1, math.pi - 0.1)
        for ti in range(self.THETA_STEPS):
            theta = theta_range[0] + (theta_range[1] - theta_range[0]) * ti / max(1, self.THETA_STEPS - 1)
            for pi_ in range(self.PHI_STEPS):
                phi = -math.pi + 2 * math.pi * pi_ / self.PHI_STEPS
                yield spherical_to_direction(theta, phi), self.distance

    def _build_refine_plan(self):
        for i in range(10):
            sigma = 0.15 * (0.75 ** i)
            t = self._clamp(self.best_theta + random.gauss(0, sigma))
            p = wrap_phi(self.best_phi + random.gauss(0, sigma))
            yield spherical_to_direction(t, p), self.best_distance


class GoldenSectionCamera(_CameraBase):
    """Cam 8: Golden-section 1D search on each axis sequentially."""

    ITERS_PER_AXIS = 8

    def _gs_1d(self, lo, hi, n):
        """Golden-section search bracket shrinking."""
        gr = (math.sqrt(5) - 1) / 2
        for _ in range(n):
            c = hi - gr * (hi - lo)
            d = lo + gr * (hi - lo)
            yield c, d
            # We yield both probe points; the coordinator picks the better
            # After reporting, we shrink the bracket toward best_theta/phi
            mid = (lo + hi) / 2
            if abs(c - mid) < abs(d - mid):
                hi = d
            else:
                lo = c

    def build_plan(self):
        # Theta axis
        if self.upper_hemisphere:
            t_lo, t_hi = 0.05, math.pi / 2 - 0.05
        else:
            t_lo, t_hi = 0.05, math.pi - 0.05
        for c, d in self._gs_1d(t_lo, t_hi, self.ITERS_PER_AXIS):
            yield spherical_to_direction(c, self.phi), self.distance
            yield spherical_to_direction(d, self.phi), self.distance

        # Phi axis
        for c, d in self._gs_1d(-math.pi, math.pi, self.ITERS_PER_AXIS):
            yield spherical_to_direction(self.best_theta, c), self.distance
            yield spherical_to_direction(self.best_theta, d), self.distance

        # Distance axis
        for c, d in self._gs_1d(0.3, self.distance * 2.5, self.ITERS_PER_AXIS):
            yield spherical_to_direction(self.best_theta, self.best_phi), c
            yield spherical_to_direction(self.best_theta, self.best_phi), d

    def _build_refine_plan(self):
        for i in range(10):
            sigma = 0.1 * (0.8 ** i)
            t = self._clamp(self.best_theta + random.gauss(0, sigma))
            p = wrap_phi(self.best_phi + random.gauss(0, sigma))
            yield spherical_to_direction(t, p), self.best_distance


class DifferentialEvolutionCamera(_CameraBase):
    """Cam 9: Mini differential evolution with a small population."""

    POP_SIZE = 6
    GENERATIONS = 6
    F = 0.7   # mutation factor
    CR = 0.8  # crossover rate

    def build_plan(self):
        # Initialize population as (theta, phi, dist)
        pop = []
        for _ in range(self.POP_SIZE):
            if self.upper_hemisphere:
                t = random.uniform(0.05, math.pi / 2 - 0.05)
            else:
                t = random.uniform(0.05, math.pi - 0.05)
            p = random.uniform(-math.pi, math.pi)
            d = self.distance * random.uniform(0.5, 2.0)
            pop.append([t, p, d])

        # Evaluate initial population
        for member in pop:
            yield spherical_to_direction(member[0], member[1]), member[2]

        # Evolve
        for gen in range(self.GENERATIONS):
            for i in range(self.POP_SIZE):
                # Pick 3 distinct others
                others = [j for j in range(self.POP_SIZE) if j != i]
                a, b, c = random.sample(others, 3)
                # Mutant
                trial = [0.0, 0.0, 0.0]
                for k in range(3):
                    if random.random() < self.CR or k == random.randint(0, 2):
                        trial[k] = pop[a][k] + self.F * (pop[b][k] - pop[c][k])
                    else:
                        trial[k] = pop[i][k]
                trial[0] = self._clamp(trial[0])
                trial[1] = wrap_phi(trial[1])
                trial[2] = max(0.1, trial[2])
                yield spherical_to_direction(trial[0], trial[1]), trial[2]
                # After scoring, replace if better (simplified — we track
                # through best_score)

    def _build_refine_plan(self):
        for i in range(10):
            sigma = 0.12 * (0.75 ** i)
            t = self._clamp(self.best_theta + random.gauss(0, sigma))
            p = wrap_phi(self.best_phi + random.gauss(0, sigma))
            d = max(0.1, self.best_distance * (1 + random.gauss(0, 0.05)))
            yield spherical_to_direction(t, p), d


# ---------------------------------------------------------------------------
# Camera registry — maps string keys to (class, display_name)
# ---------------------------------------------------------------------------

ALGORITHM_REGISTRY = {
    'FIBONACCI':   (FibonacciCamera,            "Fibonacci Sphere"),
    'GAUSSIAN':    (WarmGaussianCamera,          "Warm Gaussian"),
    'PID':         (PIDGradientCamera,           "PID Gradient"),
    'PATTERN':     (PatternSearchCamera,         "Pattern Search"),
    'SPIRAL':      (SpiralCamera,                "Spiral Sweep"),
    'ANNEALING':   (SimulatedAnnealingCamera,    "Simulated Annealing"),
    'LEVY':        (LevyWalkCamera,              "Lévy Walk"),
    'GRID':        (GridSweepCamera,             "Grid Sweep"),
    'GOLDEN':      (GoldenSectionCamera,         "Golden Section"),
    'DE':          (DifferentialEvolutionCamera,  "Differential Evolution"),
}

# Ordered list of all algorithm keys (stable iteration order)
ALL_ALGORITHM_KEYS = list(ALGORITHM_REGISTRY.keys())

# Legacy flat lists kept for backward compatibility with get_camera_scores
_CAMERA_CLASSES = [ALGORITHM_REGISTRY[k][0] for k in ALL_ALGORITHM_KEYS]
CAMERA_NAMES = [ALGORITHM_REGISTRY[k][1] for k in ALL_ALGORITHM_KEYS]


def resolve_camera_lineup(num_cameras, assignment_mode='ROUND_ROBIN',
                          single_algo_key=None):
    """Return a list of (CamClass, display_name) tuples for the requested config.

    Args:
        num_cameras:     how many cameras to create (1-50).
        assignment_mode: one of
            'RANDOM'      — each camera gets a randomly chosen algorithm.
            'ROUND_ROBIN' — cycle through all 10 algorithms; wraps if
                            num_cameras > 10.
            'SINGLE'      — every camera uses the algorithm given by
                            *single_algo_key*.
        single_algo_key: required when assignment_mode == 'SINGLE'.
                         Must be a key from ALGORITHM_REGISTRY (e.g. 'PID').

    Returns:
        List of (CameraClass, name_string) with length *num_cameras*.
    """
    num_cameras = max(1, min(50, int(num_cameras)))

    if assignment_mode == 'RANDOM':
        choices = [random.choice(ALL_ALGORITHM_KEYS) for _ in range(num_cameras)]
    elif assignment_mode == 'SINGLE':
        key = single_algo_key or 'FIBONACCI'
        if key not in ALGORITHM_REGISTRY:
            key = 'FIBONACCI'
        choices = [key] * num_cameras
    else:  # ROUND_ROBIN (default)
        choices = [ALL_ALGORITHM_KEYS[i % len(ALL_ALGORITHM_KEYS)]
                   for i in range(num_cameras)]

    return [(ALGORITHM_REGISTRY[k][0], ALGORITHM_REGISTRY[k][1]) for k in choices]


# ---------------------------------------------------------------------------
# Multi-camera coordinator
# ---------------------------------------------------------------------------

class MultiCameraSearch:
    """Coordinates N cameras searching in parallel with configurable algorithms.

    Usage:
        mcs = MultiCameraSearch(
            target_center, start_dir, start_dist, upper_hemi,
            num_cameras=10, assignment_mode='ROUND_ROBIN',
            hotspot_threshold=80.0,
        )
        while True:
            cand = mcs.next_candidate()
            if cand is None:
                break
            cam_id, phase, direction, distance = cand
            # ... render and score ...
            mcs.report_score(cam_id, direction, distance, score)
        print(mcs.best_score, mcs.best_direction, mcs.best_distance)
    """

    def __init__(self, target_center, start_direction, start_distance,
                 upper_hemisphere=True,
                 num_cameras=10,
                 assignment_mode='ROUND_ROBIN',
                 single_algo_key=None,
                 hotspot_threshold=80.0):
        self.target_center = Vector(target_center)
        self.upper_hemisphere = upper_hemisphere
        self.hotspot_threshold = float(hotspot_threshold)

        start_direction = Vector(start_direction).normalized()
        start_theta, start_phi = direction_to_spherical(start_direction)
        start_theta = clamp_theta(start_theta, upper_hemisphere)
        start_phi = wrap_phi(start_phi)

        self.best_score = -1.0
        self.best_direction = start_direction
        self.best_distance = float(start_distance)
        self.evaluations_done = 0

        # Hotspot tracking
        self._hotspot_triggered = False
        self._hotspot_theta = 0.0
        self._hotspot_phi = 0.0
        self._hotspot_distance = 0.0

        # Resolve which algorithm each camera gets
        lineup = resolve_camera_lineup(num_cameras, assignment_mode,
                                       single_algo_key)
        self._num_cameras = len(lineup)
        self._cam_names = [name for _, name in lineup]

        # Create cameras — each gets slightly different starting positions
        # to increase diversity
        self._cameras = []
        for i, (CamClass, _name) in enumerate(lineup):
            offset_t = random.gauss(0, 0.15) if i > 0 else 0
            offset_p = random.gauss(0, 0.15) if i > 0 else 0
            t = clamp_theta(start_theta + offset_t, upper_hemisphere)
            p = wrap_phi(start_phi + offset_p)
            cam = CamClass(i, t, p, float(start_distance), upper_hemisphere)
            self._cameras.append(cam)

        # Build initial plans
        self._plans = [cam.build_plan() for cam in self._cameras]

        # Round-robin index
        self._current_cam = 0
        self._finished_cams = set()

    @property
    def total_evaluations_planned(self):
        return self._num_cameras * 35

    def next_candidate(self):
        """Return (cam_id, phase_name, direction, distance) or None."""
        if self.best_score >= EARLY_STOP_SCORE:
            return None

        attempts = 0
        while attempts < self._num_cameras:
            cam_id = self._current_cam
            self._current_cam = (self._current_cam + 1) % self._num_cameras

            if cam_id in self._finished_cams:
                attempts += 1
                continue

            cam = self._cameras[cam_id]
            plan = self._plans[cam_id]

            try:
                direction, distance = next(plan)
                phase = self._cam_names[cam_id]
                return (cam_id, phase, direction, float(distance))
            except StopIteration:
                self._finished_cams.add(cam_id)
                attempts += 1
                continue

        return None

    def report_score(self, cam_id, direction, distance, score):
        """Feed the score back to the specific camera and update globals."""
        self.evaluations_done += 1
        cam = self._cameras[cam_id]
        cam.report_score(direction, distance, score)

        if score > self.best_score:
            self.best_score = score
            self.best_direction = Vector(direction).normalized()
            self.best_distance = float(distance)

        # Hotspot broadcast
        if score >= self.hotspot_threshold and not self._hotspot_triggered:
            self._hotspot_triggered = True
            t, p = direction_to_spherical(direction)
            self._hotspot_theta = clamp_theta(t, self.upper_hemisphere)
            self._hotspot_phi = wrap_phi(p)
            self._hotspot_distance = float(distance)

            for other_cam in self._cameras:
                if other_cam.cam_id != cam_id:
                    other_cam.teleport_to(
                        self._hotspot_theta,
                        self._hotspot_phi,
                        self._hotspot_distance,
                    )
                    self._plans[other_cam.cam_id] = other_cam._build_refine_plan()
                    self._finished_cams.discard(other_cam.cam_id)

    def get_camera_scores(self):
        """Return list of (cam_name, best_score, evals) for UI display."""
        results = []
        for i, cam in enumerate(self._cameras):
            results.append((self._cam_names[i], cam.best_score, cam.evals))
        return results

    def get_best_camera(self):
        """Return (cam_id, cam_name, score) of the best-performing camera."""
        best_id = 0
        best_s = -1.0
        for cam in self._cameras:
            if cam.best_score > best_s:
                best_s = cam.best_score
                best_id = cam.cam_id
        return best_id, self._cam_names[best_id], best_s
