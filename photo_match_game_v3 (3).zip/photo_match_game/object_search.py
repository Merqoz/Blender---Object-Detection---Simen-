"""Search algorithm for the object auto-solver (6 DOF).

Where `search.py` searches a 3-DOF camera-on-sphere parameter space, this
module searches the **object's** 6-DOF transform:

    (rotation_x, rotation_y, rotation_z, location_x, location_y, location_z)

The camera is held fixed and the target object is rotated and translated
through candidate poses; pixel similarity drives the search.

Algorithm — phased coarse-to-fine with block-coordinate decomposition:

  Phase 0  Baseline           — score the user's current pose as a freebie
  Phase 1  Latin Hypercube    — 16 stratified initial samples for 6D coverage
  Phase 2  Rotation refine    — fix translation, Gaussian-perturb rotation
  Phase 3  Translation refine — fix rotation, Gaussian-perturb translation
  Phase 4  Joint refine       — 6D Gaussian perturbations, catches coupling
  Phase 5  Final polish       — tiny perturbations on both blocks

Why decomposition? Rotation and translation contribute semi-independently to
the rendered image — solving them in turn before joint refinement is more
sample-efficient than searching the full 6D space directly. The joint phase
captures coupling cases (off-axis rotations that need translation correction).

Why LHS over uniform random? For small N, LHS guarantees each dimension is
sampled uniformly across its full range, giving better coverage with the same
budget.

Why not CMA-ES, Bayesian optimization, or DE? CMA-ES is more sophisticated
but needs ~300 lines to implement well. BO is much more sample-efficient but
the surrogate model adds significant complexity. DE doesn't fit the "watch it
search" UX as well. The phased approach is implementable in ~150 lines,
matches the camera-autosolve user experience, and converges reliably in our
budget.
"""

import math
import random

from mathutils import Vector


# ----------------------------------------------------------------------------
# Sampling primitives
# ----------------------------------------------------------------------------

def latin_hypercube(n_samples, n_dimensions):
    """Generate `n_samples` points in [0,1]^`n_dimensions` via LHS.

    Each dimension is divided into `n_samples` strata; exactly one sample falls
    in each stratum, with strata permuted independently per dimension. This
    gives much better coverage than uniform random sampling for small N.
    """
    permutations = [list(range(n_samples)) for _ in range(n_dimensions)]
    for p in permutations:
        random.shuffle(p)

    points = []
    for i in range(n_samples):
        point = []
        for d in range(n_dimensions):
            stratum = permutations[d][i]
            # Random within the stratum, scaled to [0,1]
            point.append((stratum + random.random()) / n_samples)
        points.append(point)
    return points


def random_gaussian_vec3(sigma):
    """Return a 3D vector with each component drawn from N(0, sigma)."""
    return Vector((
        random.gauss(0, sigma),
        random.gauss(0, sigma),
        random.gauss(0, sigma),
    ))


def wrap_angle(a):
    """Wrap an angle (radians) into (-π, π]."""
    return ((a + math.pi) % (2.0 * math.pi)) - math.pi


def wrap_euler(rot):
    """Wrap each component of an Euler-like vector into (-π, π]."""
    return Vector((wrap_angle(rot[0]), wrap_angle(rot[1]), wrap_angle(rot[2])))


# ----------------------------------------------------------------------------
# Search state machine
# ----------------------------------------------------------------------------

class ObjectSolveState:
    """Multi-phase 6-DOF object-pose search.

    Usage mirrors `search.AutoSolveState`:

        state = ObjectSolveState(original_rotation, original_location, radius)
        while True:
            cand = state.next_candidate()
            if cand is None:
                break
            phase, rotation, location = cand
            # ... apply pose, render, score ...
            state.report_score(rotation, location, score)
        # state.best_rotation / best_location hold the answer
    """

    # Per-phase tuning. Total = 1 + 16 + 12 + 12 + 12 + 6 = 59 evaluations.
    INITIAL_SAMPLES = 16
    ROT_REFINE_ITERS = 3
    ROT_SAMPLES_PER_ITER = 4
    TRANS_REFINE_ITERS = 3
    TRANS_SAMPLES_PER_ITER = 4
    JOINT_ITERS = 4
    JOINT_SAMPLES_PER_ITER = 3
    FINAL_ITERS = 2
    FINAL_SAMPLES_PER_ITER = 3

    DEFAULT_EARLY_STOP_SCORE = 97.0  # for pixel-similarity scoring

    def __init__(self, original_rotation, original_location, translation_radius,
                 early_stop_score=None):
        """
        Args:
            original_rotation: Euler XYZ as a 3-vector (radians)
            original_location: world-space XYZ as a 3-vector
            translation_radius: max translation offset along any axis from
                the original location, used as the search bound. Pick something
                like 3x the object's bounding-sphere radius.
            early_stop_score: override the early-stop threshold. Useful for
                contour scoring (V3), where the score ceiling is lower than
                for pixel similarity (~95 vs ~97).
        """
        self.original_rotation = Vector(original_rotation)
        self.original_location = Vector(original_location)
        self.translation_radius = max(float(translation_radius), 0.1)
        self.early_stop_score = (
            float(early_stop_score)
            if early_stop_score is not None
            else self.DEFAULT_EARLY_STOP_SCORE
        )

        self.best_rotation = self.original_rotation.copy()
        self.best_location = self.original_location.copy()
        self.best_score = -1.0
        self.evaluations_done = 0

        self._plan = self._build_plan()

    @property
    def total_evaluations_planned(self):
        return (
            1  # baseline
            + self.INITIAL_SAMPLES
            + self.ROT_REFINE_ITERS * self.ROT_SAMPLES_PER_ITER
            + self.TRANS_REFINE_ITERS * self.TRANS_SAMPLES_PER_ITER
            + self.JOINT_ITERS * self.JOINT_SAMPLES_PER_ITER
            + self.FINAL_ITERS * self.FINAL_SAMPLES_PER_ITER
        )

    # -- Pose helpers --

    def _lhs_sample_to_pose(self, params):
        """Map a [0,1]^6 LHS point to (rotation_euler, location)."""
        # Rotation: full sphere → [-π, π] each axis
        rot = Vector((
            params[0] * 2.0 * math.pi - math.pi,
            params[1] * 2.0 * math.pi - math.pi,
            params[2] * 2.0 * math.pi - math.pi,
        ))
        # Translation: bounded box centered on the original location
        trans = self.original_location + Vector((
            (params[3] * 2.0 - 1.0) * self.translation_radius,
            (params[4] * 2.0 - 1.0) * self.translation_radius,
            (params[5] * 2.0 - 1.0) * self.translation_radius,
        ))
        return rot, trans

    def _perturb_rotation(self, base, sigma):
        offset = random_gaussian_vec3(sigma)
        return wrap_euler(Vector(base) + offset)

    def _perturb_translation(self, base, sigma):
        return Vector(base) + random_gaussian_vec3(sigma)

    # -- The plan --

    def _build_plan(self):
        """Generator yielding (phase_name, rotation, location) tuples.

        Each yield references `self.best_*` at the moment of yield, so phases
        2+ adapt to whatever the previous phases discovered.
        """
        # Phase 0: baseline — score the user's current pose
        yield 'baseline', self.original_rotation.copy(), self.original_location.copy()

        # Phase 1: Latin Hypercube — broad initial coverage
        for params in latin_hypercube(self.INITIAL_SAMPLES, 6):
            rot, trans = self._lhs_sample_to_pose(params)
            yield 'coarse', rot, trans

        # Phase 2: Block descent on rotation (translation fixed at current best)
        for it in range(self.ROT_REFINE_ITERS):
            sigma = 0.6 * (0.65 ** it)  # 0.60 → 0.16 over 3 iters
            for _ in range(self.ROT_SAMPLES_PER_ITER):
                rot = self._perturb_rotation(self.best_rotation, sigma)
                yield 'rotation', rot, self.best_location.copy()

        # Phase 3: Block descent on translation (rotation fixed at current best)
        for it in range(self.TRANS_REFINE_ITERS):
            sigma = 0.5 * (0.65 ** it) * self.translation_radius
            for _ in range(self.TRANS_SAMPLES_PER_ITER):
                trans = self._perturb_translation(self.best_location, sigma)
                yield 'translation', self.best_rotation.copy(), trans

        # Phase 4: Joint refinement — captures coupling effects
        for it in range(self.JOINT_ITERS):
            r_sigma = 0.2 * (0.7 ** it)
            t_sigma = 0.15 * (0.7 ** it) * self.translation_radius
            for _ in range(self.JOINT_SAMPLES_PER_ITER):
                rot = self._perturb_rotation(self.best_rotation, r_sigma)
                trans = self._perturb_translation(self.best_location, t_sigma)
                yield 'joint', rot, trans

        # Phase 5: Final polish
        for it in range(self.FINAL_ITERS):
            r_sigma = 0.08 * (0.5 ** it)
            t_sigma = 0.05 * (0.5 ** it) * self.translation_radius
            for _ in range(self.FINAL_SAMPLES_PER_ITER):
                rot = self._perturb_rotation(self.best_rotation, r_sigma)
                trans = self._perturb_translation(self.best_location, t_sigma)
                yield 'final', rot, trans

    # -- Iteration interface --

    def next_candidate(self):
        if self.best_score >= self.early_stop_score:
            return None
        try:
            return next(self._plan)
        except StopIteration:
            return None

    def report_score(self, rotation, location, score):
        self.evaluations_done += 1
        if score > self.best_score:
            self.best_score = score
            self.best_rotation = Vector(rotation)
            self.best_location = Vector(location)
