"""Image features for contour-aware scoring.

The big idea: instead of comparing pixels (which throws away spatial structure)
or gradient *magnitudes* (which is rotation-symmetric — a vertical edge looks
the same as a horizontal edge to the magnitude-only metric), we compare *where
the edges are*.

The pipeline, applied once per reference image:

  1. Optionally invert (for line-art renders that are white-on-dark)
  2. Histogram-normalize per channel so lighting/contrast differences don't
     dominate the comparison
  3. Compute Sobel gradients → edge magnitude → threshold to a binary edge map
  4. Distance-transform the binary edge map: each pixel becomes "distance to
     the nearest edge". This map is the expensive precomputation; the search
     reuses it for every render.
  5. Build a 3-level multi-scale pyramid (32, 64, 128) — coarse scales smooth
     out local minima, fine scales nail down precise alignment.

For each rendered image during the search:

  1. Compute its edge map at each pyramid level (cheap)
  2. **Chamfer distance**: average the reference's distance-transform values
     at every rendered-edge pixel. Lower = better contour match.

Cost: ~10ms per reference setup, ~3-5ms per scoring call at 128px.

Why a custom distance transform? True Euclidean DT needs scipy or a careful
implementation. The two-pass chamfer DT (3-4 weights) is within ~2% of
Euclidean, runs in pure numpy, and is fast enough.
"""

import numpy as np


# ----------------------------------------------------------------------------
# Edge extraction
# ----------------------------------------------------------------------------

# Sobel kernels — applied via correlation, equivalent to convolution since the
# kernels are symmetric/anti-symmetric in the right ways.
_SOBEL_X = np.array([[-1, 0, 1], [-2, 0, 2], [-1, 0, 1]], dtype=np.float32)
_SOBEL_Y = np.array([[-1, -2, -1], [0, 0, 0], [1, 2, 1]], dtype=np.float32)


def _correlate2d_3x3(image, kernel):
    """3x3 correlation with edge replication. Pure numpy, no scipy needed.

    Implementation: build 8 shifted views of the image (center plus 8
    neighbors), multiply each by its kernel weight, sum. This is faster than
    a Python loop over kernel positions and avoids needing scipy.signal.
    """
    h, w = image.shape
    # Pad with edge replication so border pixels get a sensible result
    padded = np.pad(image, 1, mode='edge')
    out = np.zeros_like(image)
    for ky in range(3):
        for kx in range(3):
            weight = kernel[ky, kx]
            if weight == 0:
                continue
            out += weight * padded[ky:ky + h, kx:kx + w]
    return out


def sobel_edge_map(gray, threshold=0.15):
    """Compute a binary edge map from a grayscale image in [0,1].

    Returns a uint8 array (0 or 1) of the same shape as `gray`.
    """
    gx = _correlate2d_3x3(gray, _SOBEL_X)
    gy = _correlate2d_3x3(gray, _SOBEL_Y)
    magnitude = np.sqrt(gx * gx + gy * gy)
    # Normalize so threshold is independent of image brightness range
    max_mag = float(magnitude.max())
    if max_mag > 1e-6:
        magnitude /= max_mag
    return (magnitude > threshold).astype(np.uint8)


# ----------------------------------------------------------------------------
# Silhouette extraction
# ----------------------------------------------------------------------------
#
# Why this exists: when the reference image has a cluttered background (e.g.
# a phone photo of an object on a busy desk), Sobel produces edges everywhere
# — every desk crease, every shadow, every wall line. The rendered scene from
# Blender, by contrast, has just the target object on a plain background, so
# its edges are sparse. Comparing the two with chamfer matching means the
# render's silhouette gets penalized by being "far from" all the background
# edges in the reference.
#
# Solution: keep only the largest connected component of the edge map, on the
# bet that it's the object's outline. Discard everything else. Apply the same
# filter symmetrically to both reference and rendered edges so the comparison
# stays apples-to-apples.
#
# Implementation: textbook two-pass connected-component labeling with
# union-find. 8-connected (so diagonal Sobel ridges stay joined). Pure numpy
# + Python loop in pass 1; vectorized lookup in pass 2. Cost at 128x128 with
# typical edge density: ~3-5ms.

def extract_largest_silhouette(edges):
    """Keep only the largest 8-connected component of a binary edge map.

    Args:
        edges: HxW uint8 array, nonzero where there's an edge.

    Returns:
        HxW uint8 array of the same shape. 1 where the largest component was;
        0 elsewhere. All-zero input → all-zero output.
    """
    h, w = edges.shape
    if int((edges > 0).sum()) == 0:
        return np.zeros_like(edges, dtype=np.uint8)

    # --- Union-find ---
    # parent[i] points to a smaller-or-equal label in the same component as i.
    # parent[0] = 0 (background sentinel). Path compression in find() keeps
    # amortized cost near-constant.
    parent = [0]  # index 0 is the background sentinel; real labels start at 1

    def find(x):
        # Path-compression: walk to the root, then re-point every node along
        # the way directly at the root.
        root = x
        while parent[root] != root:
            root = parent[root]
        while parent[x] != root:
            parent[x], x = root, parent[x]
        return root

    def union(a, b):
        ra, rb = find(a), find(b)
        if ra == rb:
            return
        # Always keep the smaller label as the root — pass-2 lookups become
        # deterministic and cluster lower-numbered labels first.
        if ra < rb:
            parent[rb] = ra
        else:
            parent[ra] = rb

    # --- Pass 1: provisional labels ---
    # Of the 8 neighbors of (y, x), only the four in the upper-left quadrant
    # (NW, N, NE, W) have already been visited in raster order — those are
    # the only ones we check here.
    labels = np.zeros((h, w), dtype=np.int32)
    next_label = 1
    for y in range(h):
        for x in range(w):
            if edges[y, x] == 0:
                continue
            found = []
            if y > 0:
                if x > 0 and labels[y - 1, x - 1] != 0:
                    found.append(labels[y - 1, x - 1])
                if labels[y - 1, x] != 0:
                    found.append(labels[y - 1, x])
                if x < w - 1 and labels[y - 1, x + 1] != 0:
                    found.append(labels[y - 1, x + 1])
            if x > 0 and labels[y, x - 1] != 0:
                found.append(labels[y, x - 1])

            if not found:
                labels[y, x] = next_label
                parent.append(next_label)
                next_label += 1
            else:
                m = min(found)
                labels[y, x] = m
                # Union the rest with m. Path compression makes duplicates fast.
                for n in found:
                    if n != m:
                        union(m, n)

    if next_label <= 1:
        return np.zeros_like(edges, dtype=np.uint8)

    # --- Pass 2: resolve labels to canonical roots, vectorized ---
    roots = np.array([find(i) for i in range(next_label)], dtype=np.int32)
    canonical = roots[labels]  # HxW canonical-label array; 0 where no edge

    counts = np.bincount(canonical.ravel(), minlength=next_label)
    counts[0] = 0  # background never wins
    largest_label = int(np.argmax(counts))
    if counts[largest_label] == 0:
        return np.zeros_like(edges, dtype=np.uint8)

    return (canonical == largest_label).astype(np.uint8)


# ----------------------------------------------------------------------------
# Distance transform (chamfer 3-4)
# ----------------------------------------------------------------------------

# Chamfer weights: orthogonal neighbors cost 3, diagonal neighbors cost 4.
# This approximates Euclidean distance to within ~2% (since 4/3 ≈ √2 = 1.414).
# See: Borgefors 1986, "Distance transformations in digital images".

_CHAMFER_ORTH = 3.0
_CHAMFER_DIAG = 4.0


def chamfer_distance_transform(edges):
    """Two-pass 3-4 chamfer distance transform.

    Input: 2D uint8 array, 1 where there's an edge, 0 elsewhere.
    Output: float32 array of same shape, each cell = approximate distance to
    nearest edge pixel (in chamfer units; divide by 3 to get Euclidean-ish).

    Two-pass: forward pass propagates distance from upper-left, backward pass
    from lower-right. After both passes every cell holds the min distance to
    any edge pixel. ~5ms for a 128x128 image in pure numpy.
    """
    h, w = edges.shape
    LARGE = float(h * w * _CHAMFER_DIAG)  # bigger than any possible distance
    dist = np.where(edges > 0, 0.0, LARGE).astype(np.float32)

    # --- Forward pass (top-left → bottom-right) ---
    # For each cell, look at neighbors above and to the left and take min(
    # current, neighbor + edge_cost).
    for y in range(h):
        for x in range(w):
            if dist[y, x] == 0.0:
                continue
            best = dist[y, x]
            if y > 0:
                best = min(best, dist[y - 1, x] + _CHAMFER_ORTH)
                if x > 0:
                    best = min(best, dist[y - 1, x - 1] + _CHAMFER_DIAG)
                if x < w - 1:
                    best = min(best, dist[y - 1, x + 1] + _CHAMFER_DIAG)
            if x > 0:
                best = min(best, dist[y, x - 1] + _CHAMFER_ORTH)
            dist[y, x] = best

    # --- Backward pass (bottom-right → top-left) ---
    for y in range(h - 1, -1, -1):
        for x in range(w - 1, -1, -1):
            if dist[y, x] == 0.0:
                continue
            best = dist[y, x]
            if y < h - 1:
                best = min(best, dist[y + 1, x] + _CHAMFER_ORTH)
                if x > 0:
                    best = min(best, dist[y + 1, x - 1] + _CHAMFER_DIAG)
                if x < w - 1:
                    best = min(best, dist[y + 1, x + 1] + _CHAMFER_DIAG)
            if x < w - 1:
                best = min(best, dist[y, x + 1] + _CHAMFER_ORTH)
            dist[y, x] = best

    return dist


def chamfer_distance_transform_vectorized(edges):
    """Vectorized version of the two-pass chamfer DT.

    Pure-Python loop is too slow (~200ms at 128px). Vectorizing with shifted
    array views per row/column gives ~5ms. Idea: instead of looping over
    individual cells, process whole rows at once using array slicing.
    """
    h, w = edges.shape
    LARGE = np.float32(h * w * _CHAMFER_DIAG)
    dist = np.where(edges > 0, np.float32(0.0), LARGE)

    # Forward pass: row by row from top, each row uses already-updated row above
    for y in range(h):
        row = dist[y]
        if y > 0:
            above = dist[y - 1]
            # Orthogonal neighbor (directly above)
            candidate = above + _CHAMFER_ORTH
            np.minimum(row, candidate, out=row)
            # Diagonal upper-left
            candidate_l = np.empty_like(row)
            candidate_l[0] = LARGE
            candidate_l[1:] = above[:-1] + _CHAMFER_DIAG
            np.minimum(row, candidate_l, out=row)
            # Diagonal upper-right
            candidate_r = np.empty_like(row)
            candidate_r[-1] = LARGE
            candidate_r[:-1] = above[1:] + _CHAMFER_DIAG
            np.minimum(row, candidate_r, out=row)
        # Within-row left propagation (must be sequential within the row)
        for x in range(1, w):
            cand = row[x - 1] + _CHAMFER_ORTH
            if cand < row[x]:
                row[x] = cand

    # Backward pass: row by row from bottom
    for y in range(h - 1, -1, -1):
        row = dist[y]
        if y < h - 1:
            below = dist[y + 1]
            candidate = below + _CHAMFER_ORTH
            np.minimum(row, candidate, out=row)
            candidate_l = np.empty_like(row)
            candidate_l[0] = LARGE
            candidate_l[1:] = below[:-1] + _CHAMFER_DIAG
            np.minimum(row, candidate_l, out=row)
            candidate_r = np.empty_like(row)
            candidate_r[-1] = LARGE
            candidate_r[:-1] = below[1:] + _CHAMFER_DIAG
            np.minimum(row, candidate_r, out=row)
        for x in range(w - 2, -1, -1):
            cand = row[x + 1] + _CHAMFER_ORTH
            if cand < row[x]:
                row[x] = cand

    # Convert chamfer units → Euclidean-ish (divide by orth weight)
    return dist / _CHAMFER_ORTH


# ----------------------------------------------------------------------------
# Filtering
# ----------------------------------------------------------------------------

def histogram_normalize(gray):
    """Stretch a grayscale image so 1st/99th percentiles map to [0, 1].

    Robust to a few extreme outliers; prevents brightness or contrast offsets
    between reference and render from dominating the comparison.
    """
    lo = np.percentile(gray, 1)
    hi = np.percentile(gray, 99)
    if hi - lo < 1e-6:
        return np.zeros_like(gray)
    return np.clip((gray - lo) / (hi - lo), 0.0, 1.0)


def maybe_invert_for_line_art(gray):
    """Detect & invert line-art images (mostly bright with dark edges).

    Sobel-based edge detection naturally handles both polarities, but for
    line-art renders that are white-on-dark vs photo references that are
    typically the opposite, normalizing brightness helps.

    Heuristic: if the mean brightness is above 0.6, the image is likely
    "mostly light pixels with dark detail" — invert it.
    """
    if float(np.mean(gray)) > 0.6:
        return 1.0 - gray
    return gray


def downsample_2x(image):
    """Box-filter downsample by 2 in each dimension.

    Cheap: just reshape-and-mean. For odd dims, the last row/column gets
    duplicated before reshape so we don't lose them.
    """
    if image.ndim == 2:
        h, w = image.shape
        h2 = h // 2 * 2
        w2 = w // 2 * 2
        cropped = image[:h2, :w2]
        return cropped.reshape(h2 // 2, 2, w2 // 2, 2).mean(axis=(1, 3))
    else:
        h, w, c = image.shape
        h2 = h // 2 * 2
        w2 = w // 2 * 2
        cropped = image[:h2, :w2]
        return cropped.reshape(h2 // 2, 2, w2 // 2, 2, c).mean(axis=(1, 3))


def resize_nearest(arr, new_h, new_w):
    """Nearest-neighbor resize for HxW or HxWxC arrays."""
    h, w = arr.shape[:2]
    ys = np.linspace(0, h - 1, new_h).astype(np.int64)
    xs = np.linspace(0, w - 1, new_w).astype(np.int64)
    return arr[ys][:, xs]


def to_grayscale(rgb):
    """Convert HxWx3 RGB → HxW grayscale using luminance weights."""
    return 0.299 * rgb[..., 0] + 0.587 * rgb[..., 1] + 0.114 * rgb[..., 2]


# ----------------------------------------------------------------------------
# Reference features — built once per reference, reused for every search step
# ----------------------------------------------------------------------------

class ReferenceFeatures:
    """Cached features extracted from a reference image.

    Built once when the reference loads (or settings change), then reused for
    every score evaluation during the search. The expensive parts — distance
    transform and pyramid construction — happen here, not per-evaluation.

    Attributes:
        levels: list of dicts, one per pyramid level, each containing:
            'size': (height, width)
            'gray': normalized grayscale image, HxW float32
            'edges': binary edge map, HxW uint8
            'distance': distance transform of edges, HxW float32
                        (each pixel = distance to nearest edge in pixels)
            'edge_count': total number of edge pixels in this level
        weight_per_level: weighting for combining scores across levels
    """

    PYRAMID_SIZES = [(32, 32), (64, 64), (128, 128)]
    # Heavier weights at finer scales — coarse helps avoid local minima but
    # finest scale determines the final precision.
    LEVEL_WEIGHTS = [0.2, 0.35, 0.45]

    def __init__(self, rgb_image, edge_threshold=0.15, auto_invert=True,
                 normalize=True, silhouette_only=False):
        """Build the multi-scale feature pyramid.

        Args:
            rgb_image: HxWx3 float32 array in [0, 1]
            edge_threshold: Sobel magnitude cutoff (lower = more edges)
            auto_invert: if True, detect line-art and invert
            normalize: if True, histogram-normalize each level
            silhouette_only: if True, keep only the largest connected
                component of the edge map at each pyramid level. Useful
                when the reference has cluttered background that would
                otherwise drown out the target object's contour. The
                same filter must be applied to rendered images at scoring
                time — `contour_score` does this automatically by reading
                this flag back off the ReferenceFeatures.
        """
        gray = to_grayscale(rgb_image)
        if auto_invert:
            gray = maybe_invert_for_line_art(gray)

        # Stash on self so contour_score can apply the matching filter to
        # rendered images without the caller having to track the flag.
        self.silhouette_only = silhouette_only

        self.levels = []
        for (h, w) in self.PYRAMID_SIZES:
            level_gray = resize_nearest(gray, h, w)
            if normalize:
                level_gray = histogram_normalize(level_gray)
            edges = sobel_edge_map(level_gray, threshold=edge_threshold)
            if silhouette_only:
                # Replace the full edge map with just the largest component
                # BEFORE the DT and edge_count computation, so backward
                # chamfer (which iterates over ref_level['edges']) stays
                # consistent with forward chamfer (which uses the DT).
                edges = extract_largest_silhouette(edges)
            distance = chamfer_distance_transform_vectorized(edges)
            self.levels.append({
                'size': (h, w),
                'gray': level_gray,
                'edges': edges,
                'distance': distance,
                'edge_count': int(edges.sum()),
            })

        self.weight_per_level = list(self.LEVEL_WEIGHTS)
        # Normalize weights to 1 in case caller overrides them later
        s = sum(self.weight_per_level)
        if s > 0:
            self.weight_per_level = [w / s for w in self.weight_per_level]

        # The maximum useful chamfer distance: any rendered edge that's
        # farther than this from a reference edge is "missed" — capping
        # prevents one outlier pixel from dominating the average. Tighter
        # clipping means more aggressive discrimination near the optimum;
        # 12% of the image dimension is a tested sweet spot.
        self.distance_clip = max(self.levels[-1]['size']) * 0.12


# ----------------------------------------------------------------------------
# Scoring against cached reference features
# ----------------------------------------------------------------------------

def _chamfer_score_one_level(rendered_gray, ref_level, edge_threshold,
                             distance_clip, silhouette_only=False):
    """Score one pyramid level: lower mean chamfer distance → higher score."""
    h, w = ref_level['size']
    if rendered_gray.shape != (h, w):
        rendered_gray = resize_nearest(rendered_gray, h, w)
    rendered_gray = histogram_normalize(rendered_gray)
    rendered_edges = sobel_edge_map(rendered_gray, threshold=edge_threshold)
    if silhouette_only:
        # Apply the same filter the reference was built with — both forward
        # and backward chamfer must compare like-against-like, otherwise the
        # render's silhouette gets penalized for failing to match clutter
        # that's not actually there.
        rendered_edges = extract_largest_silhouette(rendered_edges)

    # Chamfer score has two halves — average distance from each rendered edge
    # to the nearest reference edge, AND average distance from each reference
    # edge to the nearest rendered edge. Doing both is the "symmetric chamfer
    # distance" and it avoids the failure case where the renderer produces no
    # edges at all (would otherwise score perfectly).
    ref_dist = ref_level['distance']

    # Forward: rendered edges → reference distance map
    if int(rendered_edges.sum()) > 0:
        forward = float(np.mean(np.minimum(
            ref_dist[rendered_edges > 0], distance_clip
        )))
    else:
        forward = distance_clip

    # Backward: reference edges → rendered distance map (compute on the fly,
    # since we don't have it cached for the rendered image)
    if int(rendered_edges.sum()) > 0:
        rendered_dist = chamfer_distance_transform_vectorized(rendered_edges)
        if ref_level['edge_count'] > 0:
            backward = float(np.mean(np.minimum(
                rendered_dist[ref_level['edges'] > 0], distance_clip
            )))
        else:
            backward = 0.0  # ref has no edges → nothing to compare
    else:
        backward = distance_clip

    mean_distance = 0.5 * (forward + backward)

    # Convert distance → 0..100 score. distance_clip is the worst case,
    # 0 is perfect. Power curve of 2.5 (matching strict_pixel_similarity)
    # squeezes the middle and rewards real precision.
    if distance_clip <= 0:
        return 100.0
    normalized = 1.0 - min(1.0, mean_distance / distance_clip)
    return max(0.0, min(100.0, (normalized ** 2.5) * 100.0))


def contour_score(rendered_rgb, reference_features, edge_threshold=0.15,
                  silhouette_only=None):
    """Multi-scale Chamfer score 0..100 for a rendered image.

    Args:
        rendered_rgb: HxWx3 float32 array in [0, 1] (any size)
        reference_features: pre-built ReferenceFeatures
        edge_threshold: same threshold used when building the reference
        silhouette_only: if None (default), inherit from
            `reference_features.silhouette_only`. If True/False, override —
            useful only for diagnostics or unit tests; mismatching this
            against the reference's setting will produce asymmetric scoring.

    Returns:
        Weighted average across pyramid levels.
    """
    if silhouette_only is None:
        # Inherit from the reference. Older ReferenceFeatures objects from
        # before this attribute existed are treated as silhouette_only=False.
        silhouette_only = getattr(reference_features, 'silhouette_only', False)

    rendered_gray = to_grayscale(rendered_rgb)

    total = 0.0
    for level, weight in zip(reference_features.levels,
                             reference_features.weight_per_level):
        score = _chamfer_score_one_level(
            rendered_gray, level, edge_threshold,
            reference_features.distance_clip,
            silhouette_only=silhouette_only,
        )
        total += weight * score
    return total
