"""Live scoring — background timer that updates pose scores in real time.

A `bpy.app.timers` callback runs every ~200ms. When it detects that the player
camera has moved since the last tick, it recomputes the cheap pose-based
metrics (position + rotation) and the combined score. The expensive pixel
metric is left as-is; refreshing it requires a full render and is the job of
the explicit Calculate button.

This is opt-in (controlled by `props.live_scoring_enabled`) and only does
anything when a hidden reference camera exists — i.e. when the user generated
a random challenge. Loaded-image mode has no pose ground truth to compare
against.

The timer also pauses itself while the auto-solver is running, so the two
features don't fight over the camera.
"""

import bpy

from . import camera_utils
from . import geometry
from . import scoring


# Tracks the last known camera matrix per scene so we can short-circuit when
# the camera hasn't moved. Keyed by scene name (scenes can be renamed but the
# worst case is one redundant rescore).
_LAST_POSE_HASH = {}

# How often to poll. 5x/second is responsive without burning CPU.
_TICK_INTERVAL = 0.2


def _camera_pose_hash(cam):
    """Cheap hash of the camera's world matrix — used to detect movement."""
    if cam is None:
        return None
    mat = cam.matrix_world
    return tuple(round(v, 5) for row in mat for v in row)


def _tag_viewports():
    """Force a panel redraw so updated scores show up immediately."""
    try:
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except Exception:
        pass


def _update_scene_scores(scene):
    """Compute and store live pose scores for one scene. Returns True if it
    actually did work (so we know whether to redraw)."""
    if not hasattr(scene, 'photo_match_props'):
        return False

    props = scene.photo_match_props
    if not props.live_scoring_enabled:
        return False
    if props.auto_solve_running:
        return False
    if props.reference_camera is None or props.target_object is None:
        return False

    cam = scene.camera
    if cam is None or cam.type != 'CAMERA':
        return False
    if cam.name == camera_utils.REFERENCE_CAMERA_NAME:
        return False

    # Skip if the camera (and reference camera, in case the user moved it)
    # hasn't budged since the last tick.
    pose_hash = (_camera_pose_hash(cam), _camera_pose_hash(props.reference_camera))
    if _LAST_POSE_HASH.get(scene.name) == pose_hash:
        return False
    _LAST_POSE_HASH[scene.name] = pose_hash

    # Compute pose metrics — both are essentially free
    target_center, _ = geometry.target_center_and_radius(props.target_object)
    ref_loc = props.reference_camera.matrix_world.translation
    ref_quat = props.reference_camera.matrix_world.to_quaternion()
    player_loc = cam.matrix_world.translation
    player_quat = cam.matrix_world.to_quaternion()

    characteristic_distance = (ref_loc - target_center).length
    props.position_score = scoring.position_similarity(
        player_loc, ref_loc, characteristic_distance
    )
    props.rotation_score = scoring.rotation_similarity(player_quat, ref_quat)

    # Combined uses the cached pixel score; if Calculate hasn't been pressed,
    # pixel_score is 0 and the combined will be a bit pessimistic until they
    # do. The breakdown in the UI makes it obvious why.
    props.score = scoring.combined_score(
        props.pixel_score, props.position_score, props.rotation_score
    )
    if props.score > props.best_score:
        props.best_score = props.score

    return True


def _tick():
    """Timer callback. Returns the delay until the next tick (or None to stop)."""
    try:
        any_changed = False
        for scene in bpy.data.scenes:
            if _update_scene_scores(scene):
                any_changed = True
        if any_changed:
            _tag_viewports()
    except Exception as e:
        # Never let an error kill the timer — log and keep ticking
        print(f"Photo Match live scoring error: {e}")
    return _TICK_INTERVAL


def register():
    if not bpy.app.timers.is_registered(_tick):
        bpy.app.timers.register(_tick, persistent=True)


def unregister():
    if bpy.app.timers.is_registered(_tick):
        try:
            bpy.app.timers.unregister(_tick)
        except Exception:
            pass
    _LAST_POSE_HASH.clear()
